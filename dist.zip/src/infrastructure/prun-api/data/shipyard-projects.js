import { onApiMessage } from "./api-messages.js";
import { createEntityStore } from "./create-entity-store.js";
import { createRequestStore, request } from "./request-hooks.js";
const store = createEntityStore();
const state = store.state;
onApiMessage({
  SHIPYARD_PROJECTS(data) {
    store.setAll(data.projects);
    store.setFetched();
  },
  SHIPYARD_PROJECT(data) {
    store.setOne(data);
  }
});
const shipyardProjectsStore = createRequestStore(request.shipyardProjects, {
  ...state
});
export {
  shipyardProjectsStore
};
