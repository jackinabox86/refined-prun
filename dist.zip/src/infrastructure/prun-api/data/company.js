import { onApiMessage } from "./api-messages.js";
import { shallowRef } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const companyStore = shallowRef(void 0);
onApiMessage({
  COMPANY_DATA(data) {
    companyStore.value = data;
  }
});
export {
  companyStore
};
