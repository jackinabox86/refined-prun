import { onApiMessage } from "./api-messages.js";
import { shallowReactive } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const uiDataStore = shallowReactive({});
onApiMessage({
  UI_DATA(data) {
    Object.assign(uiDataStore, data);
  }
});
export {
  uiDataStore
};
