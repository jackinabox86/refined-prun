import { createEntityStore } from "./create-entity-store.js";
import { onApiMessage } from "./api-messages.js";
import { createMapGetter } from "./create-map-getter.js";
import { materialsStore } from "./materials.js";
const store = createEntityStore();
const state = store.state;
onApiMessage({
  WORLD_MATERIAL_CATEGORIES(data) {
    store.setAll(data.categories);
    store.setFetched();
  }
});
const toSerializableCategoryName = (name) => name.replaceAll("(", "").replaceAll(")", "").toUpperCase();
const getBySerializableName = createMapGetter(state.all, (x) => x.name, toSerializableCategoryName);
const getById = createMapGetter(state.all, (x) => x.id);
const getCategoryById = (id) => {
  if (!id) {
    return void 0;
  }
  return getById(id);
};
const getCategoryByMaterialIdentifier = (identifier) => {
  if (!identifier) {
    return void 0;
  }
  const search = identifier.toUpperCase();
  const material = materialsStore.all.value?.find(
    (m) => m.ticker.toUpperCase() === search || m.name.toUpperCase() === search
  );
  return getCategoryById(material?.category);
};
const materialCategoriesStore = {
  ...state,
  getById,
  getBySerializableName,
  getCategoryById,
  getCategoryByMaterialIdentifier
};
export {
  getCategoryById,
  getCategoryByMaterialIdentifier,
  materialCategoriesStore,
  toSerializableCategoryName
};
