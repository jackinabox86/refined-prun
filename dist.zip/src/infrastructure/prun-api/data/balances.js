import { onApiMessage } from "./api-messages.js";
import { createEntityStore } from "./create-entity-store.js";
import { ref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { computed } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
const store = createEntityStore({ selectId: (x) => x.currency });
const state = store.state;
const ownCurrency = ref("");
onApiMessage({
  ACCOUNTING_CASH_BALANCES(data) {
    ownCurrency.value = data.ownCurrency.code;
    store.setAll(data.currencyAccounts.map((x) => x.currencyBalance));
    store.setFetched();
  },
  ACCOUNTING_BOOKINGS(data) {
    for (const item of data.items) {
      if (item.accountCategory !== "LIQUID_ASSETS" && item.accountType !== 1800) {
        continue;
      }
      store.setOne(item.balance);
    }
  }
});
const currencies = computed(() => state.all.value?.map((x) => x.currency));
const balancesStore = {
  ...state,
  ownCurrency,
  currencies
};
export {
  balancesStore
};
