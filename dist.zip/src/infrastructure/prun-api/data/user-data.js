import { onApiMessage } from "./api-messages.js";
import { shallowReactive } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { computed } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
const userDataStore = shallowReactive({});
const companyContextId = computed(
  () => userDataStore.contexts?.find((x) => x.type === "COMPANY")?.id
);
onApiMessage({
  USER_DATA(data) {
    Object.assign(userDataStore, data);
  }
});
export {
  companyContextId,
  userDataStore
};
