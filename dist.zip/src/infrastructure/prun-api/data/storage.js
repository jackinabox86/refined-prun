import { createEntityStore } from "./create-entity-store.js";
import { onApiMessage } from "./api-messages.js";
import { createGroupMapGetter } from "./create-map-getter.js";
import { computed } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
const store = createEntityStore();
const state = store.state;
onApiMessage({
  STORAGE_STORAGES(data) {
    store.setMany(data.stores);
    store.setFetched();
  },
  STORAGE_CHANGE(data) {
    store.setMany(data.stores);
  },
  STORAGE_REMOVED(data) {
    for (const id of data.storeIds) {
      store.removeOne(id);
    }
  }
});
const getByAddressableId = createGroupMapGetter(state.all, (x) => x.addressableId);
const getByName = createGroupMapGetter(state.all, (x) => x.name ?? "");
const getByTypeRaw = createGroupMapGetter(state.all, (x) => x.type);
const getByType = (value) => state.fetched.value ? getByTypeRaw(value) ?? [] : getByTypeRaw(value);
const personal = computed(() => state.all.value?.filter(isPersonalStorage));
const nonPersonalTypes = /* @__PURE__ */ new Set(["CONSTRUCTION_STORE", "UPKEEP_STORE"]);
function isPersonalStorage(storage) {
  return !nonPersonalTypes.has(storage.type);
}
const fuelStores = computed(() => personal.value?.filter(isFuelStore));
const nonFuelStores = computed(() => personal.value?.filter((x) => !isFuelStore(x)));
const fuelTypes = /* @__PURE__ */ new Set(["STL_FUEL_STORE", "FTL_FUEL_STORE", "VORTEX_FUEL_STORE"]);
function isFuelStore(storage) {
  return fuelTypes.has(storage.type);
}
const storagesStore = {
  ...state,
  all: personal,
  fuelStores,
  nonFuelStores,
  getByAddressableId,
  getByName,
  getByType
};
export {
  storagesStore
};
