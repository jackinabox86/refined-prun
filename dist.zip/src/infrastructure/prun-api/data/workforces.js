import { createEntityStore } from "./create-entity-store.js";
import { onApiMessage } from "./api-messages.js";
import { createRequestGetter, request } from "./request-hooks.js";
const store = createEntityStore({ selectId: (x) => x.siteId });
const state = store.state;
onApiMessage({
  WORKFORCE_WORKFORCES(data) {
    store.setOne(data);
    store.setFetched();
  },
  WORKFORCE_WORKFORCES_UPDATED(data) {
    store.setOne(data);
  }
});
const getById = createRequestGetter(state.getById, (x) => request.workforce(x));
const workforcesStore = {
  ...state,
  getById
};
export {
  workforcesStore
};
