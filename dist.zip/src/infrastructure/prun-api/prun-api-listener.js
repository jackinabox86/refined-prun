import socketIOMiddleware from "./socket-io-middleware.js";
import { dispatch } from "./data/api-messages.js";
import { companyContextId } from "./data/user-data.js";
import { startMeasure } from "../../utils/performance-measure.js";
import { context } from "./data/screens.js";
import { watchUntil } from "../../utils/watch.js";
import { ref } from "../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { computed } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
const initialApiLoadingComplete = ref(false);
const middleware = {
  onOpen: function() {
    const storeAction = {
      type: "CLIENT_CONNECTION_OPENED",
      data: void 0
    };
    dispatch(storeAction);
  },
  onMessage: async (message) => {
    if (context.value === companyContextId.value || !companyContextId.value || !context.value) {
      return await processEvent(message) ?? false;
    }
    return false;
  },
  dispatchClientMessage: ref(void 0)
};
function listenPrunApi() {
  socketIOMiddleware(middleware);
}
const isRecordingPrunLog = ref(false);
const prunLog = ref([]);
async function processEvent(message) {
  if (!message || !message.messageType || !message.payload) {
    return;
  }
  startMeasure(message.messageType);
  try {
    if (message.messageType === "ACTION_COMPLETED") {
      return processEvent(message.payload.message);
    } else {
      if (isRecordingPrunLog.value) {
        prunLog.value.push(message);
      }
      const storeAction = {
        type: message.messageType,
        data: message.payload
      };
      const result = dispatch(storeAction);
      if (message.messageType === "COMPANY_DATA" && !initialApiLoadingComplete.value) {
        await watchUntil(() => initialApiLoadingComplete.value);
      }
      return result;
    }
  } finally {
  }
}
const canDispatchClientPrunMessage = computed(
  () => !!middleware.dispatchClientMessage.value
);
function dispatchClientPrunMessage(message) {
  if (!middleware.dispatchClientMessage.value) {
    return false;
  }
  middleware.dispatchClientMessage.value(message);
  return true;
}
export {
  canDispatchClientPrunMessage,
  dispatchClientPrunMessage,
  initialApiLoadingComplete,
  isRecordingPrunLog,
  listenPrunApi,
  prunLog
};
