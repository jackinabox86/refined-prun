import { decodePayload, encodePayload } from "../../../npm/engine.io-parser@5.2.3-engine.io-parser.js";
import { PacketType, Encoder, Decoder } from "../../../npm/socket.io-parser@4.2.6-socket.io-parser.js";
import { castArray } from "../../utils/cast-array.js";
function socketIOMiddleware(middleware) {
  const addEventListener = WebSocket.prototype.addEventListener;
  window.WebSocket = new Proxy(WebSocket, {
    construct(target, args) {
      const ws = new target(...args);
      return new Proxy(ws, {
        set(target2, prop, value) {
          if (prop === "onmessage") {
            middleware.dispatchClientMessage.value = (message) => {
              value(new MessageEvent("message", { data: encodeMessage(message) }));
            };
            target2.onmessage = async (e) => {
              const data = await processMessage(e.data, middleware);
              if (data !== e.data) {
                e = new Proxy(e, {
                  get(target3, prop2) {
                    if (prop2 === "data") {
                      return data;
                    }
                    return Reflect.get(target3, prop2);
                  }
                });
              }
              value(e);
            };
            return true;
          }
          return Reflect.set(target2, prop, value);
        },
        get(target2, prop) {
          if (prop === "addEventListener") {
            return addEventListener.bind(target2);
          }
          const value = Reflect.get(target2, prop);
          if (typeof value === "function") {
            return value.bind(target2);
          }
          return value;
        }
      });
    }
  });
  WebSocket.prototype.addEventListener = function(type, listener, options) {
    return this.addEventListener(type, listener, options);
  };
  window.XMLHttpRequest = new Proxy(XMLHttpRequest, {
    construct(target) {
      const xhr = new target();
      let data = "";
      return new Proxy(xhr, {
        get(target2, prop) {
          if (prop === "responseText" && data) {
            return data;
          }
          const value = Reflect.get(target2, prop);
          if (typeof value === "function") {
            return value.bind(target2);
          }
          return value;
        },
        set(target2, prop, value) {
          if (prop === "onreadystatechange") {
            target2.onreadystatechange = async () => {
              if (target2.readyState === 4 && target2.status === 200) {
                data = await processMessage(target2.responseText, middleware);
              }
              value();
            };
            return true;
          }
          return Reflect.set(target2, prop, value);
        }
      });
    }
  });
}
async function processMessage(data, middleware) {
  const engineIOPackets = decodePayload(data);
  const rewrite = await Promise.all(
    engineIOPackets.map((packet) => processEngineIOPacket(packet, middleware))
  );
  return rewrite.some((x) => x) ? encodeEIOPacket(engineIOPackets) : data;
}
async function processEngineIOPacket(packet, middleware) {
  if (packet.type !== "message") {
    return false;
  }
  const decodedPacket = decodeSIOPacket(packet.data);
  if (!decodedPacket) {
    console.error(`Failed to decode packet: ${packet.data}`);
    return false;
  }
  const data = decodedPacket.data;
  if (decodedPacket.type === 0) {
    try {
      middleware.onOpen();
    } catch (error) {
      console.error(error);
    }
    return false;
  }
  const payload = data[1];
  if (decodedPacket.type !== 2 || data[0] !== "event" || payload === void 0) {
    return false;
  }
  let rewrite;
  try {
    rewrite = await middleware.onMessage(payload);
  } catch (error) {
    console.error(error);
    rewrite = false;
  }
  if (rewrite) {
    packet.data = encodeSIOPacket(decodedPacket);
  }
  return rewrite;
}
function encodeMessage(message) {
  return encodeEIOPacket({
    type: "message",
    data: encodeSIOPacket({
      type: PacketType.EVENT,
      nsp: "/",
      data: ["event", message]
    })
  });
}
function encodeSIOPacket(packet) {
  const encoder = new Encoder();
  return encoder.encode(packet)[0];
}
function decodeSIOPacket(data) {
  const decoder = new Decoder();
  let decodedPacket;
  decoder.on("decoded", (x) => decodedPacket = x);
  decoder.add(data);
  return decodedPacket;
}
function encodeEIOPacket(packet) {
  let data;
  encodePayload(castArray(packet), (newData) => {
    data = newData;
  });
  return data;
}
export {
  socketIOMiddleware as default
};
