import { startRelay } from "./relay.js";
import { listenPrunApi, initialApiLoadingComplete } from "./prun-api-listener.js";
import { preloadFioResponses, loadFallbackPlanetData } from "../fio/fio-api.js";
import { watchUntil } from "../../utils/watch.js";
import { companyStore } from "./data/company.js";
import { alertsStore } from "./data/alerts.js";
import { materialsStore } from "./data/materials.js";
import { uiDataStore } from "./data/ui-data.js";
import { balancesStore } from "./data/balances.js";
import { flightsStore } from "./data/flights.js";
import { shipsStore } from "./data/ships.js";
import { starsStore } from "./data/stars.js";
import { sitesStore } from "./data/sites.js";
import { storagesStore } from "./data/storage.js";
import { warehousesStore } from "./data/warehouses.js";
import { contractsStore } from "./data/contracts.js";
import { fetchPrices } from "../fio/cx.js";
async function initializeApi() {
  startRelay();
  void fetchPrices();
  preloadFioResponses();
  listenPrunApi();
  const startupStores = [
    alertsStore,
    balancesStore,
    contractsStore,
    flightsStore,
    materialsStore,
    shipsStore,
    sitesStore,
    starsStore,
    storagesStore,
    warehousesStore
  ];
  await watchUntil(
    () => uiDataStore.screens !== void 0 && companyStore.value !== void 0 && startupStores.every((x) => x.fetched.value)
  );
  await loadFallbackPlanetData();
}
function finishApiInitialization() {
  initialApiLoadingComplete.value = true;
}
export {
  finishApiInitialization,
  initializeApi
};
