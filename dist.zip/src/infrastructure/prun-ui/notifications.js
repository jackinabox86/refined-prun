import { $ } from "../../utils/select-dom.js";
import { C } from "./prun-css.js";
import oneMutation from "../../../npm/one-mutation@3.0.1-one-mutation.js";
async function waitNotificationLoaded(container) {
  const content = await $(container, C.AlertListItem.content);
  const isLoaded = () => !content.textContent?.includes("…");
  if (!isLoaded()) {
    await oneMutation(content, {
      childList: true,
      subtree: true,
      characterData: true,
      filter: isLoaded
    });
  }
  return content;
}
export {
  waitNotificationLoaded
};
