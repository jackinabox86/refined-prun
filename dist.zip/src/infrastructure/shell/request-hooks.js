import { sitesStore } from "../prun-api/data/sites.js";
import { getEntityNaturalIdFromAddress } from "../prun-api/data/addresses.js";
import { implementRequestHooks } from "../prun-api/data/request-hooks.js";
import { showBuffer } from "../prun-ui/buffers.js";
import { onApiMessage } from "../prun-api/data/api-messages.js";
import { cxosStore } from "../prun-api/data/cxos.js";
import { fxosStore } from "../prun-api/data/fxos.js";
import { blueprintsStore } from "../prun-api/data/blueprints.js";
import { shipyardsStore } from "../prun-api/data/shipyards.js";
import { shipyardProjectsStore } from "../prun-api/data/shipyard-projects.js";
import { computed } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
const bs = /* @__PURE__ */ new Set();
onApiMessage({
  CLIENT_CONNECTION_OPENED() {
    bs.clear();
  }
});
function requestBS(siteId) {
  const site = sitesStore.getById(siteId);
  if (!site) {
    return;
  }
  if (bs.has(site.siteId)) {
    return;
  }
  bs.add(site.siteId);
  const naturalId = getEntityNaturalIdFromAddress(site.address);
  singleBufferRequest(`BS ${naturalId}`, () => sitesStore.getById(siteId) !== void 0)();
}
function singleBufferRequest(command, closeWhen) {
  let requested = false;
  onApiMessage({
    CLIENT_CONNECTION_OPENED() {
      requested = false;
    }
  });
  return function request() {
    if (requested) {
      return;
    }
    requested = true;
    showBuffer(command, { autoClose: true, closeWhen: computed(closeWhen) });
  };
}
implementRequestHooks({
  production: requestBS,
  workforce: requestBS,
  cxos: singleBufferRequest("CXOS", () => cxosStore.fetched.value),
  fxos: singleBufferRequest("FXOS", () => fxosStore.fetched.value),
  blueprints: singleBufferRequest("BLU", () => blueprintsStore.fetched.value),
  shipyards: singleBufferRequest("SHY", () => shipyardsStore.fetched.value),
  shipyardProjects: singleBufferRequest("SHYP", () => shipyardProjectsStore.fetched.value)
});
