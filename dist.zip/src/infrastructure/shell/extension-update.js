import config from "./config.js";
import { C } from "../prun-ui/prun-css.js";
import { createFragmentApp } from "../../utils/vue-fragment-app.js";
import { fetchJson } from "../../utils/fetch.js";
import { createVNode, createTextVNode } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
{
  const container = document.getElementById("container");
  const id = setInterval(async () => {
    let manifest;
    try {
      manifest = await fetchJson(config.url.manifest);
    } catch {
      clearInterval(id);
      return;
    }
    if (!manifest.version || config.version === manifest.version) {
      return;
    }
    void setTimeout(() => window.location.reload(), 3e3);
    clearInterval(id);
    if (C.Connecting === void 0) {
      return;
    }
    createFragmentApp(() => createVNode("div", {
      "class": [C.Connecting.processing, C.Connecting.overlay],
      "style": {
        zIndex: "999999"
      }
    }, [createVNode("span", {
      "class": [C.Connecting.message, C.fonts.fontRegular, C.type.typeLarger]
    }, [createTextVNode("Reloading Refined PrUn...")])])).appendTo(container);
  }, 1e3);
}
