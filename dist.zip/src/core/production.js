import { sitesStore } from "../infrastructure/prun-api/data/sites.js";
import { productionStore } from "../infrastructure/prun-api/data/production.js";
import { storagesStore } from "../infrastructure/prun-api/data/storage.js";
import { getEntityNaturalIdFromAddress, getEntityNameFromAddress } from "../infrastructure/prun-api/data/addresses.js";
import { computed } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
const productionMap = computed(() => {
  const allSites = sitesStore.all.value;
  if (!allSites) {
    return {};
  }
  const result = {};
  for (const site of allSites) {
    const id = site.siteId;
    const lines = productionStore.getBySiteId(id) ?? [];
    const storage = storagesStore.getByAddressableId(id);
    const production = lines.map((line) => {
      const platform = site.platforms.find((x) => x.module.reactorName === line.type);
      const activeOrders = line.orders.filter((x) => x.started !== null && !x.halted);
      const queuedOrders = line.orders.filter((x) => x.started === null || x.halted);
      return {
        id: line.id,
        reactorTicker: platform?.module.reactorTicker ?? line.type,
        capacity: line.capacity,
        activeCapacity: activeOrders.length,
        inactiveCapacity: Math.max(0, line.capacity - activeOrders.length),
        condition: line.condition,
        efficiency: line.efficiency,
        efficiencyFactors: line.efficiencyFactors,
        orders: activeOrders,
        queuedOrders
      };
    });
    result[id] = {
      storeId: storage?.find((x) => x.type === "STORE")?.id ?? "",
      planetName: getEntityNameFromAddress(site.address) ?? "",
      naturalId: getEntityNaturalIdFromAddress(site.address) ?? "",
      site,
      platforms: site.platforms,
      lines,
      production
    };
  }
  return result;
});
function getPlanetProduction(siteOrId) {
  const siteId = typeof siteOrId === "string" ? siteOrId : siteOrId?.siteId;
  if (!siteId) {
    return void 0;
  }
  return productionMap.value[siteId] ?? void 0;
}
export {
  getPlanetProduction
};
