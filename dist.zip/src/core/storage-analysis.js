import { getPlanetBurn, computeNeed } from "./burn.js";
import { storagesStore } from "../infrastructure/prun-api/data/storage.js";
import { sitesStore } from "../infrastructure/prun-api/data/sites.js";
import { materialsStore } from "../infrastructure/prun-api/data/materials.js";
import { getEntityNaturalIdFromAddress, getEntityNameFromAddress } from "../infrastructure/prun-api/data/addresses.js";
import { userData } from "../store/user-data.js";
import { computed } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
const analysisBySiteId = computed(() => {
  if (!sitesStore.all.value) {
    return void 0;
  }
  const bySiteId = /* @__PURE__ */ new Map();
  for (const site of sitesStore.all.value) {
    bySiteId.set(
      site.siteId,
      computed(() => computeAnalysis(site))
    );
  }
  return bySiteId;
});
function computeAnalysis(site) {
  const storage = storagesStore.getByAddressableId(site.siteId);
  const store = storage?.find((x) => x.type === "STORE");
  if (!store) {
    return void 0;
  }
  const planetBurn = getPlanetBurn(site);
  const resupplyDays = userData.settings.burn.resupply;
  let importWeight = 0;
  let importVolume = 0;
  let exportWeight = 0;
  let exportVolume = 0;
  let infWeight = 0;
  let infVolume = 0;
  let addedWeight = 0;
  let addedVolume = 0;
  let shippedOutWeight = 0;
  let shippedOutVolume = 0;
  let consumerInventoryWeight = 0;
  let consumerInventoryVolume = 0;
  if (planetBurn) {
    for (const ticker of Object.keys(planetBurn.burn)) {
      const mat = materialsStore.getByTicker(ticker);
      if (!mat) {
        continue;
      }
      const mb = planetBurn.burn[ticker];
      const daily = mb.dailyAmount;
      if (daily < 0) {
        const consumption = -daily;
        importWeight += consumption * mat.weight;
        importVolume += consumption * mat.volume;
        consumerInventoryWeight += mb.inventory * mat.weight;
        consumerInventoryVolume += mb.inventory * mat.volume;
      } else {
        exportWeight += daily * mat.weight;
        exportVolume += daily * mat.volume;
        infWeight += mb.inventory * mat.weight;
        infVolume += mb.inventory * mat.volume;
      }
      if (daily > 0) {
        shippedOutWeight += mb.inventory * mat.weight;
        shippedOutVolume += mb.inventory * mat.volume;
      }
      const need = computeNeed(mb, resupplyDays);
      if (need > 0) {
        addedWeight += need * mat.weight;
        addedVolume += need * mat.volume;
      }
    }
  }
  const fillPercentWeight = store.weightCapacity > 0 ? store.weightLoad / store.weightCapacity : 0;
  const fillPercentVolume = store.volumeCapacity > 0 ? store.volumeLoad / store.volumeCapacity : 0;
  const fillPercentWeightNoInf = store.weightCapacity > 0 ? Math.max(store.weightLoad - infWeight, 0) / store.weightCapacity : 0;
  const fillPercentVolumeNoInf = store.volumeCapacity > 0 ? Math.max(store.volumeLoad - infVolume, 0) / store.volumeCapacity : 0;
  const needFillPercentWeight = store.weightCapacity > 0 ? (store.weightLoad + addedWeight) / store.weightCapacity : 0;
  const needFillPercentVolume = store.volumeCapacity > 0 ? (store.volumeLoad + addedVolume) / store.volumeCapacity : 0;
  const needFillRatio = Math.max(needFillPercentWeight, needFillPercentVolume);
  const availableWeight = Math.max(store.weightCapacity - store.weightLoad, 0);
  const availableVolume = Math.max(store.volumeCapacity - store.volumeLoad, 0);
  const netWeight = exportWeight - importWeight;
  const netVolume = exportVolume - importVolume;
  const daysW = netWeight > 0 ? availableWeight / netWeight : Infinity;
  const daysV = netVolume > 0 ? availableVolume / netVolume : Infinity;
  const daysUntilFull = Math.min(daysW, daysV);
  const bindingLimit = daysUntilFull === Infinity ? void 0 : daysW < daysV ? "t" : "m³";
  const availableAfterShipOutWeight = Math.max(
    store.weightCapacity - store.weightLoad + shippedOutWeight,
    0
  );
  const availableAfterShipOutVolume = Math.max(
    store.volumeCapacity - store.volumeLoad + shippedOutVolume,
    0
  );
  const suppliesReserveFraction = daysUntilFull === Infinity ? 0.05 : 0.2;
  const idleNonConsumableWeight = Math.max(
    store.weightLoad - shippedOutWeight - consumerInventoryWeight,
    0
  );
  const idleNonConsumableVolume = Math.max(
    store.volumeLoad - shippedOutVolume - consumerInventoryVolume,
    0
  );
  const consumableCapWeight = Math.max(
    store.weightCapacity * (1 - suppliesReserveFraction) - idleNonConsumableWeight,
    0
  );
  const consumableCapVolume = Math.max(
    store.volumeCapacity * (1 - suppliesReserveFraction) - idleNonConsumableVolume,
    0
  );
  const daysFitW = importWeight > 0 ? consumableCapWeight / importWeight : Infinity;
  const daysFitV = importVolume > 0 ? consumableCapVolume / importVolume : Infinity;
  const daysOfSuppliesFit = Math.min(daysFitW, daysFitV);
  return {
    siteId: site.siteId,
    storeId: store.id,
    planetName: getEntityNameFromAddress(site.address) ?? "",
    naturalId: getEntityNaturalIdFromAddress(site.address) ?? "",
    weightCapacity: store.weightCapacity,
    weightLoad: store.weightLoad,
    volumeCapacity: store.volumeCapacity,
    volumeLoad: store.volumeLoad,
    importWeight,
    importVolume,
    exportWeight,
    exportVolume,
    fillPercentWeight,
    fillPercentVolume,
    fillPercentWeightNoInf,
    fillPercentVolumeNoInf,
    needFillPercentWeight,
    needFillPercentVolume,
    needFillRatio,
    availableAfterShipOutWeight,
    availableAfterShipOutVolume,
    daysOfSuppliesFit,
    suppliesReserveFraction,
    daysUntilFull,
    bindingLimit
  };
}
function getBaseStorageAnalysis(siteOrId) {
  const site = typeof siteOrId === "string" ? sitesStore.getById(siteOrId) : siteOrId;
  if (!site) {
    return void 0;
  }
  return analysisBySiteId.value?.get(site.siteId)?.value;
}
function buildProjectedStore(siteOrId) {
  const site = typeof siteOrId === "string" ? sitesStore.getById(siteOrId) : siteOrId;
  if (!site) {
    return void 0;
  }
  const storage = storagesStore.getByAddressableId(site.siteId);
  const store = storage?.find((x) => x.type === "STORE");
  if (!store) {
    return void 0;
  }
  const planetBurn = getPlanetBurn(site);
  const resupplyDays = userData.settings.burn.resupply;
  const items = [];
  let weightLoad = 0;
  let volumeLoad = 0;
  const producedTickers = /* @__PURE__ */ new Set();
  if (planetBurn) {
    for (const ticker of Object.keys(planetBurn.burn)) {
      if (planetBurn.burn[ticker].dailyAmount > 0) {
        producedTickers.add(ticker);
      }
    }
  }
  for (const item of store.items) {
    if (item.type === "SHIPMENT") {
      items.push(item);
      weightLoad += item.weight;
      volumeLoad += item.volume;
      continue;
    }
    const ticker = item.quantity?.material.ticker;
    if (ticker && producedTickers.has(ticker)) {
      continue;
    }
    items.push(item);
    weightLoad += item.weight;
    volumeLoad += item.volume;
  }
  if (planetBurn) {
    for (const ticker of Object.keys(planetBurn.burn)) {
      const mb = planetBurn.burn[ticker];
      const need = computeNeed(mb, resupplyDays);
      if (need <= 0) {
        continue;
      }
      const material = materialsStore.getByTicker(ticker);
      if (!material) {
        continue;
      }
      const addedWeight = need * material.weight;
      const addedVolume = need * material.volume;
      items.push({
        id: `projected-${ticker}`,
        type: "INVENTORY",
        weight: addedWeight,
        volume: addedVolume,
        quantity: {
          material,
          amount: need,
          value: { amount: 0, currency: "NCC" }
        }
      });
      weightLoad += addedWeight;
      volumeLoad += addedVolume;
    }
  }
  return {
    ...store,
    items,
    weightLoad,
    volumeLoad
  };
}
export {
  buildProjectedStore,
  getBaseStorageAnalysis
};
