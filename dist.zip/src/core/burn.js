import { sumBy } from "../utils/sum-by.js";
import { productionStore } from "../infrastructure/prun-api/data/production.js";
import { workforcesStore } from "../infrastructure/prun-api/data/workforces.js";
import { storagesStore } from "../infrastructure/prun-api/data/storage.js";
import { sitesStore } from "../infrastructure/prun-api/data/sites.js";
import { shipsStore } from "../infrastructure/prun-api/data/ships.js";
import { flightsStore } from "../infrastructure/prun-api/data/flights.js";
import { getEntityNaturalIdFromAddress, getEntityNameFromAddress } from "../infrastructure/prun-api/data/addresses.js";
import { getRecurringOrders } from "./orders.js";
import { computed } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { ref } from "../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const burnBySiteId = computed(() => {
  if (!sitesStore.all.value) {
    return void 0;
  }
  const bySiteId = /* @__PURE__ */ new Map();
  for (const site of sitesStore.all.value) {
    bySiteId.set(
      site.siteId,
      computed(() => {
        const id = site.siteId;
        const workforce = workforcesStore.getById(id)?.workforces;
        const production = productionStore.getBySiteId(id);
        const storage = storagesStore.getByAddressableId(id);
        if (!workforce || !production) {
          return void 0;
        }
        const naturalId = getEntityNaturalIdFromAddress(site.address);
        const inboundStores = getInboundShipStores(naturalId);
        const combinedStorage = [...storage ?? [], ...inboundStores];
        return {
          storeId: storage?.[0]?.id,
          planetName: getEntityNameFromAddress(site.address),
          naturalId,
          burn: calculatePlanetBurn(production, workforce, combinedStorage)
        };
      })
    );
  }
  return bySiteId;
});
function getInboundShipStores(planetNaturalId) {
  if (!inboundShipInventoryEnabled.value) {
    return [];
  }
  if (!planetNaturalId) {
    return [];
  }
  const ships = shipsStore.all.value;
  const stores = storagesStore.all.value;
  if (!ships || !stores) {
    return [];
  }
  const result = [];
  for (const ship of ships) {
    if (!ship.flightId) {
      continue;
    }
    const flight = flightsStore.getById(ship.flightId);
    if (!flight) {
      continue;
    }
    if (getEntityNaturalIdFromAddress(flight.destination) !== planetNaturalId) {
      continue;
    }
    const shipStore = stores.find((x) => x.id === ship.idShipStore);
    if (shipStore) {
      result.push(shipStore);
    }
  }
  return result;
}
const inboundShipInventoryEnabled = ref(false);
function setInboundShipInventoryEnabled(value) {
  inboundShipInventoryEnabled.value = value;
}
function getPlanetBurn(siteOrId) {
  const site = typeof siteOrId === "string" ? sitesStore.getById(siteOrId) : siteOrId;
  if (!site) {
    return void 0;
  }
  return burnBySiteId.value?.get(site.siteId)?.value;
}
function calculatePlanetBurn(production, workforces, storage) {
  const burnValues = {};
  function getBurnValue(ticker) {
    burnValues[ticker] ??= {
      input: 0,
      output: 0,
      workforce: 0,
      dailyAmount: 0,
      inventory: 0,
      daysLeft: 0,
      type: "output"
    };
    return burnValues[ticker];
  }
  if (production) {
    for (const line of production) {
      const capacity = line.capacity;
      const burnOrders = getRecurringOrders(line);
      let totalDuration = sumBy(burnOrders, (x) => x.duration?.millis ?? Infinity);
      totalDuration /= 864e5;
      for (const order of burnOrders) {
        for (const mat of order.outputs) {
          const materialBurn = getBurnValue(mat.material.ticker);
          materialBurn.output += mat.amount * capacity / totalDuration;
        }
        for (const mat of order.inputs) {
          const materialBurn = getBurnValue(mat.material.ticker);
          materialBurn.input += mat.amount * capacity / totalDuration;
        }
      }
    }
  }
  if (workforces) {
    for (const tier of workforces) {
      if (tier.population <= 1) {
        continue;
      }
      if (tier.capacity === 0) {
        continue;
      }
      for (const need of tier.needs) {
        const materialBurn = getBurnValue(need.material.ticker);
        materialBurn.workforce += need.unitsPerInterval;
      }
    }
  }
  for (const ticker of Object.keys(burnValues)) {
    const burnValue = burnValues[ticker];
    burnValue.dailyAmount = burnValue.output;
    burnValue.type = "output";
    burnValue.dailyAmount -= burnValue.workforce;
    if (burnValue.workforce > 0 && burnValue.dailyAmount <= 0) {
      burnValue.type = "workforce";
    }
    burnValue.dailyAmount -= burnValue.input;
    if (burnValue.input > 0 && burnValue.dailyAmount <= 0) {
      burnValue.type = "input";
    }
  }
  if (storage) {
    for (const inventory of storage) {
      for (const item of inventory.items) {
        const quantity = item.quantity;
        if (!quantity) {
          continue;
        }
        const materialBurn = burnValues[quantity.material.ticker];
        if (materialBurn === void 0) {
          continue;
        }
        materialBurn.inventory += quantity.amount;
        if (quantity.amount != 0) {
          materialBurn.daysLeft = materialBurn.dailyAmount > 0 ? 1e3 : Math.floor(-materialBurn.inventory / materialBurn.dailyAmount);
        }
      }
    }
  }
  return burnValues;
}
function computeNeed(mat, resupplyDays) {
  const production = mat.dailyAmount;
  const isInf = production >= 0;
  const days = isInf ? 1e3 : mat.daysLeft;
  if (days > resupplyDays || production > 0) {
    return 0;
  }
  const need = Math.ceil((days - resupplyDays) * production);
  return need === 0 ? 0 : need;
}
export {
  calculatePlanetBurn,
  computeNeed,
  getPlanetBurn,
  setInboundShipInventoryEnabled
};
