const stationaryShipStatusIcon = "⦁";
const shipStatusIconBySegmentType = {
  TAKE_OFF: "↑",
  DEPARTURE: "↗",
  TRANSIT: "⟶",
  CHARGE: "±",
  JUMP: "➾",
  FLOAT: "↑",
  APPROACH: "↘",
  LANDING: "↓",
  LOCK: "⟴",
  DECAY: "⟴",
  JUMP_GATEWAY: "⟴"
};
const shipStatusI18nIconReplacements = [
  {
    key: "ships.status.stationary",
    icon: stationaryShipStatusIcon
  },
  {
    key: "ShipStatus.takeoff",
    icon: shipStatusIconBySegmentType.TAKE_OFF
  },
  {
    key: "ShipStatus.departure",
    icon: shipStatusIconBySegmentType.DEPARTURE
  },
  {
    key: "ShipStatus.transit",
    icon: shipStatusIconBySegmentType.TRANSIT
  },
  {
    key: "ShipStatus.charge",
    icon: shipStatusIconBySegmentType.CHARGE
  },
  {
    key: "ShipStatus.jump",
    icon: shipStatusIconBySegmentType.JUMP
  },
  {
    key: "ShipStatus.float",
    icon: shipStatusIconBySegmentType.FLOAT
  },
  {
    key: "ShipStatus.approach",
    icon: shipStatusIconBySegmentType.APPROACH
  },
  {
    key: "ShipStatus.landing",
    icon: shipStatusIconBySegmentType.LANDING
  },
  {
    key: "ShipStatus.lock",
    icon: shipStatusIconBySegmentType.LOCK
  },
  {
    key: "ShipStatus.decay",
    icon: shipStatusIconBySegmentType.DECAY
  },
  {
    key: "ShipStatus.jumpgateway",
    icon: shipStatusIconBySegmentType.JUMP_GATEWAY
  }
];
function getShipStatusIcon(segmentType) {
  return shipStatusIconBySegmentType[segmentType] ?? "?";
}
export {
  getShipStatusIcon,
  shipStatusI18nIconReplacements,
  shipStatusIconBySegmentType,
  stationaryShipStatusIcon
};
