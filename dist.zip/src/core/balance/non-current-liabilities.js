import { sumAccountsPayable, selfNonCurrentConditions, sumFactionProvisions, sumProvisions, sumDeliveries, sumLoanRepayments } from "./contract-conditions.js";
import { sum } from "../../utils/sum.js";
import { computed } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
const accountsPayable = computed(() => sumAccountsPayable(selfNonCurrentConditions));
const materialsPayable = computed(
  () => sum(
    sumDeliveries(selfNonCurrentConditions),
    sumProvisions(selfNonCurrentConditions),
    sumFactionProvisions(selfNonCurrentConditions)
  )
);
const longTermDebt = computed(() => sumLoanRepayments(selfNonCurrentConditions));
const nonCurrentLiabilities = {
  accountsPayable,
  materialsPayable,
  longTermDebt
};
export {
  nonCurrentLiabilities
};
