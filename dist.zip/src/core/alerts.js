import { alertsStore } from "../infrastructure/prun-api/data/alerts.js";
import { userDataStore } from "../infrastructure/prun-api/data/user-data.js";
import { computed } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
const reachableContextIds = computed(() => new Set(userDataStore.contexts.map((x) => x.id)));
const reachableAlerts = computed(
  () => alertsStore.all.value?.filter((x) => reachableContextIds.value.has(x.contextId))
);
export {
  reachableAlerts
};
