import { productionStore } from "../infrastructure/prun-api/data/production.js";
import { userDataStore } from "../infrastructure/prun-api/data/user-data.js";
import { computed } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function isFiniteOrder(order) {
  return order.amount !== null;
}
const hasRecurringOrders = computed(() => {
  if (userDataStore.subscriptionLevel !== "PRO") {
    return false;
  }
  return productionStore.all.value?.some((line) => line.orders.some((x) => x.recurring)) ?? false;
});
function getRecurringOrders(line) {
  return hasRecurringOrders.value ? line.orders.filter((x) => !x.started && x.recurring) : line.orders.filter((x) => !x.started);
}
export {
  getRecurringOrders,
  isFiniteOrder
};
