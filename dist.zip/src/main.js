import { createFragmentApp } from "./utils/vue-fragment-app.js";
import { $ } from "./utils/select-dom.js";
import { C } from "./infrastructure/prun-ui/prun-css.js";
import config from "./infrastructure/shell/config.js";
import features from "./features/feature-registry.js";
import xit from "./features/XIT/xit-registry.js";
import { initializeApi, finishApiInitialization } from "./infrastructure/prun-api/index.js";
import { initializeUI } from "./infrastructure/prun-ui/index.js";
import { initializeUserData } from "./store/index.js";
import { initAudioInterceptor } from "./infrastructure/prun-ui/audio-interceptor.js";
import _sfc_main from "./components/PmmgMigrationGuide.vue.js";
async function main() {
  try {
    initAudioInterceptor();
    await initializeApi();
    await initializeUI();
    if (window["PMMG_COLLECTOR_HAS_RUN"]) {
      createFragmentApp(_sfc_main).before(await $(document, C.App.container));
      finishApiInitialization();
      return;
    }
    console.log(`Refined PrUn ${config.version}`);
    initializeUserData();
    features.init();
    xit.init();
  } finally {
    finishApiInitialization();
  }
}
void main();
