import _sfc_main from "./REP.vue.js";
export {
  _sfc_main as default
};
