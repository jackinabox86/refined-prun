import _sfc_main from "./RepairActWindow.vue.js";
export {
  _sfc_main as default
};
