import xit from "../xit-registry.js";
import "../ACT/actions/cx-buy/cx-buy.js";
import "../ACT/actions/mtra/mtra.js";
import "../ACT/material-groups/repair/repair.js";
import _sfc_main from "./RepairActWindow.vue.js";
import { sitesStore } from "../../../infrastructure/prun-api/data/sites.js";
import { getEntityNameFromAddress } from "../../../infrastructure/prun-api/data/addresses.js";
xit.add({
  command: "REPAIRACT",
  name: (parameters) => {
    if (parameters[0]) {
      const site = sitesStore.getByPlanetNaturalIdOrName(parameters[0]);
      const name = site ? getEntityNameFromAddress(site.address) : parameters[0];
      return `REPAIR ACTION - ${name}`;
    }
    return "REPAIR ACTION";
  },
  description: "Executes a repair action package for a planet using XIT REP settings.",
  component: () => _sfc_main
});
