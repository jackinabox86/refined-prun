import _sfc_main$1 from "../../../components/forms/NumberInput.vue.js";
import { getParameterSites, getParameterShips, calculateBuildingEntries, calculateShipEntries } from "./entries.js";
import { timestampEachMinute } from "../../../utils/dayjs.js";
import { binarySearch } from "../../../utils/binary-search.js";
import dayjs from "../../../../npm/dayjs@1.11.18-dayjs-dayjs.min.js";
import { fixed1, percent1 } from "../../../utils/format.js";
import MaterialPurchaseTable from "../../../components/MaterialPurchaseTable.vue.js";
import LoadingSpinner from "../../../components/LoadingSpinner.vue.js";
import { calcBuildingCondition } from "../../../core/buildings.js";
import { diffDays } from "../../../utils/time-diff.js";
import { userData } from "../../../store/user-data.js";
import { mergeMaterialAmounts } from "../../../core/sort-materials.js";
import _sfc_main$2 from "../../../components/forms/Active.vue.js";
import SectionHeader from "../../../components/SectionHeader.vue.js";
import { useXitParameters } from "../../../hooks/use-xit-parameters.js";
import PrunLink from "../../../components/PrunLink.vue.js";
import _sfc_main$3 from "../../../components/PrunButton.vue.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import { repairButtonEnabled } from "./repair-button.js";
import { objectId } from "../../../utils/object-id.js";
import { defineComponent, computed, openBlock, createBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, createCommentVNode, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _hoisted_2 = { key: 1 };
const _hoisted_3 = { key: 0 };
const _hoisted_4 = { key: 1 };
const _hoisted_5 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "REP",
  setup(__props) {
    const parameters = useXitParameters();
    const sites = computed(() => getParameterSites(parameters));
    const ships = computed(() => getParameterShips(parameters));
    const isMultiTarget = computed(
      () => (sites.value?.length ?? 0) > 1 || (ships.value?.length ?? 0) > 0
    );
    const buildingEntries = computed(() => calculateBuildingEntries(sites.value));
    const shipEntries = computed(() => calculateShipEntries(ships.value));
    const msInADay = dayjs.duration(1, "day").asMilliseconds();
    const currentSplitIndex = computed(() => {
      if (buildingEntries.value === void 0) {
        return void 0;
      }
      const settings = userData.settings.repair;
      const currentSplitDate = timestampEachMinute.value - settings.threshold * msInADay + settings.offset * msInADay;
      return binarySearch(currentSplitDate, buildingEntries.value, (x) => x.lastRepair);
    });
    const visibleBuildings = computed(() => {
      return buildingEntries.value?.slice(0, currentSplitIndex.value);
    });
    const visibleShips = computed(() => shipEntries.value?.filter((x) => x.condition <= 0.85));
    const materials = computed(() => {
      if (visibleBuildings.value === void 0 || visibleShips.value === void 0) {
        return void 0;
      }
      const materials2 = [];
      const time = timestampEachMinute.value;
      for (const building of visibleBuildings.value) {
        const plannedRepairDate = (time - building.lastRepair) / msInADay + userData.settings.repair.offset;
        for (const { material, amount } of building.fullMaterials) {
          materials2.push({
            material,
            amount: Math.ceil(amount * (1 - calcBuildingCondition(plannedRepairDate)))
          });
        }
      }
      materials2.push(...visibleShips.value.flatMap((x) => x.materials));
      return mergeMaterialAmounts(materials2);
    });
    function calculateAge(lastRepair) {
      return diffDays(lastRepair, timestampEachMinute.value, true);
    }
    return (_ctx, _cache) => {
      return unref(materials) === void 0 ? (openBlock(), createBlock(LoadingSpinner, { key: 0 })) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
        createBaseVNode("form", null, [
          createVNode(_sfc_main$2, { label: "Age Threshold" }, {
            default: withCtx(() => [
              createVNode(_sfc_main$1, {
                modelValue: unref(userData).settings.repair.threshold,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => unref(userData).settings.repair.threshold = $event)
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$2, { label: "Time Offset" }, {
            default: withCtx(() => [
              createVNode(_sfc_main$1, {
                modelValue: unref(userData).settings.repair.offset,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => unref(userData).settings.repair.offset = $event)
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          })
        ]),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[2] || (_cache[2] = [
            createTextVNode("Shopping Cart", -1)
          ])]),
          _: 1
        }),
        createVNode(MaterialPurchaseTable, {
          collapsible: unref(isMultiTarget),
          "collapsed-by-default": true,
          materials: unref(materials)
        }, null, 8, ["collapsible", "materials"]),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[3] || (_cache[3] = [
            createTextVNode("Buildings", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              _cache[4] || (_cache[4] = createBaseVNode("th", null, "Ticker", -1)),
              unref(isMultiTarget) ? (openBlock(), createElementBlock("th", _hoisted_1, "Target")) : createCommentVNode("", true),
              _cache[5] || (_cache[5] = createBaseVNode("th", null, "Age (days)", -1)),
              _cache[6] || (_cache[6] = createBaseVNode("th", null, "Condition", -1)),
              unref(repairButtonEnabled) ? (openBlock(), createElementBlock("th", _hoisted_2, "CMD")) : createCommentVNode("", true)
            ])
          ]),
          createBaseVNode("tbody", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(visibleBuildings), (entry) => {
              return openBlock(), createElementBlock("tr", {
                key: unref(objectId)(entry)
              }, [
                createBaseVNode("td", null, toDisplayString(entry.ticker), 1),
                unref(isMultiTarget) ? (openBlock(), createElementBlock("td", _hoisted_3, [
                  createVNode(PrunLink, {
                    command: `XIT REP ${entry.naturalId}`
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(entry.target), 1)
                    ]),
                    _: 2
                  }, 1032, ["command"])
                ])) : createCommentVNode("", true),
                createBaseVNode("td", null, toDisplayString(unref(fixed1)(calculateAge(entry.lastRepair))), 1),
                createBaseVNode("td", null, toDisplayString(unref(percent1)(entry.condition)), 1),
                unref(repairButtonEnabled) ? (openBlock(), createElementBlock("td", _hoisted_4, [
                  createVNode(_sfc_main$3, {
                    dark: "",
                    inline: "",
                    onClick: ($event) => unref(showBuffer)(`XIT REPAIRACT ${entry.naturalId}`)
                  }, {
                    default: withCtx(() => [..._cache[7] || (_cache[7] = [
                      createTextVNode(" REP ", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ])) : createCommentVNode("", true)
              ]);
            }), 128)),
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(visibleShips), (entry) => {
              return openBlock(), createElementBlock("tr", {
                key: unref(objectId)(entry)
              }, [
                _cache[8] || (_cache[8] = createBaseVNode("td", null, "(Ship)", -1)),
                createBaseVNode("td", null, toDisplayString(entry.target), 1),
                createBaseVNode("td", null, toDisplayString(unref(fixed1)(calculateAge(entry.lastRepair))), 1),
                createBaseVNode("td", null, toDisplayString(unref(percent1)(entry.condition)), 1),
                unref(repairButtonEnabled) ? (openBlock(), createElementBlock("td", _hoisted_5)) : createCommentVNode("", true)
              ]);
            }), 128))
          ])
        ])
      ], 64));
    };
  }
});
export {
  _sfc_main as default
};
