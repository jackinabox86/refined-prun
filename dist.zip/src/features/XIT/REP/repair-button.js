import { ref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const repairButtonEnabled = ref(false);
function setRepairButtonEnabled(value) {
  repairButtonEnabled.value = value;
}
export {
  repairButtonEnabled,
  setRepairButtonEnabled
};
