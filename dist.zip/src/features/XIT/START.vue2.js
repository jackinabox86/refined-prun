import PrunLink from "../../components/PrunLink.vue.js";
import _sfc_main$1 from "../../components/PrunButton.vue.js";
import { userData } from "../../store/user-data.js";
import { saveUserData } from "../../infrastructure/storage/user-data-serializer.js";
import { defineComponent, openBlock, createElementBlock, createElementVNode as createBaseVNode, createTextVNode, createVNode, Fragment, withCtx } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { ref, unref } from "../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { normalizeClass } from "../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _hoisted_1 = { key: 1 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "START",
  setup(__props) {
    const needsToChoose = ref(userData.settings.mode === void 0);
    function onBasicClick() {
      needsToChoose.value = false;
      userData.settings.mode = "BASIC";
    }
    async function onFullClick() {
      needsToChoose.value = false;
      userData.settings.mode = "FULL";
      await saveUserData();
      window.location.reload();
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(_ctx.$style.container)
      }, [
        createBaseVNode("h1", {
          class: normalizeClass(_ctx.$style.title)
        }, "Thank you for using Refined PrUn!", 2),
        createBaseVNode("p", null, [
          _cache[0] || (_cache[0] = createTextVNode(" You can find a list of all of the XIT commands using ", -1)),
          createVNode(PrunLink, {
            inline: "",
            command: "XIT CMDS"
          })
        ]),
        createBaseVNode("p", null, [
          _cache[1] || (_cache[1] = createTextVNode(" You can change settings using ", -1)),
          createVNode(PrunLink, {
            inline: "",
            command: "XIT SET"
          })
        ]),
        createBaseVNode("p", null, [
          _cache[2] || (_cache[2] = createTextVNode(" For additional help, check ", -1)),
          createVNode(PrunLink, {
            inline: "",
            command: "XIT HELP"
          })
        ]),
        unref(needsToChoose) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
          createBaseVNode("p", null, [
            _cache[3] || (_cache[3] = createTextVNode(" Please select a feature set (you can change it later using ", -1)),
            createVNode(PrunLink, {
              inline: "",
              command: "XIT SET FEAT"
            }),
            _cache[4] || (_cache[4] = createTextVNode(" ) ", -1))
          ]),
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.features)
          }, [
            createVNode(_sfc_main$1, {
              primary: "",
              class: normalizeClass(_ctx.$style.feature),
              onClick: onBasicClick
            }, {
              default: withCtx(() => [
                createBaseVNode("div", {
                  class: normalizeClass(_ctx.$style.featureTitle)
                }, [
                  createBaseVNode("div", {
                    class: normalizeClass(_ctx.$style.title)
                  }, "BASIC", 2)
                ], 2),
                createBaseVNode("div", {
                  class: normalizeClass(_ctx.$style.featureDescription)
                }, "Includes features to enhance the APEX UI", 2)
              ]),
              _: 1
            }, 8, ["class"]),
            createVNode(_sfc_main$1, {
              primary: "",
              class: normalizeClass(_ctx.$style.feature),
              onClick: onFullClick
            }, {
              default: withCtx(() => [
                createBaseVNode("div", {
                  class: normalizeClass(_ctx.$style.featureTitle)
                }, [
                  createBaseVNode("div", {
                    class: normalizeClass(_ctx.$style.title)
                  }, "FULL", 2),
                  _cache[5] || (_cache[5] = createBaseVNode("div", null, "(requires restart)", -1))
                ], 2),
                createBaseVNode("div", {
                  class: normalizeClass(_ctx.$style.featureDescription)
                }, " Includes all Basic features plus additional UI refinements for experienced players ", 2)
              ]),
              _: 1
            }, 8, ["class"])
          ], 2)
        ], 64)) : (openBlock(), createElementBlock("p", _hoisted_1, [
          _cache[6] || (_cache[6] = createTextVNode(" You can change the feature set at any time using ", -1)),
          createVNode(PrunLink, {
            inline: "",
            command: "XIT SET FEAT"
          })
        ]))
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
