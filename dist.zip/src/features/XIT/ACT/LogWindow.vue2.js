import { useCssModule } from "../../../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import { objectId } from "../../../utils/object-id.js";
import { defineComponent, useTemplateRef, watch, openBlock, createElementBlock, Fragment, renderList, createCommentVNode, nextTick } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = { key: 1 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "LogWindow",
  props: {
    messages: {},
    scrolling: { type: Boolean }
  },
  setup(__props) {
    const $style = useCssModule();
    const logElement = useTemplateRef("log");
    watch(
      () => __props.messages,
      () => {
        if (__props.messages.length === 0 || !__props.scrolling) {
          return;
        }
        if (logElement.value) {
          nextTick(
            () => logElement.value?.scrollTo({ top: logElement.value.scrollHeight, behavior: "smooth" })
          );
        }
      },
      { deep: true }
    );
    function getTagClass(tag) {
      switch (tag) {
        case "ACTION":
        case "SUCCESS":
          return $style.success;
        case "WARNING":
        case "SKIP":
          return $style.warning;
        case "ERROR":
        case "CANCEL":
          return $style.failure;
      }
      return void 0;
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        ref: "log",
        class: normalizeClass([unref($style).log, ("C" in _ctx ? _ctx.C : unref(C)).fonts.fontRegular])
      }, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.messages, (message) => {
          return openBlock(), createElementBlock("div", {
            key: unref(objectId)(message)
          }, [
            message.tag ? (openBlock(), createElementBlock("b", {
              key: 0,
              class: normalizeClass(getTagClass(message.tag))
            }, toDisplayString(message.tag) + ": ", 3)) : createCommentVNode("", true),
            typeof message.message === "string" ? (openBlock(), createElementBlock("span", _hoisted_1, toDisplayString(message.message), 1)) : (openBlock(true), createElementBlock(Fragment, { key: 2 }, renderList(message.message, (part, i) => {
              return openBlock(), createElementBlock("span", {
                key: i,
                class: normalizeClass(part.yellow ? unref($style).yellow : void 0)
              }, toDisplayString(part.text), 3);
            }), 128))
          ]);
        }), 128))
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
