import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import _sfc_main$3 from "../../../components/PrunButton.vue.js";
import SectionHeader from "../../../components/SectionHeader.vue.js";
import _sfc_main$2 from "../../../components/forms/Active.vue.js";
import _sfc_main$1 from "../../../components/forms/TextInput.vue.js";
import _sfc_main$4 from "../../../components/forms/Commands.vue.js";
import { isValidPackageName } from "./utils.js";
import { defineComponent, watch, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { ref, isRef, unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { normalizeClass } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "RenameActionPackage",
  props: {
    name: {},
    onRename: { type: Function }
  },
  emits: ["close"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const newName = ref(__props.name);
    const nameError = ref(false);
    watch(newName, () => nameError.value = !isValidPackageName(newName.value));
    function onCreateClick() {
      if (newName.value.length === 0 || !isValidPackageName(newName.value)) {
        nameError.value = true;
        return;
      }
      __props.onRename(newName.value);
      emit("close");
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).DraftConditionEditor.form)
      }, [
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[1] || (_cache[1] = [
            createTextVNode("Rename Action Package", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("div", {
          class: normalizeClass(_ctx.$style.description)
        }, " WARNING: Renaming an action package will break all existing tile links to it (including this one). You can see the full list of your action packages in XIT ACT. ", 2),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$2, {
            label: "Name",
            error: unref(nameError)
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$1, {
                modelValue: unref(newName),
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(newName) ? newName.value = $event : null)
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          }, 8, ["error"]),
          createVNode(_sfc_main$4, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$3, {
                primary: "",
                onClick: onCreateClick
              }, {
                default: withCtx(() => [..._cache[2] || (_cache[2] = [
                  createTextVNode("RENAME", -1)
                ])]),
                _: 1
              })
            ]),
            _: 1
          })
        ])
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
