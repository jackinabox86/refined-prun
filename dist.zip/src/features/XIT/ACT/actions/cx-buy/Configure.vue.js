import config from "../../../../../infrastructure/shell/config.js";
import _sfc_main$2 from "../../../../../components/forms/Active.vue.js";
import SelectInput from "../../../../../components/forms/SelectInput.vue.js";
import _sfc_main$1 from "../../../../../components/forms/RadioItem.vue.js";
import { defineComponent, openBlock, createElementBlock, createBlock, withCtx, createVNode, createTextVNode, createCommentVNode } from "../../../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Configure",
  props: {
    data: {},
    config: {}
  },
  setup(__props) {
    const exchanges = ["AI1", "CI1", "IC1", "NC1", "CI2", "NC2"];
    __props.config.skip ??= false;
    __props.config.exchange ??= exchanges[0];
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("form", null, [
        _ctx.data.skippable ? (openBlock(), createBlock(_sfc_main$2, {
          key: 0,
          label: "Skip CX Buy",
          tooltip: "Whether to skip purchasing materials and only perform the transfer."
        }, {
          default: withCtx(() => [
            createVNode(_sfc_main$1, {
              modelValue: ("config" in _ctx ? _ctx.config : unref(config)).skip,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => ("config" in _ctx ? _ctx.config : unref(config)).skip = $event)
            }, {
              default: withCtx(() => [..._cache[2] || (_cache[2] = [
                createTextVNode("skip cx buy", -1)
              ])]),
              _: 1
            }, 8, ["modelValue"])
          ]),
          _: 1
        })) : createCommentVNode("", true),
        !("config" in _ctx ? _ctx.config : unref(config)).skip ? (openBlock(), createBlock(_sfc_main$2, {
          key: 1,
          label: "Exchange"
        }, {
          default: withCtx(() => [
            createVNode(SelectInput, {
              modelValue: ("config" in _ctx ? _ctx.config : unref(config)).exchange,
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => ("config" in _ctx ? _ctx.config : unref(config)).exchange = $event),
              options: exchanges
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        })) : createCommentVNode("", true)
      ]);
    };
  }
});
export {
  _sfc_main as default
};
