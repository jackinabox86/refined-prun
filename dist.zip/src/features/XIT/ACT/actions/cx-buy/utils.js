import { cxobStore } from "../../../../../infrastructure/prun-api/data/cxob.js";
import { isFiniteOrder } from "../../../../../core/orders.js";
function fillAmount(cxTicker, amount, priceLimit) {
  const orderBook = cxobStore.getByTicker(cxTicker);
  if (!orderBook) {
    return void 0;
  }
  const filled = {
    amount: 0,
    priceLimit: 0,
    cost: 0
  };
  const orders = orderBook.sellingOrders.slice().sort((a, b) => a.limit.amount - b.limit.amount);
  for (const order of orders) {
    const orderPrice = order.limit.amount;
    if (priceLimit < orderPrice) {
      break;
    }
    const orderAmount = isFiniteOrder(order) ? order.amount : Infinity;
    const remaining = amount - filled.amount;
    const filledByOrder = Math.min(remaining, orderAmount);
    filled.priceLimit = orderPrice;
    filled.amount += filledByOrder;
    filled.cost += filledByOrder * orderPrice;
    if (filled.amount === amount) {
      break;
    }
  }
  return filled;
}
export {
  fillAmount
};
