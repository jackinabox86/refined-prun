import { act } from "../../act-registry.js";
import _sfc_main$1 from "./Edit.vue.js";
import _sfc_main from "./Configure.vue.js";
import { CONT_TRADE } from "../../action-steps/CONT_TRADE.js";
import { configurableValue, groupTargetPrefix } from "../../shared-types.js";
function resolveLocation(value, config, getMaterialGroupPlanet) {
  if (!value) {
    return void 0;
  }
  if (value === configurableValue) {
    return config?.location;
  }
  if (value.startsWith(groupTargetPrefix)) {
    const groupName = value.slice(groupTargetPrefix.length);
    return getMaterialGroupPlanet(groupName);
  }
  return value;
}
function displayLocation(value) {
  if (value.startsWith(groupTargetPrefix)) {
    return `[${value.slice(groupTargetPrefix.length)}] target`;
  }
  return value;
}
act.addAction({
  type: "CONT Trade",
  shortDescription: "Create a buy/sell trade contract draft for a material group",
  description: (action, config) => {
    if (!action.group || !action.contLocation) {
      return "--";
    }
    const tradeLabel = action.contTradeType === "SELLING" ? "Sell" : "Buy";
    const location = action.contLocation === configurableValue ? config?.location ?? "configured location" : displayLocation(action.contLocation);
    return `${tradeLabel} contract for [${action.group}] at ${location}`;
  },
  editComponent: _sfc_main$1,
  configureComponent: _sfc_main,
  needsConfigure: (data) => {
    return data.contLocation === configurableValue;
  },
  isValidConfig: (data, config) => {
    return data.contLocation !== configurableValue || config.location !== void 0;
  },
  generateSteps: async (ctx) => {
    const {
      data,
      config,
      packageName,
      getMaterialGroup,
      getMaterialGroupPrices,
      getMaterialGroupPlanet,
      emitStep
    } = ctx;
    const assert = ctx.assert;
    const materials = await getMaterialGroup(data.group);
    assert(materials, "Invalid material group");
    const prices = getMaterialGroupPrices(data.group);
    assert(
      prices,
      `Material group [${data.group}] has no prices. Use a Paste group with 3 columns (ticker, amount, price).`
    );
    const location = resolveLocation(data.contLocation, config, getMaterialGroupPlanet);
    assert(location, "Invalid location");
    const tradeType = data.contTradeType ?? "BUYING";
    const daysToFulfill = data.daysToFulfill ?? 3;
    const currency = data.currency ?? "NCC";
    emitStep(
      CONT_TRADE({
        packageName,
        materials,
        prices,
        tradeType,
        location,
        currency,
        daysToFulfill
      })
    );
  }
});
