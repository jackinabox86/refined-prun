import _sfc_main$1 from "../../../../../components/forms/Active.vue.js";
import SelectInput from "../../../../../components/forms/SelectInput.vue.js";
import _sfc_main$2 from "../../../../../components/forms/NumericInput.vue.js";
import { storagesStore } from "../../../../../infrastructure/prun-api/data/storage.js";
import { sitesStore } from "../../../../../infrastructure/prun-api/data/sites.js";
import { warehousesStore } from "../../../../../infrastructure/prun-api/data/warehouses.js";
import { getEntityNameFromAddress } from "../../../../../infrastructure/prun-api/data/addresses.js";
import { comparePlanets } from "../../../../../util.js";
import { groupTargetPrefix, configurableValue } from "../../shared-types.js";
import { defineComponent, computed, openBlock, createElementBlock, createVNode, withCtx, Fragment } from "../../../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "../../../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  props: {
    action: {},
    pkg: {}
  },
  setup(__props, { expose: __expose }) {
    const materialGroups = computed(() => __props.pkg.groups.map((x) => x.name).filter((x) => x));
    const materialGroup = ref(__props.action.group ?? materialGroups.value[0]);
    const tradeTypes = ["Buy", "Sell"];
    const tradeTypeToValue = {
      Buy: "BUYING",
      Sell: "SELLING"
    };
    const valueToTradeType = {
      BUYING: "Buy",
      SELLING: "Sell"
    };
    const tradeType = ref(valueToTradeType[__props.action.contTradeType ?? "BUYING"] ?? "Buy");
    const staticLocations = computed(() => {
      const seen = /* @__PURE__ */ new Set();
      const result = [];
      for (const store of storagesStore.nonFuelStores.value ?? []) {
        let address;
        if (store.type === "STORE") {
          address = sitesStore.getById(store.addressableId)?.address;
        } else if (store.type === "WAREHOUSE_STORE") {
          address = warehousesStore.getById(store.addressableId)?.address;
        } else {
          continue;
        }
        const name = getEntityNameFromAddress(address);
        if (name && !seen.has(name)) {
          seen.add(name);
          result.push(name);
        }
      }
      return result.sort(comparePlanets);
    });
    const groupTargetOptions = computed(
      () => __props.pkg.groups.filter((x) => x.name).map((x) => ({
        label: `[${x.name}] target`,
        value: `${groupTargetPrefix}${x.name}`
      }))
    );
    const locationOptions = computed(() => [
      configurableValue,
      ...groupTargetOptions.value,
      ...staticLocations.value
    ]);
    const currencies = ["NCC", "CIS", "AIC", "ICA"];
    const contLocation = ref(__props.action.contLocation ?? staticLocations.value[0] ?? "");
    const currency = ref(__props.action.currency ?? "NCC");
    const daysToFulfill = ref(__props.action.daysToFulfill ?? 3);
    function validate() {
      if (!materialGroup.value) {
        return false;
      }
      if (daysToFulfill.value < 1) {
        return false;
      }
      return true;
    }
    function save() {
      __props.action.group = materialGroup.value;
      __props.action.contTradeType = tradeTypeToValue[tradeType.value];
      __props.action.contLocation = contLocation.value;
      __props.action.currency = currency.value;
      __props.action.daysToFulfill = daysToFulfill.value;
    }
    __expose({ validate, save });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(_sfc_main$1, { label: "Material Group" }, {
          default: withCtx(() => [
            createVNode(SelectInput, {
              modelValue: unref(materialGroup),
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(materialGroup) ? materialGroup.value = $event : null),
              options: unref(materialGroups)
            }, null, 8, ["modelValue", "options"])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$1, { label: "Trade Type" }, {
          default: withCtx(() => [
            createVNode(SelectInput, {
              modelValue: unref(tradeType),
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(tradeType) ? tradeType.value = $event : null),
              options: tradeTypes
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$1, { label: "Location" }, {
          default: withCtx(() => [
            createVNode(SelectInput, {
              modelValue: unref(contLocation),
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(contLocation) ? contLocation.value = $event : null),
              options: unref(locationOptions)
            }, null, 8, ["modelValue", "options"])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$1, { label: "Currency" }, {
          default: withCtx(() => [
            createVNode(SelectInput, {
              modelValue: unref(currency),
              "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(currency) ? currency.value = $event : null),
              options: currencies
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$1, { label: "Days to Fulfill" }, {
          default: withCtx(() => [
            createVNode(_sfc_main$2, {
              modelValue: unref(daysToFulfill),
              "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => isRef(daysToFulfill) ? daysToFulfill.value = $event : null),
              min: 1,
              max: 30,
              step: 1
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        })
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
