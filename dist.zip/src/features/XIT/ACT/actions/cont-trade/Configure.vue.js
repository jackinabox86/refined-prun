import config from "../../../../../infrastructure/shell/config.js";
import _sfc_main$1 from "../../../../../components/forms/Active.vue.js";
import _sfc_main$2 from "../../../../../components/forms/Passive.vue.js";
import SelectInput from "../../../../../components/forms/SelectInput.vue.js";
import { storagesStore } from "../../../../../infrastructure/prun-api/data/storage.js";
import { sitesStore } from "../../../../../infrastructure/prun-api/data/sites.js";
import { warehousesStore } from "../../../../../infrastructure/prun-api/data/warehouses.js";
import { getEntityNameFromAddress } from "../../../../../infrastructure/prun-api/data/addresses.js";
import { comparePlanets } from "../../../../../util.js";
import { configurableValue, groupTargetPrefix } from "../../shared-types.js";
import { defineComponent, computed, watchEffect, openBlock, createElementBlock, createBlock, withCtx, createVNode, createElementVNode as createBaseVNode } from "../../../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString } from "../../../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Configure",
  props: {
    data: {},
    config: {}
  },
  setup(__props) {
    const locations = computed(() => {
      const seen = /* @__PURE__ */ new Set();
      const result = [];
      for (const store of storagesStore.nonFuelStores.value ?? []) {
        let address;
        if (store.type === "STORE") {
          address = sitesStore.getById(store.addressableId)?.address;
        } else if (store.type === "WAREHOUSE_STORE") {
          address = warehousesStore.getById(store.addressableId)?.address;
        } else {
          continue;
        }
        const name = getEntityNameFromAddress(address);
        if (name && !seen.has(name)) {
          seen.add(name);
          result.push(name);
        }
      }
      return result.sort(comparePlanets);
    });
    if (__props.data.contLocation === configurableValue && !__props.config.location && locations.value.length > 0) {
      __props.config.location = locations.value[0];
    }
    watchEffect(() => {
      if (__props.data.contLocation === configurableValue) {
        if (__props.config.location && !locations.value.includes(__props.config.location)) {
          __props.config.location = void 0;
        }
        if (!__props.config.location && locations.value.length === 1) {
          __props.config.location = locations.value[0];
        }
      }
    });
    function displayValue(value) {
      if (!value) {
        return "--";
      }
      if (value.startsWith(groupTargetPrefix)) {
        return `[${value.slice(groupTargetPrefix.length)}] target`;
      }
      return value;
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("form", null, [
        _ctx.data.contLocation === unref(configurableValue) ? (openBlock(), createBlock(_sfc_main$1, {
          key: 0,
          label: "Location"
        }, {
          default: withCtx(() => [
            createVNode(SelectInput, {
              modelValue: ("config" in _ctx ? _ctx.config : unref(config)).location,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => ("config" in _ctx ? _ctx.config : unref(config)).location = $event),
              options: unref(locations)
            }, null, 8, ["modelValue", "options"])
          ]),
          _: 1
        })) : (openBlock(), createBlock(_sfc_main$2, {
          key: 1,
          label: "Location"
        }, {
          default: withCtx(() => [
            createBaseVNode("span", null, toDisplayString(displayValue(_ctx.data.contLocation)), 1)
          ]),
          _: 1
        }))
      ]);
    };
  }
});
export {
  _sfc_main as default
};
