import { storagesStore } from "../../../../../infrastructure/prun-api/data/storage.js";
function getRefuelOrigins() {
  return storagesStore.nonFuelStores.value ?? [];
}
export {
  getRefuelOrigins
};
