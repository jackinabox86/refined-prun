import { act } from "../../act-registry.js";
import _sfc_main$1 from "./Edit.vue.js";
import _sfc_main from "./Configure.vue.js";
import { MTRA_TRANSFER } from "../../action-steps/MTRA_TRANSFER.js";
import { OPEN_SFC } from "../../action-steps/OPEN_SFC.js";
import { deserializeStorage, atSameLocation } from "../utils.js";
import { configurableValue } from "../../shared-types.js";
act.addAction({
  type: "MTRA",
  shortDescription: "Transfer materials between storages at the same location",
  description: (action, config) => {
    if (!action.group || !action.origin || !action.dest) {
      return "--";
    }
    const origin = action.origin == configurableValue ? config?.origin ?? "configured location" : action.origin;
    const dest = action.dest == configurableValue ? config?.destination ?? "configured location" : action.dest;
    return `Transfer group [${action.group}] from ${origin} to ${dest}`;
  },
  editComponent: _sfc_main$1,
  configureComponent: _sfc_main,
  needsConfigure: (data) => {
    return data.origin === configurableValue || data.dest === configurableValue;
  },
  isValidConfig: (data, config) => {
    return (data.origin !== configurableValue || config.origin !== void 0) && (data.dest !== configurableValue || config.destination !== void 0);
  },
  generateSteps: async (ctx) => {
    const { data, config, packageName, getMaterialGroup, getMaterialGroupPlanet, emitStep } = ctx;
    const assert = ctx.assert;
    const PRUNPLANNER_PACKAGES = [
      "PRUNplanner Supply Cart",
      "PRUNplanner Construct",
      "PRUNplanner Transfer",
      "PRUNplanner Burn Supply"
    ];
    const materials = await getMaterialGroup(data.group);
    assert(materials, "Invalid material group");
    const serializedOrigin = data.origin === configurableValue ? config?.origin : data.origin;
    const origin = deserializeStorage(serializedOrigin);
    assert(origin, "Invalid origin");
    const serializedDest = data.dest === configurableValue ? config?.destination : data.dest;
    const dest = deserializeStorage(serializedDest);
    assert(dest, "Invalid destination");
    const isSameLocation = atSameLocation(origin, dest);
    assert(isSameLocation, "Origin and destination are not at the same location");
    for (const ticker of Object.keys(materials)) {
      emitStep(
        MTRA_TRANSFER({
          from: origin.id,
          to: dest.id,
          ticker,
          amount: materials[ticker]
        })
      );
    }
    if (dest.type === "SHIP_STORE" && !PRUNPLANNER_PACKAGES.includes(packageName)) {
      const planet = getMaterialGroupPlanet(data.group);
      emitStep(OPEN_SFC({ shipId: dest.addressableId, destination: planet }));
    }
  }
});
