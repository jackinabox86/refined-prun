import config from "../../../../../infrastructure/shell/config.js";
import _sfc_main$1 from "../../../../../components/forms/Active.vue.js";
import _sfc_main$2 from "../../../../../components/forms/Passive.vue.js";
import SelectInput from "../../../../../components/forms/SelectInput.vue.js";
import { storagesStore } from "../../../../../infrastructure/prun-api/data/storage.js";
import { sitesStore } from "../../../../../infrastructure/prun-api/data/sites.js";
import { warehousesStore } from "../../../../../infrastructure/prun-api/data/warehouses.js";
import { getEntityNameFromAddress } from "../../../../../infrastructure/prun-api/data/addresses.js";
import { comparePlanets } from "../../../../../util.js";
import { configurableValue, groupTargetPrefix } from "../../shared-types.js";
import { serializeStorage } from "../utils.js";
import { defineComponent, computed, watchEffect, openBlock, createElementBlock, createBlock, withCtx, createVNode, createElementVNode as createBaseVNode, createCommentVNode } from "../../../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString } from "../../../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Configure",
  props: {
    data: {},
    config: {}
  },
  setup(__props) {
    const locations = computed(() => {
      const seen = /* @__PURE__ */ new Set();
      const result = [];
      for (const store of storagesStore.nonFuelStores.value ?? []) {
        let address;
        if (store.type === "STORE") {
          address = sitesStore.getById(store.addressableId)?.address;
        } else if (store.type === "WAREHOUSE_STORE") {
          address = warehousesStore.getById(store.addressableId)?.address;
        } else {
          continue;
        }
        const name = getEntityNameFromAddress(address);
        if (name && !seen.has(name)) {
          seen.add(name);
          result.push(name);
        }
      }
      return result.sort(comparePlanets);
    });
    if (__props.data.contOrigin === configurableValue && !__props.config.origin && locations.value.length > 0) {
      __props.config.origin = locations.value[0];
    }
    if (__props.data.contDest === configurableValue && !__props.config.destination && locations.value.length > 0) {
      __props.config.destination = locations.value[0];
    }
    watchEffect(() => {
      if (__props.data.contOrigin === configurableValue) {
        if (__props.config.origin && !locations.value.includes(__props.config.origin)) {
          __props.config.origin = void 0;
        }
        if (!__props.config.origin && locations.value.length === 1) {
          __props.config.origin = locations.value[0];
        }
      }
      if (__props.data.contDest === configurableValue) {
        if (__props.config.destination && !locations.value.includes(__props.config.destination)) {
          __props.config.destination = void 0;
        }
        if (!__props.config.destination && locations.value.length === 1) {
          __props.config.destination = locations.value[0];
        }
      }
    });
    const resolvedOrigin = computed(() => {
      if (__props.data.contOrigin === configurableValue) {
        return __props.config.origin;
      }
      return __props.data.contOrigin;
    });
    const storeOptions = computed(() => {
      const origin = resolvedOrigin.value;
      if (!origin || !__props.data.autoProvision) {
        return [];
      }
      const result = [];
      for (const store of storagesStore.nonFuelStores.value ?? []) {
        let address;
        if (store.type === "STORE") {
          address = sitesStore.getById(store.addressableId)?.address;
        } else if (store.type === "WAREHOUSE_STORE") {
          address = warehousesStore.getById(store.addressableId)?.address;
        } else {
          continue;
        }
        const name = getEntityNameFromAddress(address);
        if (name === origin) {
          result.push({ label: serializeStorage(store), value: store.id });
        }
      }
      return result;
    });
    if (__props.data.autoProvision && !__props.config.autoProvisionStoreId && storeOptions.value.length > 0) {
      __props.config.autoProvisionStoreId = storeOptions.value[0].value;
    }
    watchEffect(() => {
      if (__props.data.autoProvision) {
        const ids = new Set(storeOptions.value.map((o) => o.value));
        if (__props.config.autoProvisionStoreId && !ids.has(__props.config.autoProvisionStoreId)) {
          __props.config.autoProvisionStoreId = void 0;
        }
        if (!__props.config.autoProvisionStoreId && storeOptions.value.length > 0) {
          __props.config.autoProvisionStoreId = storeOptions.value[0].value;
        }
      }
    });
    function displayValue(value) {
      if (!value) {
        return "--";
      }
      if (value.startsWith(groupTargetPrefix)) {
        return `[${value.slice(groupTargetPrefix.length)}] target`;
      }
      return value;
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("form", null, [
        _ctx.data.contOrigin === unref(configurableValue) ? (openBlock(), createBlock(_sfc_main$1, {
          key: 0,
          label: "From"
        }, {
          default: withCtx(() => [
            createVNode(SelectInput, {
              modelValue: ("config" in _ctx ? _ctx.config : unref(config)).origin,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => ("config" in _ctx ? _ctx.config : unref(config)).origin = $event),
              options: unref(locations)
            }, null, 8, ["modelValue", "options"])
          ]),
          _: 1
        })) : (openBlock(), createBlock(_sfc_main$2, {
          key: 1,
          label: "From"
        }, {
          default: withCtx(() => [
            createBaseVNode("span", null, toDisplayString(displayValue(_ctx.data.contOrigin)), 1)
          ]),
          _: 1
        })),
        _ctx.data.contDest === unref(configurableValue) ? (openBlock(), createBlock(_sfc_main$1, {
          key: 2,
          label: "To"
        }, {
          default: withCtx(() => [
            createVNode(SelectInput, {
              modelValue: ("config" in _ctx ? _ctx.config : unref(config)).destination,
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => ("config" in _ctx ? _ctx.config : unref(config)).destination = $event),
              options: unref(locations)
            }, null, 8, ["modelValue", "options"])
          ]),
          _: 1
        })) : (openBlock(), createBlock(_sfc_main$2, {
          key: 3,
          label: "To"
        }, {
          default: withCtx(() => [
            createBaseVNode("span", null, toDisplayString(displayValue(_ctx.data.contDest)), 1)
          ]),
          _: 1
        })),
        _ctx.data.autoProvision ? (openBlock(), createBlock(_sfc_main$1, {
          key: 4,
          label: "Auto-provision"
        }, {
          default: withCtx(() => [
            createVNode(SelectInput, {
              modelValue: ("config" in _ctx ? _ctx.config : unref(config)).autoProvisionStoreId,
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => ("config" in _ctx ? _ctx.config : unref(config)).autoProvisionStoreId = $event),
              options: unref(storeOptions)
            }, null, 8, ["modelValue", "options"])
          ]),
          _: 1
        })) : createCommentVNode("", true)
      ]);
    };
  }
});
export {
  _sfc_main as default
};
