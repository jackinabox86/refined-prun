import { act } from "../../act-registry.js";
import _sfc_main$1 from "./Edit.vue.js";
import _sfc_main from "./Configure.vue.js";
import { CONT_SEND } from "../../action-steps/CONT_SEND.js";
import { configurableValue, groupTargetPrefix } from "../../shared-types.js";
import { materialsStore } from "../../../../../infrastructure/prun-api/data/materials.js";
function resolveLocation(value, config, field, getMaterialGroupPlanet) {
  if (!value) {
    return void 0;
  }
  if (value === configurableValue) {
    return config?.[field];
  }
  if (value.startsWith(groupTargetPrefix)) {
    const groupName = value.slice(groupTargetPrefix.length);
    return getMaterialGroupPlanet(groupName);
  }
  return value;
}
function displayLocation(value) {
  if (value.startsWith(groupTargetPrefix)) {
    return `[${value.slice(groupTargetPrefix.length)}] target`;
  }
  return value;
}
act.addAction({
  type: "CONT Ship",
  shortDescription: "Create a shipping contract draft for a material group",
  description: (action, config) => {
    if (!action.group || !action.contOrigin || !action.contDest) {
      return "--";
    }
    const origin = action.contOrigin === configurableValue ? config?.origin ?? "configured location" : displayLocation(action.contOrigin);
    const dest = action.contDest === configurableValue ? config?.destination ?? "configured location" : displayLocation(action.contDest);
    const payment = action.paymentPerTon ?? 0;
    const paymentStr = payment > 0 ? ` @ ${payment}/t` : "";
    return `Send contract for [${action.group}] from ${origin} to ${dest}${paymentStr}`;
  },
  editComponent: _sfc_main$1,
  configureComponent: _sfc_main,
  needsConfigure: () => true,
  isValidConfig: (data, config) => {
    return (data.contOrigin !== configurableValue || config.origin !== void 0) && (data.contDest !== configurableValue || config.destination !== void 0) && (!data.autoProvision || config.autoProvisionStoreId !== void 0);
  },
  generateSteps: async (ctx) => {
    const { data, config, packageName, getMaterialGroup, getMaterialGroupPlanet, emitStep } = ctx;
    const assert = ctx.assert;
    const materials = await getMaterialGroup(data.group);
    assert(materials, "Invalid material group");
    const contOrigin = resolveLocation(data.contOrigin, config, "origin", getMaterialGroupPlanet);
    assert(contOrigin, "Invalid origin");
    const contDest = resolveLocation(data.contDest, config, "destination", getMaterialGroupPlanet);
    assert(contDest, "Invalid destination");
    const paymentPerTon = Number(data.paymentPerTon ?? 0);
    const daysToFulfill = data.daysToFulfill ?? 3;
    const currency = data.currency ?? "NCC";
    let totalTonnage = 0;
    for (const [ticker, amount] of Object.entries(materials)) {
      const material = materialsStore.getByTicker(ticker);
      totalTonnage += material ? material.weight * amount : amount;
    }
    const totalPayment = Math.round(totalTonnage * paymentPerTon);
    emitStep(
      CONT_SEND({
        packageName,
        materials,
        contractNote: data.contractNote,
        payment: totalPayment,
        currency,
        daysToFulfill,
        contOrigin,
        contDest,
        autoProvisionStoreId: data.autoProvision ? config?.autoProvisionStoreId : void 0
      })
    );
  }
});
