import _sfc_main$1 from "../../../../../components/forms/Active.vue.js";
import SelectInput from "../../../../../components/forms/SelectInput.vue.js";
import _sfc_main$2 from "../../../../../components/forms/NumericInput.vue.js";
import _sfc_main$3 from "../../../../../components/forms/RadioItem.vue.js";
import { storagesStore } from "../../../../../infrastructure/prun-api/data/storage.js";
import { sitesStore } from "../../../../../infrastructure/prun-api/data/sites.js";
import { warehousesStore } from "../../../../../infrastructure/prun-api/data/warehouses.js";
import { getEntityNameFromAddress } from "../../../../../infrastructure/prun-api/data/addresses.js";
import { comparePlanets } from "../../../../../util.js";
import { groupTargetPrefix, configurableValue } from "../../shared-types.js";
import { defineComponent, computed, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, Fragment } from "../../../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "../../../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  props: {
    action: {},
    pkg: {}
  },
  setup(__props, { expose: __expose }) {
    const materialGroups = computed(() => __props.pkg.groups.map((x) => x.name).filter((x) => x));
    const materialGroup = ref(__props.action.group ?? materialGroups.value[0]);
    const staticLocations = computed(() => {
      const seen = /* @__PURE__ */ new Set();
      const result = [];
      for (const store of storagesStore.nonFuelStores.value ?? []) {
        let address;
        if (store.type === "STORE") {
          address = sitesStore.getById(store.addressableId)?.address;
        } else if (store.type === "WAREHOUSE_STORE") {
          address = warehousesStore.getById(store.addressableId)?.address;
        } else {
          continue;
        }
        const name = getEntityNameFromAddress(address);
        if (name && !seen.has(name)) {
          seen.add(name);
          result.push(name);
        }
      }
      return result.sort(comparePlanets);
    });
    const groupTargetOptions = computed(
      () => __props.pkg.groups.filter((x) => x.name).map((x) => ({
        label: `[${x.name}] target`,
        value: `${groupTargetPrefix}${x.name}`
      }))
    );
    const locationOptions = computed(() => [
      configurableValue,
      ...groupTargetOptions.value,
      ...staticLocations.value
    ]);
    const currencies = ["NCC", "CIS", "AIC", "ICA"];
    const contOrigin = ref(__props.action.contOrigin ?? staticLocations.value[0] ?? "");
    const contDest = ref(__props.action.contDest ?? staticLocations.value[0] ?? "");
    const currency = ref(__props.action.currency ?? "NCC");
    const paymentPerTon = ref(__props.action.paymentPerTon ?? 0);
    const daysToFulfill = ref(__props.action.daysToFulfill ?? 3);
    const autoProvision = ref(__props.action.autoProvision ?? false);
    function validate() {
      if (!materialGroup.value) {
        return false;
      }
      if (daysToFulfill.value < 1) {
        return false;
      }
      if (paymentPerTon.value < 0) {
        return false;
      }
      return true;
    }
    function save() {
      __props.action.group = materialGroup.value;
      __props.action.contOrigin = contOrigin.value;
      __props.action.contDest = contDest.value;
      __props.action.currency = currency.value;
      __props.action.paymentPerTon = paymentPerTon.value;
      __props.action.daysToFulfill = daysToFulfill.value;
      __props.action.autoProvision = autoProvision.value;
      delete __props.action.contractNote;
    }
    __expose({ validate, save });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(_sfc_main$1, { label: "Material Group" }, {
          default: withCtx(() => [
            createVNode(SelectInput, {
              modelValue: unref(materialGroup),
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(materialGroup) ? materialGroup.value = $event : null),
              options: unref(materialGroups)
            }, null, 8, ["modelValue", "options"])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$1, { label: "Origin" }, {
          default: withCtx(() => [
            createVNode(SelectInput, {
              modelValue: unref(contOrigin),
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(contOrigin) ? contOrigin.value = $event : null),
              options: unref(locationOptions)
            }, null, 8, ["modelValue", "options"])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$1, { label: "Destination" }, {
          default: withCtx(() => [
            createVNode(SelectInput, {
              modelValue: unref(contDest),
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(contDest) ? contDest.value = $event : null),
              options: unref(locationOptions)
            }, null, 8, ["modelValue", "options"])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$1, { label: "Currency" }, {
          default: withCtx(() => [
            createVNode(SelectInput, {
              modelValue: unref(currency),
              "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(currency) ? currency.value = $event : null),
              options: currencies
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$1, { label: "Payment per Ton" }, {
          default: withCtx(() => [
            createVNode(_sfc_main$2, {
              modelValue: unref(paymentPerTon),
              "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => isRef(paymentPerTon) ? paymentPerTon.value = $event : null),
              min: 0,
              step: 1,
              placeholder: "0"
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$1, { label: "Days to Fulfill" }, {
          default: withCtx(() => [
            createVNode(_sfc_main$2, {
              modelValue: unref(daysToFulfill),
              "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => isRef(daysToFulfill) ? daysToFulfill.value = $event : null),
              min: 1,
              max: 30,
              step: 1
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$1, { label: "Auto-provision" }, {
          default: withCtx(() => [
            createVNode(_sfc_main$3, {
              modelValue: unref(autoProvision),
              "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => isRef(autoProvision) ? autoProvision.value = $event : null)
            }, {
              default: withCtx(() => [..._cache[7] || (_cache[7] = [
                createTextVNode("enable auto-provision", -1)
              ])]),
              _: 1
            }, 8, ["modelValue"])
          ]),
          _: 1
        })
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
