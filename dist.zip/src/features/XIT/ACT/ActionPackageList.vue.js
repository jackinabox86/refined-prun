import _sfc_main$2 from "../../../components/ActionBar.vue.js";
import _sfc_main$1 from "../../../components/PrunButton.vue.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import { showTileOverlay, showConfirmationOverlay } from "../../../infrastructure/prun-ui/tile-overlay.js";
import _sfc_main$3 from "./CreateActionPackage.vue.js";
import _sfc_main$4 from "./ImportActionPackage.vue.js";
import Quickstart from "./Quickstart.vue.js";
import { userData } from "../../../store/user-data.js";
import PrunLink from "../../../components/PrunLink.vue.js";
import removeArrayElement from "../../../utils/remove-array-element.js";
import { objectId } from "../../../utils/object-id.js";
import { vDraggable as so } from "../../../../npm/vue-draggable-plus@0.6.0_@types+sortablejs@1.15.8-vue-draggable-plus-vue-draggable-plus.js";
import { grip } from "../../../components/grip/index.js";
import GripCell from "../../../components/grip/GripCell.vue.js";
import GripHeaderCell from "../../../components/grip/GripHeaderCell.vue.js";
import { defineComponent, computed, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, createCommentVNode, createBlock, withDirectives, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _hoisted_2 = { key: 1 };
const _hoisted_3 = { key: 0 };
const _hoisted_4 = { key: 1 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ActionPackageList",
  setup(__props) {
    const actionPackages = computed(() => userData.actionPackages);
    const showQuickstart = computed(() => userData.actionPackages.length === 0);
    function onQuickstartClick(ev) {
      showTileOverlay(ev, Quickstart);
    }
    function onCreateClick(ev) {
      showTileOverlay(ev, _sfc_main$3, {
        onCreate: (name) => {
          userData.actionPackages.push({
            global: { name },
            groups: [],
            actions: []
          });
          showBuffer("XIT ACT_EDIT_" + name.split(" ").join("_"));
        }
      });
    }
    function onImportClick(ev) {
      showTileOverlay(ev, _sfc_main$4, {
        onImport: (json) => {
          const existing = userData.actionPackages.find((x) => x.global.name === json.global.name);
          if (existing) {
            const index = userData.actionPackages.indexOf(existing);
            userData.actionPackages[index] = json;
          } else {
            userData.actionPackages.push(json);
          }
        }
      });
    }
    function onDeleteClick(ev, pkg) {
      showConfirmationOverlay(ev, () => removeArrayElement(userData.actionPackages, pkg), {
        message: `Are you sure you want to delete the action package "${pkg.global.name}"?`,
        confirmLabel: "DELETE"
      });
    }
    function friendlyName(pkg) {
      return pkg.global.name.split("_").join(" ");
    }
    function paramName(pkg) {
      return pkg.global.name.split(" ").join("_");
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(_sfc_main$2, null, {
          default: withCtx(() => [
            unref(showQuickstart) ? (openBlock(), createElementBlock("div", _hoisted_1, [..._cache[0] || (_cache[0] = [
              createTextVNode("Click here if you don't", -1),
              createBaseVNode("br", null, null, -1),
              createTextVNode("know what to do!", -1)
            ])])) : createCommentVNode("", true),
            unref(showQuickstart) ? (openBlock(), createElementBlock("div", _hoisted_2, "→")) : createCommentVNode("", true),
            unref(showQuickstart) ? (openBlock(), createBlock(_sfc_main$1, {
              key: 2,
              primary: "",
              onClick: onQuickstartClick
            }, {
              default: withCtx(() => [..._cache[1] || (_cache[1] = [
                createTextVNode("QUICKSTART", -1)
              ])]),
              _: 1
            })) : createCommentVNode("", true),
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: onCreateClick
            }, {
              default: withCtx(() => [..._cache[2] || (_cache[2] = [
                createTextVNode("CREATE NEW", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: onImportClick
            }, {
              default: withCtx(() => [..._cache[3] || (_cache[3] = [
                createTextVNode("IMPORT", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        }),
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createVNode(GripHeaderCell),
              _cache[4] || (_cache[4] = createBaseVNode("th", null, "Name", -1)),
              _cache[5] || (_cache[5] = createBaseVNode("th", null, "Execute", -1)),
              _cache[6] || (_cache[6] = createBaseVNode("th", null, "Edit", -1)),
              _cache[7] || (_cache[7] = createBaseVNode("th", null, "Delete", -1))
            ])
          ]),
          unref(userData).actionPackages.length === 0 ? (openBlock(), createElementBlock("tbody", _hoisted_3, [..._cache[8] || (_cache[8] = [
            createBaseVNode("tr", null, [
              createBaseVNode("td", { colspan: "5" }, "No action packages.")
            ], -1)
          ])])) : withDirectives((openBlock(), createElementBlock("tbody", _hoisted_4, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(actionPackages), (pkg) => {
              return openBlock(), createElementBlock("tr", {
                key: unref(objectId)(pkg)
              }, [
                createVNode(GripCell),
                createBaseVNode("td", null, [
                  createVNode(PrunLink, {
                    inline: "",
                    command: `XIT ACT_${paramName(pkg)}`
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(friendlyName(pkg)), 1)
                    ]),
                    _: 2
                  }, 1032, ["command"])
                ]),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$1, {
                    primary: "",
                    onClick: ($event) => unref(showBuffer)(`XIT ACT_${paramName(pkg)}`)
                  }, {
                    default: withCtx(() => [..._cache[9] || (_cache[9] = [
                      createTextVNode(" EXECUTE ", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ]),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$1, {
                    primary: "",
                    onClick: ($event) => unref(showBuffer)(`XIT ACT_EDIT_${paramName(pkg)}`)
                  }, {
                    default: withCtx(() => [..._cache[10] || (_cache[10] = [
                      createTextVNode(" EDIT ", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ]),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$1, {
                    dark: "",
                    inline: "",
                    onClick: ($event) => onDeleteClick($event, pkg)
                  }, {
                    default: withCtx(() => [..._cache[11] || (_cache[11] = [
                      createTextVNode("delete", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ])
              ]);
            }), 128))
          ])), [
            [unref(so), [unref(actionPackages), unref(grip).draggable]]
          ])
        ])
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
