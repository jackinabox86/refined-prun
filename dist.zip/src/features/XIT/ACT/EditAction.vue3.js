const description = "rp-EditAction__description___0c18652";
const style0 = {
  description
};
export {
  style0 as default,
  description
};
