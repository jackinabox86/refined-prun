import Header from "../../../components/Header.vue.js";
import SectionHeader from "../../../components/SectionHeader.vue.js";
import _sfc_main$2 from "../../../components/forms/Commands.vue.js";
import _sfc_main$1 from "../../../components/PrunButton.vue.js";
import { showTileOverlay, showConfirmationOverlay } from "../../../infrastructure/prun-ui/tile-overlay.js";
import removeArrayElement from "../../../utils/remove-array-element.js";
import { objectId } from "../../../utils/object-id.js";
import { act } from "./act-registry.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import EditMaterialGroup from "./EditMaterialGroup.vue.js";
import EditAction from "./EditAction.vue.js";
import { downloadJson } from "../../../utils/json-file.js";
import { deepToRaw } from "../../../utils/deep-to-raw.js";
import RenameActionPackage from "./RenameActionPackage.vue.js";
import { vDraggable as so } from "../../../../npm/vue-draggable-plus@0.6.0_@types+sortablejs@1.15.8-vue-draggable-plus-vue-draggable-plus.js";
import { grip } from "../../../components/grip/index.js";
import GripCell from "../../../components/grip/GripCell.vue.js";
import GripHeaderCell from "../../../components/grip/GripHeaderCell.vue.js";
import { defineComponent, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, withDirectives, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _hoisted_2 = { key: 1 };
const _hoisted_3 = { key: 0 };
const _hoisted_4 = { key: 1 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "EditActionPackage",
  props: {
    pkg: {}
  },
  setup(__props) {
    function onAddMaterialGroupClick(e) {
      const group = {
        name: "",
        type: "Resupply"
      };
      showTileOverlay(e, EditMaterialGroup, {
        add: true,
        group,
        onSave: () => __props.pkg.groups.push(group)
      });
    }
    function onEditMaterialGroupClick(e, group) {
      showTileOverlay(e, EditMaterialGroup, { group });
    }
    function onDeleteMaterialGroupClick(e, group) {
      showConfirmationOverlay(e, () => removeArrayElement(__props.pkg.groups, group), {
        message: `Are you sure you want to delete the material group "${group.name ?? "--"}"?`,
        confirmLabel: "DELETE"
      });
    }
    function onAddActionClick(e) {
      const action = {
        name: "",
        type: "MTRA"
      };
      showTileOverlay(e, EditAction, {
        add: true,
        action,
        pkg: __props.pkg,
        onSave: () => __props.pkg.actions.push(action)
      });
    }
    function onEditActionClick(e, action) {
      showTileOverlay(e, EditAction, { action, pkg: __props.pkg });
    }
    function onDeleteActionClick(e, action) {
      showConfirmationOverlay(e, () => removeArrayElement(__props.pkg.actions, action), {
        message: `Are you sure you want to delete the action "${action.name ?? "--"}"?`,
        confirmLabel: "DELETE"
      });
    }
    function getMaterialGroupDescription(group) {
      const info = act.getMaterialGroupInfo(group.type);
      return info ? info.description(group) : "--";
    }
    function getActionDescription(action) {
      const info = act.getActionInfo(action.type);
      return info ? info.description(action) : "--";
    }
    function onRenameClick(ev) {
      showTileOverlay(ev, RenameActionPackage, {
        name: __props.pkg.global.name,
        onRename: (name) => __props.pkg.global.name = name
      });
    }
    function onExecuteClick() {
      showBuffer(`XIT ACT_${__props.pkg.global.name.replace(" ", "_")}`);
    }
    function onExportClick() {
      const json = deepToRaw(__props.pkg);
      downloadJson(json, `${__props.pkg.global.name.replace(" ", "_")}-${Date.now()}.json`);
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(Header, {
          modelValue: _ctx.pkg.global.name,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => _ctx.pkg.global.name = $event),
          editable: "",
          class: normalizeClass(_ctx.$style.header)
        }, null, 8, ["modelValue", "class"]),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[1] || (_cache[1] = [
            createTextVNode("Material Groups", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createVNode(GripHeaderCell),
              _cache[2] || (_cache[2] = createBaseVNode("th", null, "Type", -1)),
              _cache[3] || (_cache[3] = createBaseVNode("th", null, "Name", -1)),
              _cache[4] || (_cache[4] = createBaseVNode("th", null, "Content", -1)),
              _cache[5] || (_cache[5] = createBaseVNode("th", null, null, -1))
            ])
          ]),
          _ctx.pkg.groups.length === 0 ? (openBlock(), createElementBlock("tbody", _hoisted_1, [
            createBaseVNode("tr", null, [
              createBaseVNode("td", {
                colspan: "4",
                class: normalizeClass(_ctx.$style.emptyRow)
              }, "No groups yet.", 2)
            ])
          ])) : withDirectives((openBlock(), createElementBlock("tbody", _hoisted_2, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.pkg.groups, (group) => {
              return openBlock(), createElementBlock("tr", {
                key: unref(objectId)(group)
              }, [
                createVNode(GripCell),
                createBaseVNode("td", null, toDisplayString(group.type), 1),
                createBaseVNode("td", null, toDisplayString(group.name || "--"), 1),
                createBaseVNode("td", null, toDisplayString(getMaterialGroupDescription(group)), 1),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$1, {
                    dark: "",
                    inline: "",
                    onClick: ($event) => onEditMaterialGroupClick($event, group)
                  }, {
                    default: withCtx(() => [..._cache[6] || (_cache[6] = [
                      createTextVNode(" edit ", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"]),
                  createVNode(_sfc_main$1, {
                    dark: "",
                    inline: "",
                    onClick: ($event) => onDeleteMaterialGroupClick($event, group)
                  }, {
                    default: withCtx(() => [..._cache[7] || (_cache[7] = [
                      createTextVNode(" delete ", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ])
              ]);
            }), 128))
          ])), [
            [unref(so), [_ctx.pkg.groups, unref(grip).draggable]]
          ])
        ]),
        createBaseVNode("form", {
          class: normalizeClass(_ctx.$style.sectionCommands)
        }, [
          createVNode(_sfc_main$2, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$1, {
                primary: "",
                onClick: onAddMaterialGroupClick
              }, {
                default: withCtx(() => [..._cache[8] || (_cache[8] = [
                  createTextVNode("ADD", -1)
                ])]),
                _: 1
              })
            ]),
            _: 1
          })
        ], 2),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[9] || (_cache[9] = [
            createTextVNode("Actions", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createVNode(GripHeaderCell),
              _cache[10] || (_cache[10] = createBaseVNode("th", null, "Type", -1)),
              _cache[11] || (_cache[11] = createBaseVNode("th", null, "Name", -1)),
              _cache[12] || (_cache[12] = createBaseVNode("th", null, "Content", -1)),
              _cache[13] || (_cache[13] = createBaseVNode("th", null, null, -1))
            ])
          ]),
          _ctx.pkg.actions.length === 0 ? (openBlock(), createElementBlock("tbody", _hoisted_3, [
            createBaseVNode("tr", null, [
              createBaseVNode("td", {
                colspan: "4",
                class: normalizeClass(_ctx.$style.emptyRow)
              }, "No actions yet.", 2)
            ])
          ])) : withDirectives((openBlock(), createElementBlock("tbody", _hoisted_4, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.pkg.actions, (action) => {
              return openBlock(), createElementBlock("tr", {
                key: unref(objectId)(action)
              }, [
                createVNode(GripCell),
                createBaseVNode("td", null, toDisplayString(action.type), 1),
                createBaseVNode("td", null, toDisplayString(action.name || "--"), 1),
                createBaseVNode("td", null, toDisplayString(getActionDescription(action)), 1),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$1, {
                    dark: "",
                    inline: "",
                    onClick: ($event) => onEditActionClick($event, action)
                  }, {
                    default: withCtx(() => [..._cache[14] || (_cache[14] = [
                      createTextVNode("edit", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"]),
                  createVNode(_sfc_main$1, {
                    dark: "",
                    inline: "",
                    onClick: ($event) => onDeleteActionClick($event, action)
                  }, {
                    default: withCtx(() => [..._cache[15] || (_cache[15] = [
                      createTextVNode("delete", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ])
              ]);
            }), 128))
          ])), [
            [unref(so), [_ctx.pkg.actions, unref(grip).draggable]]
          ])
        ]),
        createBaseVNode("form", {
          class: normalizeClass(_ctx.$style.sectionCommands)
        }, [
          createVNode(_sfc_main$2, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$1, {
                primary: "",
                onClick: onAddActionClick
              }, {
                default: withCtx(() => [..._cache[16] || (_cache[16] = [
                  createTextVNode("ADD", -1)
                ])]),
                _: 1
              })
            ]),
            _: 1
          })
        ], 2),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[17] || (_cache[17] = [
            createTextVNode("Commands", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$2, { label: "Remame" }, {
            default: withCtx(() => [
              createVNode(_sfc_main$1, {
                primary: "",
                onClick: onRenameClick
              }, {
                default: withCtx(() => [..._cache[18] || (_cache[18] = [
                  createTextVNode("RENAME", -1)
                ])]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_sfc_main$2, { label: "Execute" }, {
            default: withCtx(() => [
              createVNode(_sfc_main$1, {
                primary: "",
                onClick: onExecuteClick
              }, {
                default: withCtx(() => [..._cache[19] || (_cache[19] = [
                  createTextVNode("EXECUTE", -1)
                ])]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_sfc_main$2, { label: "Export" }, {
            default: withCtx(() => [
              createVNode(_sfc_main$1, {
                primary: "",
                onClick: onExportClick
              }, {
                default: withCtx(() => [..._cache[20] || (_cache[20] = [
                  createTextVNode("EXPORT", -1)
                ])]),
                _: 1
              })
            ]),
            _: 1
          })
        ])
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
