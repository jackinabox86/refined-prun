const textarea = "rp-Configure__textarea___6840c89";
const style0 = {
  textarea
};
export {
  style0 as default,
  textarea
};
