import { defineComponent, openBlock, createElementBlock } from "../../../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  props: {
    group: {}
  },
  setup(__props, { expose: __expose }) {
    function validate() {
      return true;
    }
    function save() {
    }
    __expose({ validate, save });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div");
    };
  }
});
export {
  _sfc_main as default
};
