import { vModelText } from "../../../../../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import _sfc_main$1 from "../../../../../components/forms/Active.vue.js";
import { parseMaterials } from "./paste.js";
import { defineComponent, watch, openBlock, createElementBlock, createVNode, withCtx, withDirectives, createElementVNode as createBaseVNode } from "../../../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { ref, isRef, unref } from "../../../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { normalizeClass } from "../../../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Configure",
  props: {
    data: {},
    config: {}
  },
  setup(__props) {
    const text = ref(__props.config.materials ?? "");
    const hasError = ref(false);
    watch(text, (value) => {
      __props.config.materials = value;
      const parsed = parseMaterials(value);
      hasError.value = parsed === void 0;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("form", null, [
        createVNode(_sfc_main$1, {
          label: "Materials",
          error: unref(hasError)
        }, {
          default: withCtx(() => [
            withDirectives(createBaseVNode("textarea", {
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(text) ? text.value = $event : null),
              class: normalizeClass(_ctx.$style.textarea),
              placeholder: `Paste from spreadsheet or type manually
TICKER  AMOUNT  PRICE
RAT     100     50.25

Price column is optional.
Supports tab or comma separated values.`,
              spellcheck: "false"
            }, null, 2), [
              [vModelText, unref(text)]
            ])
          ]),
          _: 1
        }, 8, ["error"])
      ]);
    };
  }
});
export {
  _sfc_main as default
};
