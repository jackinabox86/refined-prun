import "../../../../../infrastructure/shell/config.js";
import { act } from "../../act-registry.js";
import _sfc_main from "./Edit.vue.js";
import Configure from "./Configure.vue.js";
import { materialsStore } from "../../../../../infrastructure/prun-api/data/materials.js";
function isValidPrice(n) {
  if (n <= 0 || !isFinite(n)) {
    return false;
  }
  if (Math.round(n * 100) !== n * 100) {
    return false;
  }
  return true;
}
function stripQuotes(s) {
  if (s.length >= 2 && s[0] === '"' && s[s.length - 1] === '"') {
    return s.slice(1, -1);
  }
  return s;
}
function stripThousands(s) {
  return s.replace(/,/g, "");
}
function splitLine(line) {
  if (line.includes("	")) {
    return {
      parts: line.split("	").map((x) => stripQuotes(x.trim())),
      isTabSeparated: true
    };
  }
  return {
    parts: line.split(",").map((x) => stripQuotes(x.trim())),
    isTabSeparated: false
  };
}
function parseNumber(value, isTabSeparated) {
  return Number(isTabSeparated ? stripThousands(value) : value);
}
function parseMaterials(input) {
  if (!input) {
    return void 0;
  }
  const lines = input.split("\n").filter((x) => x.trim().length > 0);
  if (lines.length === 0) {
    return void 0;
  }
  const materials = {};
  let prices;
  let hasPrice = false;
  for (const line of lines) {
    const { parts, isTabSeparated } = splitLine(line);
    if (parts.length < 2 || parts.length > 3) {
      return void 0;
    }
    const [ticker, amountStr] = parts;
    const material = materialsStore.getByTicker(ticker.toUpperCase());
    if (!material) {
      return void 0;
    }
    const amount = parseNumber(amountStr, isTabSeparated);
    if (!Number.isFinite(amount) || amount <= 0 || Math.floor(amount) !== amount) {
      return void 0;
    }
    materials[material.ticker] = (materials[material.ticker] ?? 0) + amount;
    if (parts.length === 3) {
      const price = parseNumber(parts[2], isTabSeparated);
      if (!isValidPrice(price)) {
        return void 0;
      }
      prices ??= {};
      prices[material.ticker] = price;
      hasPrice = true;
    } else if (hasPrice) {
      return void 0;
    }
  }
  return { materials, prices };
}
act.addMaterialGroup({
  type: "Paste",
  shortDescription: "Paste materials from clipboard at execution time",
  description: () => {
    return "Paste materials at execution time";
  },
  editComponent: _sfc_main,
  configureComponent: Configure,
  needsConfigure: () => true,
  isValidConfig: (_data, config) => parseMaterials(config.materials) !== void 0,
  generateMaterialBill: async ({ config, log, setPrices }) => {
    const result = parseMaterials(config.materials);
    if (!result) {
      log.error("Invalid or missing pasted materials.");
      return void 0;
    }
    if (result.prices) {
      setPrices(result.prices);
    }
    return result.materials;
  }
});
export {
  parseMaterials
};
