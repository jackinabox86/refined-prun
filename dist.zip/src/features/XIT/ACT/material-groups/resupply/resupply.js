import "../../../../../infrastructure/shell/config.js";
import { act } from "../../act-registry.js";
import _sfc_main from "./Edit.vue.js";
import Configure from "./Configure.vue.js";
import { sitesStore } from "../../../../../infrastructure/prun-api/data/sites.js";
import { workforcesStore } from "../../../../../infrastructure/prun-api/data/workforces.js";
import { productionStore } from "../../../../../infrastructure/prun-api/data/production.js";
import { configurableValue } from "../../shared-types.js";
import { computeResupplyBill } from "./bill.js";
import { watchWhile } from "../../../../../utils/watch.js";
import { getEntityNameFromAddress, getEntityNaturalIdFromAddress } from "../../../../../infrastructure/prun-api/data/addresses.js";
import { computed } from "../../../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { toRef } from "../../../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
act.addMaterialGroup({
  type: "Resupply",
  shortDescription: "Calculate consumables needed based on burn rate",
  description: (data) => {
    if (!data.planet || data.days === void 0) {
      return "--";
    }
    const daysLabel = data.days === configurableValue ? "?" : data.days;
    return `Resupply ${data.planet} with ${daysLabel} day${data.days == 1 ? "" : "s"} of supplies`;
  },
  editComponent: _sfc_main,
  configureComponent: Configure,
  needsConfigure: (data) => data.planet === configurableValue || data.days === configurableValue,
  isValidConfig: (data, config) => (data.planet !== configurableValue || config.planet !== void 0) && (data.days !== configurableValue || config.days !== void 0),
  generateMaterialBill: async ({ data, config, log, setStatus }) => {
    if (!data.planet) {
      log.error("Missing resupply planet");
    }
    if (data.days === void 0) {
      log.error("Missing resupply days");
    }
    const planet = data.planet === configurableValue ? config.planet : data.planet;
    const days = data.days === configurableValue ? config.days ?? 10 : typeof data.days === "number" ? data.days : parseFloat(data.days);
    const site = sitesStore.getByPlanetNaturalIdOrName(planet);
    if (!site) {
      log.error(`Base is not present on ${data.planet}`);
    }
    if (!site || days === void 0 || isNaN(days)) {
      return void 0;
    }
    const workforce = computed(() => workforcesStore.getById(site?.siteId)?.workforces);
    const production = computed(() => productionStore.getBySiteId(site.siteId));
    if (workforce.value === void 0 || production.value === void 0) {
      const name = getEntityNameFromAddress(site.address) ?? getEntityNaturalIdFromAddress(site.address);
      setStatus(`Loading ${name} burn data...`);
      await watchWhile(
        toRef(() => workforce.value === void 0 || production.value === void 0)
      );
    }
    return computeResupplyBill(data, planet, days, config.materialFilter);
  }
});
