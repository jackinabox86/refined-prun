import { calculatePlanetBurn } from "../../../../../core/burn.js";
import { sitesStore } from "../../../../../infrastructure/prun-api/data/sites.js";
import { workforcesStore } from "../../../../../infrastructure/prun-api/data/workforces.js";
import { productionStore } from "../../../../../infrastructure/prun-api/data/production.js";
import { storagesStore } from "../../../../../infrastructure/prun-api/data/storage.js";
function computeResupplyBill(data, planet, days, materialFilter) {
  if (!planet || days === void 0 || isNaN(days)) {
    return void 0;
  }
  const site = sitesStore.getByPlanetNaturalIdOrName(planet);
  if (!site) {
    return void 0;
  }
  const workforce = workforcesStore.getById(site.siteId)?.workforces;
  const production = productionStore.getBySiteId(site.siteId);
  if (workforce === void 0 || production === void 0) {
    return void 0;
  }
  const stores = storagesStore.getByAddressableId(site.siteId);
  const filter = materialFilter ?? (data.consumablesOnly ? "Workforce" : "All");
  const planetBurn = calculatePlanetBurn(
    filter === "Workforce" ? void 0 : production,
    filter === "Production" ? void 0 : workforce,
    data.useBaseInv ?? true ? stores : void 0
  );
  const exclusions = data.exclusions ?? [];
  const bill = {};
  for (const ticker of Object.keys(planetBurn)) {
    if (exclusions.includes(ticker)) {
      continue;
    }
    const matBurn = planetBurn[ticker];
    if (matBurn.dailyAmount >= 0) {
      continue;
    }
    const consumed = days * -matBurn.dailyAmount;
    const need = Math.max(0, Math.ceil(consumed - matBurn.inventory + 1));
    if (need > 0) {
      bill[ticker] = need;
    }
  }
  return bill;
}
export {
  computeResupplyBill
};
