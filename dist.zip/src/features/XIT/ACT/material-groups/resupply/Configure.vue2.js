import config from "../../../../../infrastructure/shell/config.js";
import SelectInput from "../../../../../components/forms/SelectInput.vue.js";
import _sfc_main$1 from "../../../../../components/forms/Active.vue.js";
import _sfc_main$2 from "../../../../../components/forms/NumberInput.vue.js";
import _sfc_main$3 from "../../../../../components/PrunButton.vue.js";
import { computeResupplyBill } from "./bill.js";
import { sitesStore } from "../../../../../infrastructure/prun-api/data/sites.js";
import { getEntityNameFromAddress } from "../../../../../infrastructure/prun-api/data/addresses.js";
import { comparePlanets } from "../../../../../util.js";
import { configurableValue } from "../../shared-types.js";
import { userData } from "../../../../../store/user-data.js";
import { materialsStore } from "../../../../../infrastructure/prun-api/data/materials.js";
import { shipsStore } from "../../../../../infrastructure/prun-api/data/ships.js";
import { fixed02 } from "../../../../../utils/format.js";
import { defineComponent, computed, watch, openBlock, createElementBlock, createElementVNode as createBaseVNode, createBlock, withCtx, createVNode, createCommentVNode, Fragment, renderList, createTextVNode } from "../../../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "../../../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _hoisted_1 = { key: 1 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Configure",
  props: {
    data: {},
    config: {},
    shipStore: {}
  },
  setup(__props) {
    const planets = computed(
      () => (sitesStore.all.value ?? []).map((x) => getEntityNameFromAddress(x.address)).filter((x) => x !== void 0).sort(comparePlanets)
    );
    if (__props.data.planet === configurableValue && !__props.config.planet) {
      __props.config.planet = planets.value[0];
    }
    if (__props.data.days === configurableValue && __props.config.days === void 0) {
      __props.config.days = userData.settings.burn.resupply ?? 10;
    }
    const materialFilterOptions = ["All", "Workforce", "Production"];
    const materialFilter = ref(
      __props.config.materialFilter ?? (__props.data.consumablesOnly ? "Workforce" : "All")
    );
    __props.config.materialFilter = materialFilter.value;
    watch(materialFilter, (val) => {
      __props.config.materialFilter = val;
    });
    const effectivePlanet = computed(
      () => __props.data.planet === configurableValue ? __props.config.planet : __props.data.planet
    );
    const effectiveDays = computed(() => {
      if (__props.data.days === configurableValue) {
        return __props.config.days;
      }
      if (typeof __props.data.days === "number") {
        return __props.data.days;
      }
      const parsed = parseFloat(__props.data.days);
      return isNaN(parsed) ? void 0 : parsed;
    });
    const bill = computed(
      () => computeResupplyBill(__props.data, effectivePlanet.value, effectiveDays.value, materialFilter.value)
    );
    function billTotals(entries) {
      let weight = 0;
      let volume = 0;
      for (const [ticker, amount] of Object.entries(entries)) {
        const mat = materialsStore.getByTicker(ticker);
        if (mat) {
          weight += mat.weight * amount;
          volume += mat.volume * amount;
        }
      }
      return { weight, volume };
    }
    const totals = computed(() => {
      const entries = bill.value;
      if (!entries) {
        return void 0;
      }
      return billTotals(entries);
    });
    const shipSizes = [
      { label: "2k/2k", weight: 2e3, volume: 2e3 },
      { label: "3k/1k", weight: 3e3, volume: 1e3 },
      { label: "5k/5k", weight: 5e3, volume: 5e3 }
    ];
    function fitToShip(maxWeight, maxVolume) {
      const planet = effectivePlanet.value;
      if (!planet) {
        return;
      }
      if (!computeResupplyBill(__props.data, planet, 1, materialFilter.value)) {
        return;
      }
      let lo = 0;
      let hi = 999;
      while (lo < hi) {
        const mid = lo + Math.ceil((hi - lo) / 2);
        const entries = computeResupplyBill(__props.data, planet, mid, materialFilter.value);
        const t = billTotals(entries);
        if (t.weight <= maxWeight && t.volume <= maxVolume) {
          lo = mid;
        } else {
          hi = mid - 1;
        }
      }
      __props.config.days = lo;
    }
    const canFit = computed(() => bill.value !== void 0);
    const shipFree = computed(() => {
      if (!__props.shipStore) {
        return void 0;
      }
      return {
        weight: __props.shipStore.weightCapacity - __props.shipStore.weightLoad,
        volume: __props.shipStore.volumeCapacity - __props.shipStore.volumeLoad
      };
    });
    const shipName = computed(() => {
      if (!__props.shipStore) {
        return void 0;
      }
      const ship = shipsStore.getById(__props.shipStore.addressableId);
      return ship?.name ?? ship?.registration;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("form", null, [
          _ctx.data.planet === unref(configurableValue) ? (openBlock(), createBlock(_sfc_main$1, {
            key: 0,
            label: "Planet"
          }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: ("config" in _ctx ? _ctx.config : unref(config)).planet,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => ("config" in _ctx ? _ctx.config : unref(config)).planet = $event),
                options: unref(planets)
              }, null, 8, ["modelValue", "options"])
            ]),
            _: 1
          })) : createCommentVNode("", true),
          _ctx.data.days === unref(configurableValue) ? (openBlock(), createBlock(_sfc_main$1, {
            key: 1,
            label: "Days",
            tooltip: "The number of days of supplies to refill the planet with."
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$2, {
                modelValue: ("config" in _ctx ? _ctx.config : unref(config)).days,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => ("config" in _ctx ? _ctx.config : unref(config)).days = $event)
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          })) : createCommentVNode("", true)
        ]),
        createVNode(_sfc_main$1, {
          label: "Materials",
          tooltip: "Which materials to include in the resupply group."
        }, {
          default: withCtx(() => [
            createVNode(SelectInput, {
              modelValue: unref(materialFilter),
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(materialFilter) ? materialFilter.value = $event : null),
              options: materialFilterOptions
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        createBaseVNode("div", {
          class: normalizeClass(_ctx.$style.totals)
        }, [
          unref(totals) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
            _cache[4] || (_cache[4] = createBaseVNode("span", null, "Total Weight ", -1)),
            createBaseVNode("span", {
              class: normalizeClass(_ctx.$style.value)
            }, toDisplayString(unref(fixed02)(unref(totals).weight)) + "t", 3),
            _cache[5] || (_cache[5] = createBaseVNode("span", null, ", Total Volume ", -1)),
            createBaseVNode("span", {
              class: normalizeClass(_ctx.$style.value)
            }, toDisplayString(unref(fixed02)(unref(totals).volume)) + "m³", 3)
          ], 64)) : (openBlock(), createElementBlock("span", _hoisted_1, "Total Weight --, Total Volume --"))
        ], 2),
        _ctx.data.days === unref(configurableValue) ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(_ctx.$style.fitRow)
        }, [
          _cache[7] || (_cache[7] = createBaseVNode("span", null, "Fit to Ship", -1)),
          (openBlock(), createElementBlock(Fragment, null, renderList(shipSizes, (ship) => {
            return createVNode(_sfc_main$3, {
              key: ship.label,
              primary: "",
              disabled: !unref(canFit),
              onClick: ($event) => fitToShip(ship.weight, ship.volume)
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(ship.label), 1)
              ]),
              _: 2
            }, 1032, ["disabled", "onClick"]);
          }), 64)),
          unref(shipName) && unref(shipFree) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
            _cache[6] || (_cache[6] = createBaseVNode("span", null, "Fit Selected", -1)),
            createVNode(_sfc_main$3, {
              primary: "",
              disabled: !unref(canFit),
              onClick: _cache[3] || (_cache[3] = ($event) => fitToShip(unref(shipFree).weight, unref(shipFree).volume))
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(unref(shipName).slice(0, 12)), 1)
              ]),
              _: 1
            }, 8, ["disabled"])
          ], 64)) : createCommentVNode("", true)
        ], 2)) : createCommentVNode("", true)
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
