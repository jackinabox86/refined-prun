const totals = "rp-Configure__totals___c202a59";
const value = "rp-Configure__value___1f9c3bb";
const fitRow = "rp-Configure__fitRow___58cc311";
const style0 = {
  totals,
  value,
  fitRow
};
export {
  style0 as default,
  fitRow,
  totals,
  value
};
