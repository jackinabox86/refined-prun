const description = "rp-EditMaterialGroup__description___45c47ce";
const style0 = {
  description
};
export {
  style0 as default,
  description
};
