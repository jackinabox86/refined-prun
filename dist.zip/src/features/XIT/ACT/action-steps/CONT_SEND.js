import { _$$, _$ } from "../../../../utils/select-dom.js";
import { C } from "../../../../infrastructure/prun-ui/prun-css.js";
import { act } from "../act-registry.js";
import { fixed0 } from "../../../../utils/format.js";
import { focusElement, changeInputValue, changeSelectIndex } from "../../../../util.js";
import { materialsStore } from "../../../../infrastructure/prun-api/data/materials.js";
import { createNewDraft, setDraftNameAndPreamble, saveDraftDetails, openTemplate, selectTemplateType, setCurrency, addMaterials, selectLocation, waitFor, setDeadline, applyTemplate, saveConditions } from "./cont-utils.js";
const CONT_SEND = act.addActionStep({
  type: "CONT_SEND",
  totalMaterials: (data) => Object.fromEntries(Object.entries(data.materials).filter(([, v]) => v > 0)),
  description: (data) => {
    const materialCount = Object.keys(data.materials).length;
    const payment = data.payment !== 0 ? ` for ${fixed0(data.payment)} ${data.currency}` : "";
    return `Create contract draft (${materialCount} materials)${payment}`;
  },
  execute: async (ctx) => {
    const { data, log, setStatus, requestTile, waitAct, complete, fail } = ctx;
    let totalTonnage = 0;
    const materialDetails = [];
    for (const [ticker, rawAmount] of Object.entries(data.materials)) {
      const qty = rawAmount;
      if (qty <= 0) {
        continue;
      }
      const material = materialsStore.getByTicker(ticker);
      if (!material) {
        log.warning(`Material ${ticker} not found, skipping`);
        continue;
      }
      const t = material.weight * qty;
      totalTonnage += t;
      materialDetails.push({ ticker, amount: qty, tonnage: t });
    }
    if (data.payment > 0 && totalTonnage > 0) {
      log.info(
        `Total: ${totalTonnage.toFixed(2)}t, ${data.payment} ${data.currency} (${Math.round(data.payment / totalTonnage)} ${data.currency}/t)`
      );
    }
    await waitAct("Create new draft?");
    const listTile = await requestTile("CONTD");
    if (!listTile) {
      return;
    }
    const draftCtx = { log, setStatus, fail };
    const newDraft = await createNewDraft(draftCtx);
    if (!newDraft) {
      return;
    }
    setStatus(`Loading draft ${newDraft.naturalId}...`);
    const draftTile = await requestTile(`CONTD ${newDraft.naturalId}`);
    if (!draftTile) {
      return;
    }
    const ctx2 = { draftTile, log, setStatus, fail };
    const now = /* @__PURE__ */ new Date();
    const dateStr = now.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    const contractName = `${data.packageName} - ${data.contDest ?? ""} - ${dateStr}`;
    const materialsList = materialDetails.map((m) => `${m.ticker} x${m.amount}`).join(", ");
    const preambleText = data.contractNote ?? `Shipping contract for ${totalTonnage.toFixed(2)}t.
Materials: ${materialsList}
` + (data.payment > 0 ? `Payment: ${data.payment} ${data.currency} (${Math.round(data.payment / totalTonnage)} ${data.currency}/t)
` : "") + (data.daysToFulfill > 0 ? `Delivery within ${data.daysToFulfill} days` : "");
    await setDraftNameAndPreamble(ctx2, contractName, preambleText);
    await waitAct("Save draft details?");
    await saveDraftDetails(ctx2);
    const templateSelect = await openTemplate(ctx2);
    if (!templateSelect) {
      return;
    }
    selectTemplateType(ctx2, templateSelect, "SHIP");
    await setCurrency(ctx2, data.currency);
    await addMaterials(
      ctx2,
      materialDetails.map((m) => ({ ticker: m.ticker, amount: m.amount }))
    );
    if (data.payment > 0 && materialDetails.length > 0) {
      const pricePerCommodity = Math.round(data.payment / materialDetails.length);
      const priceInput = draftTile.anchor.querySelector('input[name="price"]') ?? (() => {
        const groups = new Set(_$$(draftTile.anchor, C.TemplateSelection.group));
        return _$$(draftTile.anchor, 'input[inputmode="decimal"]').find(
          (el) => !Array.from(groups).some((g) => g.contains(el))
        );
      })();
      if (priceInput) {
        focusElement(priceInput);
        priceInput.select();
        changeInputValue(priceInput, String(pricePerCommodity));
        log.info(
          `Price set: ${pricePerCommodity} ${data.currency}/commodity x${materialDetails.length} = ${pricePerCommodity * materialDetails.length} ${data.currency} total`
        );
      } else {
        log.warning("Could not find price input");
      }
    }
    const addressContainers = _$$(draftTile.anchor, C.AddressSelector.container);
    if (addressContainers.length >= 1 && data.contOrigin) {
      await waitAct(`Set origin to ${data.contOrigin}?`);
      const ok = await selectLocation(addressContainers[0], data.contOrigin);
      if (ok) {
        log.info(`Origin set: ${data.contOrigin}`);
      } else {
        log.warning(`Could not select origin: ${data.contOrigin}`);
      }
    }
    if (addressContainers.length >= 2 && data.contDest) {
      await waitAct(`Set destination to ${data.contDest}?`);
      const ok = await selectLocation(addressContainers[1], data.contDest);
      if (ok) {
        log.info(`Destination set: ${data.contDest}`);
      } else {
        log.warning(`Could not select destination: ${data.contDest}`);
      }
    }
    if (data.autoProvisionStoreId) {
      setStatus("Setting auto-provision store...");
      const storeSelectReady = await waitFor(() => {
        const sel = _$(draftTile.anchor, C.StoreSelect.container);
        return !!sel && sel.options.length > 1;
      }, 5e3);
      if (storeSelectReady) {
        const storeSelect = _$(draftTile.anchor, C.StoreSelect.container);
        const normalizedId = data.autoProvisionStoreId.replaceAll("-", "");
        const optionIndex = Array.from(storeSelect.options).findIndex(
          (o) => o.value === data.autoProvisionStoreId || o.value === normalizedId
        );
        if (optionIndex >= 0) {
          changeSelectIndex(storeSelect, optionIndex);
          log.info(`Auto-provision store set: ${storeSelect.options[optionIndex].text}`);
        } else {
          log.warning(`Could not find auto-provision store option: ${data.autoProvisionStoreId}`);
        }
      } else {
        log.warning("Auto-provision store select did not appear");
      }
    }
    setDeadline(ctx2, data.daysToFulfill);
    await waitAct("Apply template?");
    const applied = await applyTemplate(ctx2);
    if (!applied) {
      return;
    }
    await saveConditions(ctx2, waitAct);
    log.success(`Contract draft ${newDraft.naturalId} ready to send`);
    complete();
  }
});
export {
  CONT_SEND
};
