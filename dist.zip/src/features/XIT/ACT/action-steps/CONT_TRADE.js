import { _$$ } from "../../../../utils/select-dom.js";
import { C } from "../../../../infrastructure/prun-ui/prun-css.js";
import { act } from "../act-registry.js";
import { fixed0 } from "../../../../utils/format.js";
import { focusElement, changeInputValue } from "../../../../util.js";
import { createNewDraft, setDraftNameAndPreamble, saveDraftDetails, openTemplate, selectTemplateType, setCurrency, addMaterials, selectLocation, setDeadline, applyTemplate, saveConditions } from "./cont-utils.js";
const CONT_TRADE = act.addActionStep({
  type: "CONT_TRADE",
  totalMaterials: (data) => Object.fromEntries(Object.entries(data.materials).filter(([, v]) => v > 0)),
  description: (data) => {
    const materialCount = Object.keys(data.materials).length;
    const typeLabel = data.tradeType === "BUYING" ? "Buy" : "Sell";
    return `Create ${typeLabel} contract draft (${materialCount} materials)`;
  },
  execute: async (ctx) => {
    const { data, log, setStatus, requestTile, waitAct, complete, fail } = ctx;
    const typeLabel = data.tradeType === "BUYING" ? "Buy" : "Sell";
    await waitAct("Create new draft?");
    const listTile = await requestTile("CONTD");
    if (!listTile) {
      return;
    }
    const draftCtx = { log, setStatus, fail };
    const newDraft = await createNewDraft(draftCtx);
    if (!newDraft) {
      return;
    }
    setStatus(`Loading draft ${newDraft.naturalId}...`);
    const draftTile = await requestTile(`CONTD ${newDraft.naturalId}`);
    if (!draftTile) {
      return;
    }
    const ctx2 = { draftTile, log, setStatus, fail };
    const now = /* @__PURE__ */ new Date();
    const dateStr = now.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    const contractName = `${data.packageName} - ${typeLabel} - ${dateStr}`;
    const materialsList = Object.entries(data.materials).map(([ticker, amount]) => {
      const price = data.prices[ticker];
      return price !== void 0 && price > 0 ? `${ticker} x${amount} @ ${fixed0(price)}/u` : `${ticker} x${amount}`;
    }).join(", ");
    const preambleText = `${typeLabel} contract.
Materials: ${materialsList}
` + (data.daysToFulfill > 0 ? `Fulfill within ${data.daysToFulfill} days` : "");
    await setDraftNameAndPreamble(ctx2, contractName, preambleText);
    await waitAct("Save draft details?");
    await saveDraftDetails(ctx2);
    const templateSelect = await openTemplate(ctx2);
    if (!templateSelect) {
      return;
    }
    selectTemplateType(ctx2, templateSelect, data.tradeType);
    await setCurrency(ctx2, data.currency);
    const materialEntries = Object.entries(data.materials).filter(([, amount]) => amount > 0).map(([ticker, amount]) => ({ ticker, amount }));
    await addMaterials(ctx2, materialEntries, {
      setPrice: (group, ticker) => {
        const price = data.prices[ticker];
        if (price !== void 0 && price > 0) {
          const priceInput = group.querySelector(
            'input[inputmode="decimal"]'
          );
          if (priceInput) {
            focusElement(priceInput);
            priceInput.select();
            changeInputValue(priceInput, String(price));
            log.info(`Price for ${ticker}: ${price} ${data.currency}`);
          } else {
            log.warning(`Could not find price input for ${ticker}`);
          }
        }
      }
    });
    const addressContainers = _$$(draftTile.anchor, C.AddressSelector.container);
    if (addressContainers.length >= 1 && data.location) {
      await waitAct(`Set location to ${data.location}?`);
      const ok = await selectLocation(addressContainers[0], data.location);
      if (ok) {
        log.info(`Location set: ${data.location}`);
      } else {
        log.warning(`Could not select location: ${data.location}`);
      }
    }
    setDeadline(ctx2, data.daysToFulfill);
    await waitAct("Apply template?");
    const applied = await applyTemplate(ctx2);
    if (!applied) {
      return;
    }
    await saveConditions(ctx2, waitAct);
    log.success(`Contract draft ${newDraft.naturalId} ready to send`);
    complete();
  }
});
export {
  CONT_TRADE
};
