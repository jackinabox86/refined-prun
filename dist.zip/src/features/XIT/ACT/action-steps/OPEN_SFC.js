import { _$$, _$ } from "../../../../utils/select-dom.js";
import { C } from "../../../../infrastructure/prun-ui/prun-css.js";
import { act } from "../act-registry.js";
import { shipsStore } from "../../../../infrastructure/prun-api/data/ships.js";
import { focusElement, changeInputValue, clickElement } from "../../../../util.js";
const OPEN_SFC = act.addActionStep({
  type: "OPEN_SFC",
  description: (data) => {
    const ship = shipsStore.getById(data.shipId);
    const shipLabel = ship?.name ?? ship?.registration ?? "unknown ship";
    return data.destination ? `Open SFC for ${shipLabel}, set destination to ${data.destination}` : `Open SFC for ${shipLabel}`;
  },
  execute: async (ctx) => {
    const { data, log, waitAct, requestTile, complete } = ctx;
    const assert = ctx.assert;
    const ship = shipsStore.getById(data.shipId);
    assert(ship, "Ship not found");
    const tile = await requestTile(`SFC ${ship.registration}`);
    if (!tile) {
      return;
    }
    if (data.destination) {
      const input = _$$(document.documentElement, C.AddressSelector.input)[0];
      if (!input) {
        log.warning("SFC address input not found — set destination manually");
        complete();
        return;
      }
      await waitAct(`Set destination to ${data.destination}?`);
      focusElement(input);
      changeInputValue(input, data.destination);
      await waitAct("Select destination?");
      const portal = document.getElementById("autosuggest-portal");
      const suggestion = _$$(portal, C.AddressSelector.suggestionContent)[0];
      if (suggestion) {
        await clickElement(suggestion);
        log.info(`Destination set: ${data.destination}`);
      } else {
        log.warning(`No suggestion found for ${data.destination} — select manually`);
      }
    }
    const windowEl = tile.frame.closest(`.${C.Window.window}`);
    const bodyEl = windowEl ? _$(windowEl, C.Window.body) : null;
    if (bodyEl) {
      bodyEl.style.width = "975px";
      bodyEl.style.height = "750px";
    }
    complete();
  }
});
export {
  OPEN_SFC
};
