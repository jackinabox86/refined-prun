import { C } from "../../../../infrastructure/prun-ui/prun-css.js";
import { $, _$$, _$ } from "../../../../utils/select-dom.js";
import tiles from "../../../../infrastructure/prun-ui/tiles.js";
import { focusElement, changeInputValue, clickElement, changeTextAreaValue, changeSelectIndex } from "../../../../util.js";
import { sleep } from "../../../../utils/sleep.js";
import { contractDraftsStore } from "../../../../infrastructure/prun-api/data/contract-drafts.js";
async function waitFor(condition, timeout = 5e3, interval = 100) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    if (condition()) {
      return true;
    }
    await sleep(interval);
  }
  return false;
}
async function selectLocation(container, locationName) {
  const input = await $(container, C.AddressSelector.input);
  if (!input) {
    return false;
  }
  const portal = document.getElementById("autosuggest-portal");
  if (!portal) {
    return false;
  }
  focusElement(input);
  changeInputValue(input, locationName);
  const appeared = await waitFor(
    () => _$$(portal, C.AddressSelector.suggestionContent).length > 0,
    5e3
  );
  if (!appeared) {
    return false;
  }
  const suggestions = _$$(portal, C.AddressSelector.suggestionContent);
  const match = suggestions.find(
    (s) => s.textContent?.trim().toLowerCase().includes(locationName.toLowerCase())
  ) ?? suggestions.at(0);
  if (!match) {
    return false;
  }
  await clickElement(match);
  return true;
}
async function selectMaterial(container, ticker) {
  const input = await $(container, C.MaterialSelector.input);
  if (!input) {
    return false;
  }
  const suggestionsContainer = await $(
    container,
    C.MaterialSelector.suggestionsContainer
  );
  focusElement(input);
  changeInputValue(input, ticker);
  const suggestionsList = await $(container, C.MaterialSelector.suggestionsList);
  if (suggestionsContainer) {
    suggestionsContainer.style.display = "none";
  }
  const match = _$$(suggestionsList, C.MaterialSelector.suggestionEntry).find(
    (entry) => _$(entry, C.ColoredIcon.label)?.textContent === ticker
  );
  if (!match) {
    if (suggestionsContainer) {
      suggestionsContainer.style.display = "";
    }
    return false;
  }
  await clickElement(match);
  if (suggestionsContainer) {
    suggestionsContainer.style.display = "";
  }
  await sleep(200);
  return true;
}
async function createNewDraft(ctx) {
  const { log, setStatus, fail } = ctx;
  setStatus("Looking for Create New button...");
  const isCreateNew = (btn) => btn.textContent?.trim().toLowerCase() === "create new";
  const findContdButton = () => {
    for (const tile of tiles.find("CONTD", true)) {
      const btn = _$$(tile.anchor, C.Button.btn).find(isCreateNew);
      if (btn) {
        return { tile, btn };
      }
    }
    return void 0;
  };
  const createBtnReady = await waitFor(() => !!findContdButton(), 1e4);
  if (!createBtnReady) {
    fail('Could not find "Create New" button');
    return void 0;
  }
  const { btn: createBtn } = findContdButton();
  const beforeIds = new Set((contractDraftsStore.all.value ?? []).map((d) => d.naturalId));
  await clickElement(createBtn);
  setStatus("Waiting for draft to be created...");
  const draftAppeared = await waitFor(
    () => (contractDraftsStore.all.value ?? []).some((d) => !beforeIds.has(d.naturalId)),
    8e3
  );
  if (!draftAppeared) {
    fail("Timed out waiting for new contract draft");
    return void 0;
  }
  const newDraft = (contractDraftsStore.all.value ?? []).find((d) => !beforeIds.has(d.naturalId));
  log.info(`New draft created: ${newDraft.naturalId}`);
  return newDraft;
}
async function setDraftNameAndPreamble(ctx, name, preamble) {
  const { draftTile, log, setStatus } = ctx;
  setStatus("Setting contract name...");
  const nameInput = await $(draftTile.anchor, "input");
  if (nameInput) {
    focusElement(nameInput);
    nameInput.select();
    changeInputValue(nameInput, name);
    log.info(`Name set: ${name}`);
  } else {
    log.warning("Could not find name input");
  }
  const preambleInput = _$(draftTile.anchor, "textarea");
  if (preambleInput) {
    focusElement(preambleInput);
    changeTextAreaValue(preambleInput, preamble);
    log.info("Preamble set");
  }
}
async function saveDraftDetails(ctx) {
  const { draftTile, log, setStatus } = ctx;
  setStatus("Saving draft details...");
  const saveBtn = _$$(draftTile.anchor, C.Button.btn).find(
    (btn) => btn.textContent?.trim().toLowerCase() === "save"
  );
  if (saveBtn) {
    await clickElement(saveBtn);
    log.info("Draft details saved");
  } else {
    log.warning("Could not find save button for draft details");
  }
}
async function openTemplate(ctx) {
  const { draftTile, setStatus, fail } = ctx;
  setStatus("Opening template selection...");
  const selectTemplateBtnReady = await waitFor(
    () => _$$(draftTile.anchor, "button").some(
      (btn) => btn.textContent?.trim().toLowerCase() === "select template"
    ),
    5e3
  );
  if (!selectTemplateBtnReady) {
    fail('Could not find "Select Template" button');
    return void 0;
  }
  const selectTemplateBtn = _$$(draftTile.anchor, "button").find(
    (btn) => btn.textContent?.trim().toLowerCase() === "select template"
  );
  await clickElement(selectTemplateBtn);
  const templateTypeContainer = await $(draftTile.anchor, C.TemplateSelection.templateTypeSelect);
  const templateSelect = _$(templateTypeContainer, "select");
  if (!templateSelect) {
    fail("Could not find template type select");
    return void 0;
  }
  return templateSelect;
}
const templateValueMap = {
  BUYING: "BUY",
  SELLING: "SELL"
};
function selectTemplateType(ctx, templateSelect, templateValue) {
  const mapped = templateValueMap[templateValue] ?? templateValue;
  const idx = Array.from(templateSelect.options).findIndex((o) => o.value === mapped);
  if (idx >= 0) {
    changeSelectIndex(templateSelect, idx);
  }
  ctx.log.info(`Selected "${templateValue}" template`);
}
async function setCurrency(ctx, currency) {
  const { draftTile, log } = ctx;
  const currencySelectFound = await waitFor(() => {
    const selects = _$$(draftTile.anchor, "select");
    return selects.some((s) => Array.from(s.options).some((o) => o.value === currency));
  }, 3e3);
  if (currencySelectFound) {
    const selects = _$$(draftTile.anchor, "select");
    const currencySelect = selects.find(
      (s) => Array.from(s.options).some((o) => o.value === currency)
    );
    const currencyIndex = Array.from(currencySelect.options).findIndex((o) => o.value === currency);
    if (currencyIndex >= 0) {
      changeSelectIndex(currencySelect, currencyIndex);
    }
    log.info(`Currency set to ${currency}`);
  } else {
    log.warning(`Could not find currency select for ${currency}`);
  }
}
async function addMaterials(ctx, materials, options) {
  const { draftTile, log, setStatus } = ctx;
  setStatus("Adding materials to template...");
  for (let i = 0; i < materials.length; i++) {
    const mat = materials[i];
    if (i > 0) {
      const addBtn = _$$(draftTile.anchor, "button").find((btn) => {
        const t = btn.textContent?.trim().toLowerCase();
        return t === "add shipment" || t === "add commodity";
      });
      if (!addBtn) {
        log.warning(`Could not find add button for ${mat.ticker}`);
        continue;
      }
      await clickElement(addBtn);
      await waitFor(() => _$$(draftTile.anchor, C.TemplateSelection.group).length >= i + 1, 2e3);
    }
    const groups = _$$(draftTile.anchor, C.TemplateSelection.group);
    const group = groups.at(-1);
    if (!group) {
      log.warning(`Could not find group for ${mat.ticker}`);
      continue;
    }
    const amountInput = group.querySelector(
      'input[inputmode="numeric"]'
    );
    if (amountInput) {
      focusElement(amountInput);
      amountInput.select();
      changeInputValue(amountInput, String(mat.amount));
    }
    const matSelectorContainer = _$(group, C.MaterialSelector.container);
    if (matSelectorContainer) {
      const ok = await selectMaterial(matSelectorContainer, mat.ticker);
      if (ok) {
        log.info(`Added: ${mat.ticker} x${mat.amount}`);
      } else {
        log.warning(`Could not select material ${mat.ticker}`);
      }
    }
    options?.setPrice?.(group, mat.ticker);
  }
}
function setDeadline(ctx, days) {
  const { draftTile, log } = ctx;
  if (days <= 0) {
    return;
  }
  const deadlineInput = draftTile.anchor.querySelector(
    'input[name="deadline"]'
  );
  if (deadlineInput) {
    focusElement(deadlineInput);
    deadlineInput.select();
    changeInputValue(deadlineInput, String(days));
    log.info(`Deadline set: ${days} days`);
  }
}
async function applyTemplate(ctx) {
  const { draftTile, log, setStatus, fail } = ctx;
  setStatus("Applying template...");
  const applyBtnReady = await waitFor(
    () => _$$(draftTile.anchor, "button").some(
      (btn) => btn.textContent?.trim().toLowerCase() === "apply template"
    ),
    5e3
  );
  if (!applyBtnReady) {
    fail('Could not find "Apply Template" button');
    return false;
  }
  const applyBtn = _$$(draftTile.anchor, "button").find(
    (btn) => btn.textContent?.trim().toLowerCase() === "apply template"
  );
  await clickElement(applyBtn);
  await waitFor(() => applyBtn.classList.contains(C.Button.disabled), 3e3);
  await waitFor(() => !applyBtn.classList.contains(C.Button.disabled), 5e3);
  log.info("Template applied");
  return true;
}
async function saveConditions(ctx, waitAct) {
  const { draftTile, log, setStatus } = ctx;
  await waitAct("Save conditions?");
  setStatus("Saving conditions...");
  const condSaveBtn = _$$(draftTile.anchor, C.Button.btn).findLast(
    (btn) => btn.textContent?.trim().toLowerCase() === "save"
  );
  if (condSaveBtn && !condSaveBtn.classList.contains(C.Button.disabled)) {
    await clickElement(condSaveBtn);
    log.info("Conditions saved");
  } else {
    log.warning("Conditions save button not found or disabled");
  }
}
export {
  addMaterials,
  applyTemplate,
  createNewDraft,
  openTemplate,
  saveConditions,
  saveDraftDetails,
  selectLocation,
  selectMaterial,
  selectTemplateType,
  setCurrency,
  setDeadline,
  setDraftNameAndPreamble,
  waitFor
};
