import xit from "../xit-registry.js";
import "./actions/cx-buy/cx-buy.js";
import "./actions/mtra/mtra.js";
import "./actions/refuel/refuel.js";
import "./actions/cont-ship/cont-ship.js";
import "./actions/cont-trade/cont-trade.js";
import "./material-groups/repair/repair.js";
import "./material-groups/resupply/resupply.js";
import "./material-groups/manual/manual.js";
import "./material-groups/paste/paste.js";
import _sfc_main from "./ACT.vue.js";
xit.add({
  command: ["ACT", "ACTION"],
  name: (parameters) => {
    if (parameters.length === 0) {
      return "ACTION PACKAGES";
    }
    if (parameters[0].toUpperCase() == "GEN" || parameters[0].toUpperCase() == "EDIT") {
      return "EDIT ACTION PACKAGE";
    }
    return "EXECUTE ACTION PACKAGE";
  },
  description: "Allows to automate certain tasks.",
  optionalParameters: "GEN and/or Action Name",
  contextItems: (parameters) => parameters.length > 0 ? [{ cmd: "XIT ACT" }] : [],
  component: () => _sfc_main
});
