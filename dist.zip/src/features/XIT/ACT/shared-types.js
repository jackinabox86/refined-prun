const configurableValue = "Configure on Execution";
const groupTargetPrefix = "group:";
export {
  configurableValue,
  groupTargetPrefix
};
