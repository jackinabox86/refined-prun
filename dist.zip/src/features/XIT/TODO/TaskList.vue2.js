import { grip } from "../../../components/grip/index.js";
import TaskItem from "./TaskItem.vue.js";
import AddTaskItem from "./AddTaskItem.vue.js";
import { vDraggable as so } from "../../../../npm/vue-draggable-plus@0.6.0_@types+sortablejs@1.15.8-vue-draggable-plus-vue-draggable-plus.js";
import Header from "../../../components/Header.vue.js";
import { defineComponent, openBlock, createElementBlock, createVNode, withDirectives, Fragment, renderList, createBlock } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "TaskList",
  props: {
    list: {}
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(_ctx.$style.root)
      }, [
        createVNode(Header, {
          modelValue: _ctx.list.name,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => _ctx.list.name = $event),
          editable: "",
          class: normalizeClass(_ctx.$style.header)
        }, null, 8, ["modelValue", "class"]),
        withDirectives((openBlock(), createElementBlock("div", {
          class: normalizeClass(_ctx.$style.list)
        }, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.list.tasks, (task) => {
            return openBlock(), createBlock(TaskItem, {
              key: task.id,
              list: _ctx.list,
              task
            }, null, 8, ["list", "task"]);
          }), 128))
        ], 2)), [
          [unref(so), [_ctx.list.tasks, unref(grip).draggable]]
        ]),
        createVNode(AddTaskItem, { list: _ctx.list }, null, 8, ["list"])
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
