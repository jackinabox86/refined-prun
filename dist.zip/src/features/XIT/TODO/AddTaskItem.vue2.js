import fa from "../../../utils/font-awesome.module.css.js";
import { showTileOverlay } from "../../../infrastructure/prun-ui/tile-overlay.js";
import _sfc_main$1 from "./EditTask.vue.js";
import { createId } from "../../../store/create-id.js";
import { defineComponent, openBlock, createElementBlock, createElementVNode as createBaseVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "AddTaskItem",
  props: {
    list: {}
  },
  setup(__props) {
    function onAddClick(ev) {
      const task = {
        id: createId(),
        type: "Text"
      };
      showTileOverlay(ev, _sfc_main$1, {
        task,
        onSave: () => __props.list.tasks.push(task)
      });
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(_ctx.$style.item),
        onClick: onAddClick
      }, [
        createBaseVNode("div", {
          class: normalizeClass([unref(fa).solid, _ctx.$style.checkmark])
        }, [
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.plus)
          }, "+", 2),
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.plusHover)
          }, toDisplayString(""), 2)
        ], 2),
        createBaseVNode("div", {
          class: normalizeClass([_ctx.$style.content])
        }, "Add task", 2)
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
