import _sfc_main from "./TaskLists.vue.js";
export {
  _sfc_main as default
};
