import { useCssModule, withModifiers } from "../../../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import Checkmark from "./Checkmark.vue.js";
import dayjs from "../../../../npm/dayjs@1.11.18-dayjs-dayjs.min.js";
import { showTileOverlay } from "../../../infrastructure/prun-ui/tile-overlay.js";
import { ddmmyyyy } from "../../../utils/format.js";
import _sfc_main$3 from "./EditTask.vue.js";
import removeArrayElement from "../../../utils/remove-array-element.js";
import _sfc_main$2 from "./TaskText.vue.js";
import { grip } from "../../../components/grip/index.js";
import _sfc_main$1 from "../../../components/grip/GripChar.vue.js";
import { defineComponent, computed, resolveComponent, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, createCommentVNode, createTextVNode, Fragment, renderList, createBlock } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "TaskItem",
  props: {
    list: {},
    subtask: { type: Boolean },
    task: {}
  },
  setup(__props) {
    const $style = useCssModule();
    const taskClass = computed(() => ({
      [$style.taskCompleted]: __props.task.completed,
      [$style.subtask]: __props.subtask
    }));
    function onContentClick(ev) {
      if (__props.subtask) {
        return;
      }
      showTileOverlay(ev, _sfc_main$3, {
        task: __props.task,
        onDelete: () => removeArrayElement(__props.list.tasks, __props.task)
      });
    }
    function onCheckmarkClick() {
      if (__props.task.recurring !== void 0 && __props.task.dueDate !== void 0) {
        __props.task.dueDate = __props.task.dueDate + dayjs.duration(__props.task.recurring, "days").asMilliseconds();
        for (const subtask of __props.task.subtasks ?? []) {
          subtask.completed = false;
        }
      } else {
        __props.task.completed = !__props.task.completed;
        for (const subtask of __props.task.subtasks ?? []) {
          subtask.completed = __props.task.completed;
        }
      }
    }
    return (_ctx, _cache) => {
      const _component_TaskItem = resolveComponent("TaskItem", true);
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", {
          class: normalizeClass([unref($style).task, unref(taskClass)])
        }, [
          !_ctx.subtask ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass([unref($style).grip, unref(grip).class])
          }, [
            createVNode(_sfc_main$1)
          ], 2)) : createCommentVNode("", true),
          createVNode(Checkmark, {
            task: _ctx.task,
            class: normalizeClass(unref($style).checkmark),
            onClick: withModifiers(onCheckmarkClick, ["stop"])
          }, null, 8, ["task", "class"]),
          createBaseVNode("div", {
            class: normalizeClass([unref($style).content, { [unref($style).contentCompleted]: _ctx.task.completed }]),
            onClick: onContentClick
          }, [
            createVNode(_sfc_main$2, {
              text: _ctx.task.text
            }, null, 8, ["text"]),
            _ctx.task.dueDate ? (openBlock(), createElementBlock("div", {
              key: 0,
              class: normalizeClass(unref($style).dueDate)
            }, [
              createTextVNode(toDisplayString(unref(ddmmyyyy)(_ctx.task.dueDate)) + " ", 1),
              _ctx.task.recurring ? (openBlock(), createElementBlock("span", _hoisted_1, "(every " + toDisplayString(_ctx.task.recurring) + "d)", 1)) : createCommentVNode("", true)
            ], 2)) : createCommentVNode("", true)
          ], 2)
        ], 2),
        (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.task.subtasks ?? [], (x) => {
          return openBlock(), createBlock(_component_TaskItem, {
            key: x.id,
            list: _ctx.list,
            task: x,
            subtask: ""
          }, null, 8, ["list", "task"]);
        }), 128))
      ]);
    };
  }
});
export {
  _sfc_main as default
};
