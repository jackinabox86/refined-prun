import { sumBy } from "../../../utils/sum-by.js";
import { showTileOverlay, showConfirmationOverlay } from "../../../infrastructure/prun-ui/tile-overlay.js";
import _sfc_main$1 from "../../../components/PrunButton.vue.js";
import _sfc_main$2 from "../../../components/ActionBar.vue.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import { userData } from "../../../store/user-data.js";
import { vDraggable as so } from "../../../../npm/vue-draggable-plus@0.6.0_@types+sortablejs@1.15.8-vue-draggable-plus-vue-draggable-plus.js";
import _sfc_main$3 from "./CreateTaskList.vue.js";
import { createId } from "../../../store/create-id.js";
import removeArrayElement from "../../../utils/remove-array-element.js";
import PrunLink from "../../../components/PrunLink.vue.js";
import { ddmmyyyy } from "../../../utils/format.js";
import { grip } from "../../../components/grip/index.js";
import GripCell from "../../../components/grip/GripCell.vue.js";
import GripHeaderCell from "../../../components/grip/GripHeaderCell.vue.js";
import { defineComponent, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, withDirectives, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "TaskLists",
  setup(__props) {
    function createNewList(ev) {
      showTileOverlay(ev, _sfc_main$3, {
        onCreate: (name) => {
          const id = createId();
          userData.todo.push({ id, name, tasks: [] });
          showBuffer(`XIT TODO ${id.substring(0, 8)}`);
        }
      });
    }
    function confirmDelete(ev, list) {
      showConfirmationOverlay(ev, () => removeArrayElement(userData.todo, list), {
        message: `Are you sure you want to delete the task list "${list.name}"?`
      });
    }
    function countCompletedTasks(list) {
      return sumBy(list.tasks, (x) => x.completed ? 1 : 0);
    }
    function getDueDate(list) {
      const dates = [];
      const add = (task) => {
        if (task.dueDate !== void 0) {
          dates.push(task.dueDate);
        }
        for (const subtask of task.subtasks ?? []) {
          add(subtask);
        }
      };
      for (const task of list.tasks) {
        add(task);
      }
      if (dates.length === 0) {
        return void 0;
      }
      dates.sort();
      return ddmmyyyy(dates[0]);
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(_sfc_main$2, null, {
          default: withCtx(() => [
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: createNewList
            }, {
              default: withCtx(() => [..._cache[0] || (_cache[0] = [
                createTextVNode("CREATE NEW", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        }),
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createVNode(GripHeaderCell),
              _cache[1] || (_cache[1] = createBaseVNode("th", null, "Name", -1)),
              _cache[2] || (_cache[2] = createBaseVNode("th", null, "Tasks", -1)),
              _cache[3] || (_cache[3] = createBaseVNode("th", null, "Due Date", -1)),
              _cache[4] || (_cache[4] = createBaseVNode("th", null, null, -1))
            ])
          ]),
          withDirectives((openBlock(), createElementBlock("tbody", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(userData).todo, (list) => {
              return openBlock(), createElementBlock("tr", {
                key: list.id
              }, [
                createVNode(GripCell),
                createBaseVNode("td", null, [
                  createVNode(PrunLink, {
                    inline: "",
                    command: `XIT TODO ${list.id.substring(0, 8)}`
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(list.name), 1)
                    ]),
                    _: 2
                  }, 1032, ["command"])
                ]),
                createBaseVNode("td", null, [
                  createBaseVNode("span", null, toDisplayString(countCompletedTasks(list)) + "/" + toDisplayString(list.tasks.length), 1)
                ]),
                createBaseVNode("td", null, [
                  createBaseVNode("span", null, toDisplayString(getDueDate(list)), 1)
                ]),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$1, {
                    danger: "",
                    onClick: ($event) => confirmDelete($event, list)
                  }, {
                    default: withCtx(() => [..._cache[5] || (_cache[5] = [
                      createTextVNode("DELETE", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ])
              ]);
            }), 128))
          ])), [
            [unref(so), [unref(userData).todo, unref(grip).draggable]]
          ])
        ])
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
