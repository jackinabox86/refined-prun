import { getPlanetBurn, computeNeed } from "../../../core/burn.js";
import { materialsStore } from "../../../infrastructure/prun-api/data/materials.js";
import { userData } from "../../../store/user-data.js";
import VisitationTable from "./VisitationTable.vue.js";
import { fixed0, percent0, fixed01 } from "../../../utils/format.js";
import { formatDays } from "./utils.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, createTextVNode, createCommentVNode, createVNode, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "BaseDetail",
  props: {
    analysis: {}
  },
  setup(__props) {
    const planetBurn = computed(() => getPlanetBurn(__props.analysis.siteId));
    const shippingOut = computed(() => {
      const pb = planetBurn.value;
      if (!pb) {
        return [];
      }
      const rows = [];
      for (const ticker of Object.keys(pb.burn)) {
        const mb = pb.burn[ticker];
        if (mb.dailyAmount <= 0 || mb.inventory <= 0) {
          continue;
        }
        const mat = materialsStore.getByTicker(ticker);
        if (!mat) {
          continue;
        }
        rows.push({
          ticker,
          amount: mb.inventory,
          weight: mb.inventory * mat.weight,
          volume: mb.inventory * mat.volume
        });
      }
      rows.sort((a, b) => b.weight - a.weight);
      return rows;
    });
    const adding = computed(() => {
      const pb = planetBurn.value;
      if (!pb) {
        return [];
      }
      const resupply = userData.settings.burn.resupply;
      const rows = [];
      for (const ticker of Object.keys(pb.burn)) {
        const mb = pb.burn[ticker];
        const need = computeNeed(mb, resupply);
        if (need <= 0) {
          continue;
        }
        const mat = materialsStore.getByTicker(ticker);
        if (!mat) {
          continue;
        }
        rows.push({
          ticker,
          amount: need,
          weight: need * mat.weight,
          volume: need * mat.volume
        });
      }
      rows.sort((a, b) => b.weight - a.weight);
      return rows;
    });
    const afterShipOutWeightLoad = computed(
      () => __props.analysis.weightCapacity - __props.analysis.availableAfterShipOutWeight
    );
    const afterShipOutVolumeLoad = computed(
      () => __props.analysis.volumeCapacity - __props.analysis.availableAfterShipOutVolume
    );
    const afterResupplyWeightLoad = computed(
      () => __props.analysis.weightCapacity * __props.analysis.needFillPercentWeight
    );
    const afterResupplyVolumeLoad = computed(
      () => __props.analysis.volumeCapacity * __props.analysis.needFillPercentVolume
    );
    const fillPercent = computed(() => Math.round((1 - __props.analysis.suppliesReserveFraction) * 100));
    const reservePercent = computed(() => Math.round(__props.analysis.suppliesReserveFraction * 100));
    const reserveReason = computed(
      () => __props.analysis.suppliesReserveFraction >= 0.2 ? "produced goods" : "production variance"
    );
    const bindingLabel = computed(() => {
      if (__props.analysis.bindingLimit === "t") {
        return "Weight (t) is the binding dimension";
      }
      if (__props.analysis.bindingLimit === "m³") {
        return "Volume (m³) is the binding dimension";
      }
      return "Storage draining — nothing is actively filling it";
    });
    const overflowAmount = computed(() => {
      const w = afterResupplyWeightLoad.value - __props.analysis.weightCapacity;
      const v = afterResupplyVolumeLoad.value - __props.analysis.volumeCapacity;
      return { w, v };
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(_ctx.$style.detail)
      }, [
        createBaseVNode("section", {
          class: normalizeClass([_ctx.$style.panel, _ctx.$style.blue])
        }, [
          createBaseVNode("h3", {
            class: normalizeClass(_ctx.$style.title)
          }, "Fill Summary", 2),
          createBaseVNode("table", {
            class: normalizeClass(_ctx.$style.numTable)
          }, [
            _cache[2] || (_cache[2] = createBaseVNode("thead", null, [
              createBaseVNode("tr", null, [
                createBaseVNode("th"),
                createBaseVNode("th", null, "Weight (t)"),
                createBaseVNode("th", null, "Weight %"),
                createBaseVNode("th", null, "Volume (m³)"),
                createBaseVNode("th", null, "Volume %")
              ])
            ], -1)),
            createBaseVNode("tbody", null, [
              createBaseVNode("tr", null, [
                createBaseVNode("th", {
                  class: normalizeClass(_ctx.$style.rowLabel)
                }, "Capacity", 2),
                createBaseVNode("td", null, toDisplayString(unref(fixed0)(_ctx.analysis.weightCapacity)), 1),
                _cache[0] || (_cache[0] = createBaseVNode("td", null, "—", -1)),
                createBaseVNode("td", null, toDisplayString(unref(fixed0)(_ctx.analysis.volumeCapacity)), 1),
                _cache[1] || (_cache[1] = createBaseVNode("td", null, "—", -1))
              ]),
              createBaseVNode("tr", null, [
                createBaseVNode("th", {
                  class: normalizeClass(_ctx.$style.rowLabel)
                }, "Now", 2),
                createBaseVNode("td", null, toDisplayString(unref(fixed0)(_ctx.analysis.weightLoad)), 1),
                createBaseVNode("td", null, toDisplayString(unref(percent0)(_ctx.analysis.fillPercentWeight)), 1),
                createBaseVNode("td", null, toDisplayString(unref(fixed0)(_ctx.analysis.volumeLoad)), 1),
                createBaseVNode("td", null, toDisplayString(unref(percent0)(_ctx.analysis.fillPercentVolume)), 1)
              ]),
              createBaseVNode("tr", null, [
                createBaseVNode("th", {
                  class: normalizeClass(_ctx.$style.rowLabel)
                }, "After ship-out", 2),
                createBaseVNode("td", null, toDisplayString(unref(fixed0)(unref(afterShipOutWeightLoad))), 1),
                createBaseVNode("td", null, toDisplayString(unref(percent0)(unref(afterShipOutWeightLoad) / _ctx.analysis.weightCapacity)), 1),
                createBaseVNode("td", null, toDisplayString(unref(fixed0)(unref(afterShipOutVolumeLoad))), 1),
                createBaseVNode("td", null, toDisplayString(unref(percent0)(unref(afterShipOutVolumeLoad) / _ctx.analysis.volumeCapacity)), 1)
              ]),
              createBaseVNode("tr", {
                class: normalizeClass({ [_ctx.$style.danger]: _ctx.analysis.needFillRatio > 1 })
              }, [
                createBaseVNode("th", {
                  class: normalizeClass(_ctx.$style.rowLabel)
                }, "After resupply", 2),
                createBaseVNode("td", null, toDisplayString(unref(fixed0)(unref(afterResupplyWeightLoad))), 1),
                createBaseVNode("td", null, toDisplayString(unref(percent0)(_ctx.analysis.needFillPercentWeight)), 1),
                createBaseVNode("td", null, toDisplayString(unref(fixed0)(unref(afterResupplyVolumeLoad))), 1),
                createBaseVNode("td", null, toDisplayString(unref(percent0)(_ctx.analysis.needFillPercentVolume)), 1)
              ], 2)
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.note)
          }, toDisplayString(unref(bindingLabel)) + ".", 3),
          unref(overflowAmount).w > 0 ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass([_ctx.$style.note, _ctx.$style.alertText])
          }, [
            _cache[3] || (_cache[3] = createTextVNode(" Weight overflow after resupply: ", -1)),
            createBaseVNode("b", null, toDisplayString(unref(fixed0)(unref(overflowAmount).w)) + " t over capacity", 1)
          ], 2)) : createCommentVNode("", true),
          unref(overflowAmount).v > 0 ? (openBlock(), createElementBlock("div", {
            key: 1,
            class: normalizeClass([_ctx.$style.note, _ctx.$style.alertText])
          }, [
            _cache[4] || (_cache[4] = createTextVNode(" Volume overflow after resupply: ", -1)),
            createBaseVNode("b", null, toDisplayString(unref(fixed0)(unref(overflowAmount).v)) + " m³ over capacity", 1)
          ], 2)) : createCommentVNode("", true),
          unref(overflowAmount).w <= 0 && unref(overflowAmount).v <= 0 ? (openBlock(), createElementBlock("div", {
            key: 2,
            class: normalizeClass(_ctx.$style.note)
          }, [
            _cache[5] || (_cache[5] = createTextVNode(" Headroom after resupply: ", -1)),
            createBaseVNode("b", null, toDisplayString(unref(fixed0)(_ctx.analysis.weightCapacity - unref(afterResupplyWeightLoad))) + " t / " + toDisplayString(unref(fixed0)(_ctx.analysis.volumeCapacity - unref(afterResupplyVolumeLoad))) + " m³ ", 1)
          ], 2)) : createCommentVNode("", true),
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.note)
          }, [
            _cache[6] || (_cache[6] = createTextVNode(" Full in ", -1)),
            createBaseVNode("b", null, toDisplayString(unref(formatDays)(_ctx.analysis.daysUntilFull)) + " days", 1),
            createTextVNode(" at net " + toDisplayString(unref(fixed01)(_ctx.analysis.exportWeight - _ctx.analysis.importWeight)) + " t / " + toDisplayString(unref(fixed01)(_ctx.analysis.exportVolume - _ctx.analysis.importVolume)) + " m³ per day. ", 1)
          ], 2)
        ], 2),
        createBaseVNode("section", {
          class: normalizeClass([_ctx.$style.panel, _ctx.$style.teal])
        }, [
          createBaseVNode("h3", {
            class: normalizeClass(_ctx.$style.title)
          }, "Visitation Frequency", 2),
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.note)
          }, " How long before a ship of this size would be needed, given current import/export rates. ", 2),
          createVNode(VisitationTable, { analysis: _ctx.analysis }, null, 8, ["analysis"])
        ], 2),
        createBaseVNode("section", {
          class: normalizeClass([_ctx.$style.panel, _ctx.$style.green])
        }, [
          createBaseVNode("h3", {
            class: normalizeClass(_ctx.$style.title)
          }, "Days of Supplies That Fit", 2),
          !isFinite(_ctx.analysis.daysOfSuppliesFit) ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass(_ctx.$style.big)
          }, " ∞ (no active consumers) ", 2)) : (openBlock(), createElementBlock("div", {
            key: 1,
            class: normalizeClass(_ctx.$style.big)
          }, toDisplayString(unref(fixed01)(_ctx.analysis.daysOfSuppliesFit)) + " days", 3)),
          isFinite(_ctx.analysis.daysOfSuppliesFit) ? (openBlock(), createElementBlock("div", {
            key: 2,
            class: normalizeClass(_ctx.$style.note)
          }, [
            _cache[7] || (_cache[7] = createTextVNode(" Total consumables the base holds when filled to ", -1)),
            createBaseVNode("b", null, toDisplayString(unref(fillPercent)) + "%", 1),
            createTextVNode(" after ship-out (" + toDisplayString(unref(reservePercent)) + "% reserved for " + toDisplayString(unref(reserveReason)) + "). Includes consumables already in storage. ", 1)
          ], 2)) : createCommentVNode("", true),
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.note)
          }, "Current resupply target: " + toDisplayString(unref(userData).settings.burn.resupply) + " days.", 3)
        ], 2),
        createBaseVNode("section", {
          class: normalizeClass([_ctx.$style.panel, _ctx.$style.orange])
        }, [
          createBaseVNode("h3", {
            class: normalizeClass(_ctx.$style.title)
          }, "Shipping Out (" + toDisplayString(unref(shippingOut).length) + " materials)", 3),
          unref(shippingOut).length === 0 ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass(_ctx.$style.empty)
          }, "No produced goods in storage.", 2)) : (openBlock(), createElementBlock("table", {
            key: 1,
            class: normalizeClass(_ctx.$style.numTable)
          }, [
            _cache[8] || (_cache[8] = createBaseVNode("thead", null, [
              createBaseVNode("tr", null, [
                createBaseVNode("th", null, "Ticker"),
                createBaseVNode("th", null, "Amount"),
                createBaseVNode("th", null, "Weight (t)"),
                createBaseVNode("th", null, "Volume (m³)")
              ])
            ], -1)),
            createBaseVNode("tbody", null, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(shippingOut), (row) => {
                return openBlock(), createElementBlock("tr", {
                  key: row.ticker
                }, [
                  createBaseVNode("td", null, toDisplayString(row.ticker), 1),
                  createBaseVNode("td", null, toDisplayString(unref(fixed0)(row.amount)), 1),
                  createBaseVNode("td", null, toDisplayString(unref(fixed01)(row.weight)), 1),
                  createBaseVNode("td", null, toDisplayString(unref(fixed01)(row.volume)), 1)
                ]);
              }), 128))
            ])
          ], 2))
        ], 2),
        createBaseVNode("section", {
          class: normalizeClass([_ctx.$style.panel, _ctx.$style.purple])
        }, [
          createBaseVNode("h3", {
            class: normalizeClass(_ctx.$style.title)
          }, "Adding — Resupply Needs (" + toDisplayString(unref(adding).length) + " materials)", 3),
          unref(adding).length === 0 ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass(_ctx.$style.empty)
          }, "Nothing needs resupply right now.", 2)) : (openBlock(), createElementBlock("table", {
            key: 1,
            class: normalizeClass(_ctx.$style.numTable)
          }, [
            _cache[9] || (_cache[9] = createBaseVNode("thead", null, [
              createBaseVNode("tr", null, [
                createBaseVNode("th", null, "Ticker"),
                createBaseVNode("th", null, "Need"),
                createBaseVNode("th", null, "Weight (t)"),
                createBaseVNode("th", null, "Volume (m³)")
              ])
            ], -1)),
            createBaseVNode("tbody", null, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(adding), (row) => {
                return openBlock(), createElementBlock("tr", {
                  key: row.ticker
                }, [
                  createBaseVNode("td", null, toDisplayString(row.ticker), 1),
                  createBaseVNode("td", null, toDisplayString(unref(fixed0)(row.amount)), 1),
                  createBaseVNode("td", null, toDisplayString(unref(fixed01)(row.weight)), 1),
                  createBaseVNode("td", null, toDisplayString(unref(fixed01)(row.volume)), 1)
                ]);
              }), 128))
            ])
          ], 2))
        ], 2)
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
