import { createTileStateHook } from "../../../store/user-data-tiles.js";
const useTileState = createTileStateHook({
  expand: []
});
export {
  useTileState
};
