const detail = "rp-BaseDetail__detail___e4d72c4";
const panel = "rp-BaseDetail__panel___c14a179";
const title = "rp-BaseDetail__title___3ce7208";
const numTable = "rp-BaseDetail__numTable___7421137";
const rowLabel = "rp-BaseDetail__rowLabel___e9c7d86";
const note = "rp-BaseDetail__note___b1e034a";
const alertText = "rp-BaseDetail__alertText___627b57b";
const big = "rp-BaseDetail__big___7c7973e";
const empty = "rp-BaseDetail__empty___a212be2";
const danger = "rp-BaseDetail__danger___797125c";
const blue = "rp-BaseDetail__blue___664d9fe";
const green = "rp-BaseDetail__green___7c47555";
const orange = "rp-BaseDetail__orange___43ce1ef";
const purple = "rp-BaseDetail__purple___4936ddd";
const teal = "rp-BaseDetail__teal___af484d7";
const style0 = {
  detail,
  panel,
  title,
  numTable,
  rowLabel,
  note,
  alertText,
  big,
  empty,
  danger,
  blue,
  green,
  orange,
  purple,
  teal
};
export {
  alertText,
  big,
  blue,
  danger,
  style0 as default,
  detail,
  empty,
  green,
  note,
  numTable,
  orange,
  panel,
  purple,
  rowLabel,
  teal,
  title
};
