import { shipsStore } from "../../../infrastructure/prun-api/data/ships.js";
import { storagesStore } from "../../../infrastructure/prun-api/data/storage.js";
import { fixed0 } from "../../../utils/format.js";
import { formatDays } from "./utils.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "VisitationTable",
  props: {
    analysis: {}
  },
  setup(__props) {
    const rows = computed(() => {
      const ships = shipsStore.all.value;
      if (!ships) {
        return [];
      }
      const seen = /* @__PURE__ */ new Map();
      for (const ship of ships) {
        const store = storagesStore.getById(ship.idShipStore);
        if (!store) {
          continue;
        }
        const key = `${store.weightCapacity}|${store.volumeCapacity}`;
        if (!seen.has(key)) {
          seen.set(key, { shipT: store.weightCapacity, shipM3: store.volumeCapacity });
        }
      }
      const sorted = [...seen.values()].sort(
        (a, b) => a.shipT !== b.shipT ? a.shipT - b.shipT : a.shipM3 - b.shipM3
      );
      return sorted.map(({ shipT, shipM3 }) => {
        const expT = __props.analysis.exportWeight > 0 ? shipT / __props.analysis.exportWeight : Infinity;
        const expV = __props.analysis.exportVolume > 0 ? shipM3 / __props.analysis.exportVolume : Infinity;
        const impT = __props.analysis.importWeight > 0 ? shipT / __props.analysis.importWeight : Infinity;
        const impV = __props.analysis.importVolume > 0 ? shipM3 / __props.analysis.importVolume : Infinity;
        const exportDays = Math.min(expT, expV);
        const importDays = Math.min(impT, impV);
        const exportLimit = exportDays === Infinity ? void 0 : expT < expV ? "t" : "m³";
        const importLimit = importDays === Infinity ? void 0 : impT < impV ? "t" : "m³";
        return { shipT, shipM3, exportDays, exportLimit, importDays, importLimit };
      });
    });
    return (_ctx, _cache) => {
      return unref(rows).length === 0 ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: normalizeClass(_ctx.$style.empty)
      }, "No ships in fleet", 2)) : (openBlock(), createElementBlock("table", {
        key: 1,
        class: normalizeClass(_ctx.$style.table)
      }, [
        _cache[0] || (_cache[0] = createBaseVNode("thead", null, [
          createBaseVNode("tr", null, [
            createBaseVNode("th", { rowspan: "2" }, "Ship t"),
            createBaseVNode("th", { rowspan: "2" }, "Ship m³"),
            createBaseVNode("th", { colspan: "2" }, "Export Frequency"),
            createBaseVNode("th", { colspan: "2" }, "Import Frequency")
          ]),
          createBaseVNode("tr", null, [
            createBaseVNode("th", null, "Visitation (days)"),
            createBaseVNode("th", null, "Limit"),
            createBaseVNode("th", null, "Visitation (days)"),
            createBaseVNode("th", null, "Limit")
          ])
        ], -1)),
        createBaseVNode("tbody", null, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(rows), (row) => {
            return openBlock(), createElementBlock("tr", {
              key: `${row.shipT}|${row.shipM3}`
            }, [
              createBaseVNode("td", null, toDisplayString(unref(fixed0)(row.shipT)), 1),
              createBaseVNode("td", null, toDisplayString(unref(fixed0)(row.shipM3)), 1),
              createBaseVNode("td", null, toDisplayString(unref(formatDays)(row.exportDays)), 1),
              createBaseVNode("td", null, toDisplayString(row.exportLimit ?? "—"), 1),
              createBaseVNode("td", null, toDisplayString(unref(formatDays)(row.importDays)), 1),
              createBaseVNode("td", null, toDisplayString(row.importLimit ?? "—"), 1)
            ]);
          }), 128))
        ])
      ], 2));
    };
  }
});
export {
  _sfc_main as default
};
