import { getBaseStorageAnalysis } from "../../../core/storage-analysis.js";
import BaseHeader from "./BaseHeader.vue.js";
import _sfc_main$2 from "./BaseSection.vue.js";
import LoadingSpinner from "../../../components/LoadingSpinner.vue.js";
import InlineFlex from "../../../components/InlineFlex.vue.js";
import _sfc_main$1 from "../../../components/Tooltip.vue.js";
import { useTileState } from "./tile-state.js";
import { useXitParameters } from "../../../hooks/use-xit-parameters.js";
import { sitesStore } from "../../../infrastructure/prun-api/data/sites.js";
import { comparePlanets } from "../../../util.js";
import { defineComponent, computed, watchEffect, openBlock, createBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _hoisted_1 = { key: 3 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "STO",
  setup(__props) {
    const fakeAnalysis = {
      siteId: "",
      storeId: "",
      planetName: "Placeholder",
      naturalId: "",
      weightCapacity: 1,
      weightLoad: 0.5,
      volumeCapacity: 1,
      volumeLoad: 0.5,
      importWeight: 0,
      importVolume: 0,
      exportWeight: 0,
      exportVolume: 0,
      fillPercentWeight: 0.5,
      fillPercentVolume: 0.5,
      fillPercentWeightNoInf: 0.5,
      fillPercentVolumeNoInf: 0.5,
      needFillPercentWeight: 0.5,
      needFillPercentVolume: 0.5,
      needFillRatio: 0.5,
      availableAfterShipOutWeight: 0.5,
      availableAfterShipOutVolume: 0.5,
      daysOfSuppliesFit: 10,
      suppliesReserveFraction: 0.2,
      daysUntilFull: 10,
      bindingLimit: "t"
    };
    const parameters = useXitParameters();
    const expand = useTileState("expand");
    const analyses = computed(() => {
      if (!sitesStore.all.value) {
        return void 0;
      }
      let sites = sitesStore.all.value;
      if (parameters[0]) {
        const match = sitesStore.getByPlanetNaturalIdOrName(parameters[0]);
        sites = match ? [match] : [];
      }
      const result = sites.map(getBaseStorageAnalysis).filter((x) => !!x);
      result.sort((a, b) => {
        const aInf = !isFinite(a.daysUntilFull);
        const bInf = !isFinite(b.daysUntilFull);
        if (aInf && bInf) {
          return a.planetName.localeCompare(b.planetName);
        }
        if (aInf !== bInf) {
          return aInf ? 1 : -1;
        }
        if (a.daysUntilFull !== b.daysUntilFull) {
          return a.daysUntilFull - b.daysUntilFull;
        }
        return comparePlanets(a.naturalId, b.naturalId);
      });
      return result;
    });
    watchEffect(() => {
      if (parameters[0] && analyses.value?.length === 1) {
        const naturalId = analyses.value[0].naturalId;
        if (!expand.value.includes(naturalId)) {
          expand.value = [...expand.value, naturalId];
        }
      }
    });
    const noMatch = computed(
      () => !!parameters[0] && analyses.value !== void 0 && analyses.value.length === 0
    );
    return (_ctx, _cache) => {
      return unref(analyses) === void 0 ? (openBlock(), createBlock(LoadingSpinner, { key: 0 })) : unref(noMatch) ? (openBlock(), createElementBlock("div", {
        key: 1,
        class: normalizeClass(_ctx.$style.empty)
      }, 'No base matches "' + toDisplayString(unref(parameters)[0]) + '"', 3)) : unref(analyses).length === 0 ? (openBlock(), createElementBlock("div", {
        key: 2,
        class: normalizeClass(_ctx.$style.empty)
      }, "No bases yet", 2)) : (openBlock(), createElementBlock("table", _hoisted_1, [
        createBaseVNode("thead", null, [
          createBaseVNode("tr", null, [
            createBaseVNode("th", {
              class: normalizeClass(_ctx.$style.planet)
            }, "Planet", 2),
            createBaseVNode("th", null, [
              createVNode(InlineFlex, null, {
                default: withCtx(() => [
                  _cache[0] || (_cache[0] = createTextVNode(" Days Till Full ", -1)),
                  createVNode(_sfc_main$1, {
                    position: "bottom",
                    tooltip: "Days until storage is full at the current net production rate — when a ship visit is forced."
                  })
                ]),
                _: 1
              })
            ]),
            createBaseVNode("th", null, [
              createVNode(InlineFlex, null, {
                default: withCtx(() => [
                  _cache[1] || (_cache[1] = createTextVNode(" Supply Days ", -1)),
                  createVNode(_sfc_main$1, {
                    position: "bottom",
                    tooltip: "Total days of consumables the base could hold when storage is filled to its threshold after ship-out (80% when filling, 95% when draining). Colors match XIT BURN: red below your red threshold, yellow below your yellow threshold."
                  })
                ]),
                _: 1
              })
            ]),
            createBaseVNode("th", null, [
              createVNode(InlineFlex, null, {
                default: withCtx(() => [
                  _cache[2] || (_cache[2] = createTextVNode(" Current Fill ", -1)),
                  createVNode(_sfc_main$1, {
                    position: "bottom",
                    tooltip: "What's in base storage right now. Colored by material category."
                  })
                ]),
                _: 1
              })
            ]),
            createBaseVNode("th", null, [
              createVNode(InlineFlex, null, {
                default: withCtx(() => [
                  _cache[3] || (_cache[3] = createTextVNode(" After Resupply ", -1)),
                  createVNode(_sfc_main$1, {
                    position: "bottom",
                    tooltip: "Projected storage if all produced goods were shipped out and all consumables delivered up to their XIT BURN Need amount. Red hatching shows overflow past capacity."
                  })
                ]),
                _: 1
              })
            ]),
            _cache[4] || (_cache[4] = createBaseVNode("th", null, "CMD", -1))
          ])
        ]),
        createBaseVNode("tbody", {
          class: normalizeClass(_ctx.$style.fakeRow)
        }, [
          createVNode(BaseHeader, {
            analysis: fakeAnalysis,
            "on-click": () => {
            }
          })
        ], 2),
        (openBlock(true), createElementBlock(Fragment, null, renderList(unref(analyses), (analysis) => {
          return openBlock(), createBlock(_sfc_main$2, {
            key: analysis.siteId,
            "can-minimize": "",
            analysis
          }, null, 8, ["analysis"]);
        }), 128))
      ]));
    };
  }
});
export {
  _sfc_main as default
};
