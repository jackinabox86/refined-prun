import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import { buildProjectedStore } from "../../../core/storage-analysis.js";
import { storagesStore } from "../../../infrastructure/prun-api/data/storage.js";
import { userData } from "../../../store/user-data.js";
import _sfc_main$1 from "../../../components/PrunButton.vue.js";
import CargoBar from "../../../components/CargoBar.vue.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import { fillRatioClass, formatDays, formatDaysCompact } from "./utils.js";
import { fixed01 } from "../../../utils/format.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, createCommentVNode, createVNode, withCtx, createTextVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = ["data-tooltip"];
const _hoisted_2 = ["data-tooltip"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "BaseHeader",
  props: {
    analysis: {},
    hasMinimize: { type: Boolean },
    minimized: { type: Boolean },
    onClick: { type: Function }
  },
  setup(__props) {
    const currentStore = computed(() => storagesStore.getById(__props.analysis.storeId));
    const projectedStore = computed(() => buildProjectedStore(__props.analysis.siteId));
    const stripeClass = computed(() => {
      if (__props.analysis.needFillRatio === 0) {
        return void 0;
      }
      return fillRatioClass(__props.analysis.needFillRatio);
    });
    const limitTooltip = computed(() => {
      if (__props.analysis.bindingLimit === void 0) {
        return "Storage draining — not filling.";
      }
      return __props.analysis.bindingLimit === "t" ? "Weight is the binding limit." : "Volume is the binding limit.";
    });
    const supplyTooltip = computed(() => {
      if (!isFinite(__props.analysis.daysOfSuppliesFit)) {
        return "No active consumers — no supplies needed.";
      }
      const pct = Math.round((1 - __props.analysis.suppliesReserveFraction) * 100);
      const reason = __props.analysis.suppliesReserveFraction >= 0.2 ? "produced goods that keep accumulating" : "production variance";
      return `${fixed01(__props.analysis.daysOfSuppliesFit)} days total when storage is filled to ${pct}% after ship-out (remainder reserved for ${reason}).`;
    });
    const supplyClass = computed(() => {
      const floored = Math.floor(__props.analysis.daysOfSuppliesFit);
      if (!isFinite(__props.analysis.daysOfSuppliesFit)) {
        return void 0;
      }
      return {
        [C.Workforces.daysMissing]: floored <= userData.settings.burn.red,
        [C.Workforces.daysWarning]: floored <= userData.settings.burn.yellow,
        [C.Workforces.daysSupplied]: floored > userData.settings.burn.yellow
      };
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("tr", {
        class: normalizeClass(_ctx.$style.row)
      }, [
        createBaseVNode("td", {
          class: normalizeClass([_ctx.$style.planet, _ctx.$style.clickable]),
          onClick: _cache[0] || (_cache[0] = //@ts-ignore
          (...args) => _ctx.onClick && _ctx.onClick(...args))
        }, [
          unref(stripeClass) ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass([_ctx.$style.stripe, unref(stripeClass)])
          }, null, 2)) : createCommentVNode("", true),
          _ctx.hasMinimize ? (openBlock(), createElementBlock("span", {
            key: 1,
            class: normalizeClass(_ctx.$style.minimize)
          }, toDisplayString(_ctx.minimized ? "+" : "-"), 3)) : createCommentVNode("", true),
          createBaseVNode("span", null, toDisplayString(_ctx.analysis.planetName), 1)
        ], 2),
        createBaseVNode("td", {
          class: normalizeClass(_ctx.$style.clickable),
          onClick: _cache[1] || (_cache[1] = //@ts-ignore
          (...args) => _ctx.onClick && _ctx.onClick(...args))
        }, [
          createBaseVNode("span", {
            "data-tooltip": unref(limitTooltip),
            "data-tooltip-position": "bottom"
          }, toDisplayString(unref(formatDays)(_ctx.analysis.daysUntilFull)), 9, _hoisted_1)
        ], 2),
        createBaseVNode("td", {
          class: normalizeClass([_ctx.$style.clickable, _ctx.$style.supplyCell]),
          onClick: _cache[2] || (_cache[2] = //@ts-ignore
          (...args) => _ctx.onClick && _ctx.onClick(...args))
        }, [
          unref(supplyClass) ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass([_ctx.$style.supplyBg, unref(supplyClass)])
          }, null, 2)) : createCommentVNode("", true),
          createBaseVNode("span", {
            "data-tooltip": unref(supplyTooltip),
            "data-tooltip-position": "bottom"
          }, toDisplayString(unref(formatDaysCompact)(_ctx.analysis.daysOfSuppliesFit)), 9, _hoisted_2)
        ], 2),
        createBaseVNode("td", {
          class: normalizeClass([_ctx.$style.clickable, _ctx.$style.barCell]),
          onClick: _cache[3] || (_cache[3] = //@ts-ignore
          (...args) => _ctx.onClick && _ctx.onClick(...args))
        }, [
          createVNode(CargoBar, {
            store: unref(currentStore),
            "disable-mini-mode": ""
          }, null, 8, ["store"])
        ], 2),
        createBaseVNode("td", {
          class: normalizeClass([_ctx.$style.clickable, _ctx.$style.barCell]),
          onClick: _cache[4] || (_cache[4] = //@ts-ignore
          (...args) => _ctx.onClick && _ctx.onClick(...args))
        }, [
          createVNode(CargoBar, {
            store: unref(projectedStore),
            "disable-mini-mode": ""
          }, null, 8, ["store"])
        ], 2),
        createBaseVNode("td", null, [
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.buttons)
          }, [
            createVNode(_sfc_main$1, {
              dark: "",
              inline: "",
              onClick: _cache[5] || (_cache[5] = ($event) => unref(showBuffer)(`BS ${_ctx.analysis.naturalId}`))
            }, {
              default: withCtx(() => [..._cache[7] || (_cache[7] = [
                createTextVNode("BS", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              dark: "",
              inline: "",
              onClick: _cache[6] || (_cache[6] = ($event) => unref(showBuffer)(`INV ${_ctx.analysis.storeId.substring(0, 8)}`))
            }, {
              default: withCtx(() => [..._cache[8] || (_cache[8] = [
                createTextVNode(" INV ", -1)
              ])]),
              _: 1
            })
          ], 2)
        ])
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
