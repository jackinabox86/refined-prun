import _sfc_main from "./BaseSection.vue.js";
export {
  _sfc_main as default
};
