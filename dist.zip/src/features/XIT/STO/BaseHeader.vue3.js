const row = "rp-BaseHeader__row___f6de90d";
const planet = "rp-BaseHeader__planet___297652b";
const stripe = "rp-BaseHeader__stripe___52e2955";
const clickable = "rp-BaseHeader__clickable___f5bfd1a";
const minimize = "rp-BaseHeader__minimize___6a9ec50";
const buttons = "rp-BaseHeader__buttons___b2d323e";
const barCell = "rp-BaseHeader__barCell___6e39e3a";
const supplyCell = "rp-BaseHeader__supplyCell___fb6f4ab";
const supplyBg = "rp-BaseHeader__supplyBg___d9052bb";
const style0 = {
  row,
  planet,
  stripe,
  clickable,
  minimize,
  buttons,
  barCell,
  supplyCell,
  supplyBg
};
export {
  barCell,
  buttons,
  clickable,
  style0 as default,
  minimize,
  planet,
  row,
  stripe,
  supplyBg,
  supplyCell
};
