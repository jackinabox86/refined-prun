import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import { fixed01 } from "../../../utils/format.js";
function formatDays(days) {
  if (!isFinite(days) || days >= 1e3) {
    return "∞";
  }
  return fixed01(days);
}
function formatDaysCompact(days) {
  if (!isFinite(days) || days >= 1e3) {
    return "∞";
  }
  if (days > 100) {
    return "100+";
  }
  return fixed01(days);
}
function fillRatioClass(ratio) {
  if (ratio >= 0.95) {
    return C.Workforces.daysMissing;
  }
  if (ratio >= 0.8) {
    return C.Workforces.daysWarning;
  }
  return C.Workforces.daysSupplied;
}
export {
  fillRatioClass,
  formatDays,
  formatDaysCompact
};
