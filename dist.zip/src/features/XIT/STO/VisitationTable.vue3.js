const table = "rp-VisitationTable__table___a1a8cd4";
const empty = "rp-VisitationTable__empty___1889c42";
const style0 = {
  table,
  empty
};
export {
  style0 as default,
  empty,
  table
};
