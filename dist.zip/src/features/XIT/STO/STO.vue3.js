const planet = "rp-STO__planet___1b3811d";
const empty = "rp-STO__empty___80e0cb0";
const fakeRow = "rp-STO__fakeRow___325f846";
const style0 = {
  planet,
  empty,
  fakeRow
};
export {
  style0 as default,
  empty,
  fakeRow,
  planet
};
