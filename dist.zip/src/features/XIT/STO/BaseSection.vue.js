import BaseHeader from "./BaseHeader.vue.js";
import BaseDetail from "./BaseDetail.vue.js";
import { useTileState } from "./tile-state.js";
import { defineComponent, computed, openBlock, createElementBlock, Fragment, createElementVNode as createBaseVNode, createVNode, createCommentVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _hoisted_2 = { colspan: "6" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "BaseSection",
  props: {
    analysis: {},
    canMinimize: { type: Boolean }
  },
  setup(__props) {
    const expand = useTileState("expand");
    const naturalId = computed(() => __props.analysis.naturalId);
    const isMinimized = computed(() => __props.canMinimize && !expand.value.includes(naturalId.value));
    function onHeaderClick() {
      if (!__props.canMinimize) {
        return;
      }
      if (isMinimized.value) {
        expand.value = [...expand.value, naturalId.value];
      } else {
        expand.value = expand.value.filter((x) => x !== naturalId.value);
      }
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("tbody", null, [
          createVNode(BaseHeader, {
            "has-minimize": _ctx.canMinimize,
            analysis: _ctx.analysis,
            minimized: unref(isMinimized),
            "on-click": onHeaderClick
          }, null, 8, ["has-minimize", "analysis", "minimized"])
        ]),
        !unref(isMinimized) ? (openBlock(), createElementBlock("tbody", _hoisted_1, [
          createBaseVNode("tr", null, [
            createBaseVNode("td", _hoisted_2, [
              createVNode(BaseDetail, { analysis: _ctx.analysis }, null, 8, ["analysis"])
            ])
          ])
        ])) : createCommentVNode("", true)
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
