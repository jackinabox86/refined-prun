import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { sitesStore } from "../../infrastructure/prun-api/data/sites.js";
import { getEntityNameFromAddress } from "../../infrastructure/prun-api/data/addresses.js";
import { workforcesStore } from "../../infrastructure/prun-api/data/workforces.js";
import { productionStore } from "../../infrastructure/prun-api/data/production.js";
import { storagesStore } from "../../infrastructure/prun-api/data/storage.js";
import { warehousesStore } from "../../infrastructure/prun-api/data/warehouses.js";
import { contractsStore } from "../../infrastructure/prun-api/data/contracts.js";
import { cxosStore } from "../../infrastructure/prun-api/data/cxos.js";
import { fxosStore } from "../../infrastructure/prun-api/data/fxos.js";
import { balancesStore } from "../../infrastructure/prun-api/data/balances.js";
import { cxStore } from "../../infrastructure/fio/cx.js";
import { dayjsEachSecond } from "../../utils/dayjs.js";
import { objectId } from "../../utils/object-id.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, Fragment, renderList, createTextVNode } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { toDisplayString, normalizeClass } from "../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = { style: { paddingTop: "4px" } };
const _hoisted_2 = { style: { tableLayout: "fixed" } };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "HEALTH",
  setup(__props) {
    const bases = computed(() => {
      return sitesStore.all.value?.map((site) => ({
        name: getEntityNameFromAddress(site.address),
        workforce: !!workforcesStore.getById(site.siteId),
        production: !!productionStore.getBySiteId(site.siteId),
        storage: !!storagesStore.getByAddressableId(site.siteId)
      })) ?? [];
    });
    const otherData = computed(() => [
      ["Base Sites", sitesStore.all.value?.length],
      ["Warehouse Sites", warehousesStore.all.value?.length],
      ["Base Stores", storagesStore.getByType("STORE")?.length],
      ["Warehouse Stores", storagesStore.getByType("WAREHOUSE_STORE")?.length],
      ["Ship Stores", storagesStore.getByType("SHIP_STORE")?.length],
      ["Workforces", workforcesStore.all.value?.length],
      ["Production Sites", productionStore.all.value?.length],
      ["Contracts", contractsStore.all.value?.length],
      ["CXOS", cxosStore.all.value?.length],
      ["FXOS", fxosStore.all.value?.length],
      ["Currency", (balancesStore.all.value?.length ?? 0) > 0],
      ["Last CX Price Update", cxStore.fetched ? dayjsEachSecond.value.to(cxStore.age) : false]
    ]);
    const positive = C.ColoredValue.positive;
    const negative = C.ColoredValue.negative;
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        _cache[2] || (_cache[2] = createBaseVNode("span", { class: "title" }, "Bases", -1)),
        createBaseVNode("table", null, [
          _cache[0] || (_cache[0] = createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", null, "Planet"),
              createBaseVNode("th", null, "Workforce"),
              createBaseVNode("th", null, "Production"),
              createBaseVNode("th", null, "Storage")
            ])
          ], -1)),
          createBaseVNode("tbody", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(bases), (base) => {
              return openBlock(), createElementBlock("tr", {
                key: base.name
              }, [
                createBaseVNode("td", null, toDisplayString(base.name), 1),
                base.workforce ? (openBlock(), createElementBlock("td", {
                  key: 0,
                  class: normalizeClass(unref(positive))
                }, "✓", 2)) : (openBlock(), createElementBlock("td", {
                  key: 1,
                  class: normalizeClass(unref(negative))
                }, "✗", 2)),
                base.production ? (openBlock(), createElementBlock("td", {
                  key: 2,
                  class: normalizeClass(unref(positive))
                }, "✓", 2)) : (openBlock(), createElementBlock("td", {
                  key: 3,
                  class: normalizeClass(unref(negative))
                }, "✗", 2)),
                base.storage ? (openBlock(), createElementBlock("td", {
                  key: 4,
                  class: normalizeClass(unref(positive))
                }, "✓", 2)) : (openBlock(), createElementBlock("td", {
                  key: 5,
                  class: normalizeClass(unref(negative))
                }, "✗", 2))
              ]);
            }), 128))
          ])
        ]),
        _cache[3] || (_cache[3] = createBaseVNode("span", {
          class: "title",
          style: { "padding-top": "10px" }
        }, "Other Data", -1)),
        createBaseVNode("table", _hoisted_2, [
          _cache[1] || (_cache[1] = createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", null, "Parameter"),
              createBaseVNode("th", null, "Value")
            ])
          ], -1)),
          createBaseVNode("tbody", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(otherData), (other) => {
              return openBlock(), createElementBlock("tr", {
                key: unref(objectId)(other)
              }, [
                createBaseVNode("td", null, toDisplayString(other[0]), 1),
                createBaseVNode("td", null, [
                  other[1] === true ? (openBlock(), createElementBlock("span", {
                    key: 0,
                    class: normalizeClass(unref(positive))
                  }, "✓", 2)) : other[1] === false || other[1] === void 0 ? (openBlock(), createElementBlock("span", {
                    key: 1,
                    class: normalizeClass(unref(negative))
                  }, " ✗ ", 2)) : (openBlock(), createElementBlock(Fragment, { key: 2 }, [
                    createTextVNode(toDisplayString(other[1]), 1)
                  ], 64))
                ])
              ]);
            }), 128))
          ])
        ])
      ]);
    };
  }
});
export {
  _sfc_main as default
};
