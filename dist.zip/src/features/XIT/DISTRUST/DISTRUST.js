import xit from "../xit-registry.js";
import DISTRUST from "./DISTRUST.vue.js";
xit.add({
  command: "DISTRUST",
  name: "DISTRUSTED USERS",
  description: "Maintains a list of distrusted usernames highlighted across the UI.",
  component: () => DISTRUST,
  bufferSize: [400, 500]
});
