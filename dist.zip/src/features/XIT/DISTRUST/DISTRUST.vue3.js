const panel = "rp-DISTRUST__panel___06a7c37";
const hint = "rp-DISTRUST__hint___34b6d1d";
const textarea = "rp-DISTRUST__textarea___d70195f";
const style0 = {
  panel,
  hint,
  textarea
};
export {
  style0 as default,
  hint,
  panel,
  textarea
};
