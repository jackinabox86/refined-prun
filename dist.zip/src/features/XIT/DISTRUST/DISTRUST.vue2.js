import { vModelText } from "../../../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import { userData } from "../../../store/user-data.js";
import { setDistrustedUsernamesFromText } from "../../../store/distrust.js";
import { defineComponent, watch, openBlock, createElementBlock, createElementVNode as createBaseVNode, withDirectives } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { normalizeClass } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "DISTRUST",
  setup(__props) {
    const text = ref(userData.distrustedUsernames.join("\n"));
    watch(
      () => userData.distrustedUsernames,
      (list) => {
        const joined = list.join("\n");
        if (joined !== text.value.trim()) {
          text.value = joined;
        }
      }
    );
    function onInput() {
      setDistrustedUsernamesFromText(text.value);
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(_ctx.$style.panel)
      }, [
        createBaseVNode("div", {
          class: normalizeClass(_ctx.$style.hint)
        }, "One username per line. Paste from a spreadsheet column directly.", 2),
        withDirectives(createBaseVNode("textarea", {
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(text) ? text.value = $event : null),
          spellcheck: "false",
          class: normalizeClass(_ctx.$style.textarea),
          placeholder: "Euu\nAnotherName",
          onInput
        }, null, 34), [
          [vModelText, unref(text)]
        ])
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
