import xit from "./xit-registry.js";
import { castArray } from "../../utils/cast-array.js";
import PrunLink from "../../components/PrunLink.vue.js";
import { objectId } from "../../utils/object-id.js";
import { defineComponent, openBlock, createElementBlock, createElementVNode as createBaseVNode, Fragment, renderList, createVNode, withCtx, createTextVNode } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString } from "../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CMDS",
  setup(__props) {
    const sorted = xit.registry.sort((a, b) => {
      const commandA = castArray(a.command)[0];
      const commandB = castArray(b.command)[0];
      return commandA.localeCompare(commandB);
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("table", null, [
        _cache[0] || (_cache[0] = createBaseVNode("thead", null, [
          createBaseVNode("tr", null, [
            createBaseVNode("th", null, "Command"),
            createBaseVNode("th", null, "Description"),
            createBaseVNode("th", null, "Mandatory parameters"),
            createBaseVNode("th", null, "Optional parameters")
          ])
        ], -1)),
        createBaseVNode("tbody", null, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(sorted), (command) => {
            return openBlock(), createElementBlock("tr", {
              key: unref(objectId)(command)
            }, [
              createBaseVNode("td", null, [
                createVNode(PrunLink, {
                  command: "XIT " + unref(castArray)(command.command)[0],
                  "auto-submit": !command.mandatoryParameters
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(unref(castArray)(command.command)[0]), 1)
                  ]),
                  _: 2
                }, 1032, ["command", "auto-submit"])
              ]),
              createBaseVNode("td", null, toDisplayString(command.description), 1),
              createBaseVNode("td", null, toDisplayString(command.mandatoryParameters), 1),
              createBaseVNode("td", null, toDisplayString(command.optionalParameters), 1)
            ]);
          }), 128))
        ])
      ]);
    };
  }
});
export {
  _sfc_main as default
};
