import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import _sfc_main$2 from "../../../components/ActionBar.vue.js";
import _sfc_main$1 from "../../../components/PrunButton.vue.js";
import { createId } from "../../../store/create-id.js";
import PrunLink from "../../../components/PrunLink.vue.js";
import _sfc_main$3 from "../../../components/forms/TextInput.vue.js";
import { vDraggable as so } from "../../../../npm/vue-draggable-plus@0.6.0_@types+sortablejs@1.15.8-vue-draggable-plus-vue-draggable-plus.js";
import { grip } from "../../../components/grip/index.js";
import GripCell from "../../../components/grip/GripCell.vue.js";
import GripHeaderCell from "../../../components/grip/GripHeaderCell.vue.js";
import { defineComponent, openBlock, createElementBlock, createElementVNode as createBaseVNode, Fragment, renderList, createVNode, withCtx, createTextVNode, withDirectives } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { ref, unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _hoisted_2 = { key: 0 };
const _hoisted_3 = { key: 1 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CommandList",
  props: {
    list: {}
  },
  setup(__props) {
    const edit = ref(false);
    function addCommand() {
      __props.list.commands.push({
        id: createId(),
        label: "Help",
        command: "XIT HELP"
      });
    }
    function deleteCommand(command) {
      __props.list.commands = __props.list.commands.filter((x) => x !== command);
    }
    return (_ctx, _cache) => {
      return !unref(edit) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
        createBaseVNode("table", null, [
          _cache[3] || (_cache[3] = createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", null, "Commands")
            ])
          ], -1)),
          createBaseVNode("tbody", null, [
            _ctx.list.commands.length === 0 ? (openBlock(), createElementBlock("tr", _hoisted_1, [..._cache[2] || (_cache[2] = [
              createBaseVNode("td", null, "No commands.", -1)
            ])])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(_ctx.list.commands, (command) => {
              return openBlock(), createElementBlock("tr", {
                key: command.id
              }, [
                createBaseVNode("td", null, [
                  createVNode(PrunLink, {
                    command: command.command
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(command.label), 1)
                    ]),
                    _: 2
                  }, 1032, ["command"])
                ])
              ]);
            }), 128))
          ])
        ]),
        createVNode(_sfc_main$2, null, {
          default: withCtx(() => [
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: _cache[0] || (_cache[0] = ($event) => edit.value = true)
            }, {
              default: withCtx(() => [..._cache[4] || (_cache[4] = [
                createTextVNode("EDIT", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        })
      ], 64)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createVNode(GripHeaderCell),
              _cache[5] || (_cache[5] = createBaseVNode("th", null, "Label", -1)),
              _cache[6] || (_cache[6] = createBaseVNode("th", null, "Command", -1)),
              _cache[7] || (_cache[7] = createBaseVNode("th", null, null, -1))
            ])
          ]),
          _ctx.list.commands.length === 0 ? (openBlock(), createElementBlock("tbody", _hoisted_2, [..._cache[8] || (_cache[8] = [
            createBaseVNode("tr", null, [
              createBaseVNode("td", null, "No commands.")
            ], -1)
          ])])) : withDirectives((openBlock(), createElementBlock("tbody", _hoisted_3, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.list.commands, (command) => {
              return openBlock(), createElementBlock("tr", {
                key: command.id
              }, [
                createVNode(GripCell),
                createBaseVNode("td", null, [
                  createBaseVNode("div", {
                    class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).forms.input, _ctx.$style.inline])
                  }, [
                    createVNode(_sfc_main$3, {
                      modelValue: command.label,
                      "onUpdate:modelValue": ($event) => command.label = $event
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ], 2)
                ]),
                createBaseVNode("td", null, [
                  createBaseVNode("div", {
                    class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).forms.input)
                  }, [
                    createVNode(_sfc_main$3, {
                      modelValue: command.command,
                      "onUpdate:modelValue": ($event) => command.command = $event
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ], 2)
                ]),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$1, {
                    danger: "",
                    onClick: ($event) => deleteCommand(command)
                  }, {
                    default: withCtx(() => [..._cache[9] || (_cache[9] = [
                      createTextVNode("DELETE", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ])
              ]);
            }), 128))
          ])), [
            [unref(so), [_ctx.list.commands, unref(grip).draggable]]
          ])
        ]),
        createVNode(_sfc_main$2, null, {
          default: withCtx(() => [
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: addCommand
            }, {
              default: withCtx(() => [..._cache[10] || (_cache[10] = [
                createTextVNode("ADD COMMAND", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: _cache[1] || (_cache[1] = ($event) => edit.value = false)
            }, {
              default: withCtx(() => [..._cache[11] || (_cache[11] = [
                createTextVNode("DONE", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        })
      ], 64));
    };
  }
});
export {
  _sfc_main as default
};
