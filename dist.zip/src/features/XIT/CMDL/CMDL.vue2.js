import { useXitParameters } from "../../../hooks/use-xit-parameters.js";
import { userData } from "../../../store/user-data.js";
import _sfc_main$2 from "../../../components/PrunButton.vue.js";
import { createId } from "../../../store/create-id.js";
import _sfc_main$1 from "./CommandLists.vue.js";
import CommandList from "./CommandList.vue.js";
import { isEmpty } from "../../../../npm/ts-extras@0.15.0-ts-extras-is-empty.js";
import { defineComponent, computed, openBlock, createBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CMDL",
  setup(__props) {
    const parameters = useXitParameters();
    const name = parameters.join(" ");
    const list = computed(() => {
      const byId = userData.commandLists.find((x) => x.id.startsWith(parameters[0]));
      if (byId) {
        return byId;
      }
      return userData.commandLists.find((x) => x.name === name);
    });
    function onCreateClick() {
      userData.commandLists.push({
        id: createId(),
        name,
        commands: []
      });
    }
    return (_ctx, _cache) => {
      return unref(isEmpty)(unref(parameters)) ? (openBlock(), createBlock(_sfc_main$1, { key: 0 })) : unref(list) ? (openBlock(), createBlock(CommandList, {
        key: 1,
        list: unref(list)
      }, null, 8, ["list"])) : (openBlock(), createElementBlock("div", {
        key: 2,
        class: normalizeClass(_ctx.$style.create)
      }, [
        createBaseVNode("span", null, 'Command List "' + toDisplayString(unref(name)) + '" not found.', 1),
        createVNode(_sfc_main$2, {
          primary: "",
          class: normalizeClass(_ctx.$style.button),
          onClick: onCreateClick
        }, {
          default: withCtx(() => [..._cache[0] || (_cache[0] = [
            createTextVNode("CREATE", -1)
          ])]),
          _: 1
        }, 8, ["class"])
      ], 2));
    };
  }
});
export {
  _sfc_main as default
};
