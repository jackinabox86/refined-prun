import xit from "../xit-registry.js";
import LINKEDBUFFERS from "./LINKEDBUFFERS.vue.js";
import EditPreset from "./EditPreset.vue.js";
import { userData } from "../../../store/user-data.js";
import { isEmpty } from "../../../../npm/ts-extras@0.15.0-ts-extras-is-empty.js";
function findPreset(parameters) {
  const byId = userData.linkedBuffersPresets.find((x) => x.id.startsWith(parameters[0]));
  if (byId) {
    return byId;
  }
  return userData.linkedBuffersPresets.find((x) => x.name === parameters.join(" "));
}
function isEditMode(parameters) {
  return parameters[0]?.toUpperCase() === "EDIT";
}
xit.add({
  command: ["LINKEDBUFFERS", "LB"],
  name: (parameters) => {
    if (isEmpty(parameters)) {
      return "LINKED BUFFERS";
    }
    if (isEditMode(parameters)) {
      const preset2 = findPreset(parameters.slice(1));
      return preset2 ? `LB EDIT: ${preset2.name}` : "LB EDIT";
    }
    const preset = findPreset(parameters);
    return preset ? `LB: ${preset.name}` : "LINKED BUFFERS";
  },
  description: "Opens a dashboard with linked child buffers driven by a text input.",
  optionalParameters: "Preset Name",
  component: (parameters) => {
    if (isEditMode(parameters)) {
      return EditPreset;
    }
    return LINKEDBUFFERS;
  },
  bufferSize: [205, 400]
});
