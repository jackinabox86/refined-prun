import _sfc_main from "./PresetList.vue.js";
export {
  _sfc_main as default
};
