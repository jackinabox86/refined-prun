import { vModelText } from "../../../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import Header from "../../../components/Header.vue.js";
import _sfc_main$2 from "../../../components/ActionBar.vue.js";
import _sfc_main$1 from "../../../components/PrunButton.vue.js";
import { useXitParameters } from "../../../hooks/use-xit-parameters.js";
import { userData } from "../../../store/user-data.js";
import { createId } from "../../../store/create-id.js";
import { vDraggable as so } from "../../../../npm/vue-draggable-plus@0.6.0_@types+sortablejs@1.15.8-vue-draggable-plus-vue-draggable-plus.js";
import { grip } from "../../../components/grip/index.js";
import GripCell from "../../../components/grip/GripCell.vue.js";
import GripHeaderCell from "../../../components/grip/GripHeaderCell.vue.js";
import { isEmpty } from "../../../../npm/ts-extras@0.15.0-ts-extras-is-empty.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, withDirectives, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _hoisted_2 = { key: 1 };
const _hoisted_3 = ["onUpdate:modelValue"];
const _hoisted_4 = ["onUpdate:modelValue"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "EditPreset",
  setup(__props) {
    const rawParameters = useXitParameters();
    const parameters = rawParameters.slice(1);
    const preset = computed(() => {
      if (isEmpty(parameters)) {
        return void 0;
      }
      const byId = userData.linkedBuffersPresets.find((x) => x.id.startsWith(parameters[0]));
      if (byId) {
        return byId;
      }
      const name = parameters.join(" ");
      return userData.linkedBuffersPresets.find((x) => x.name === name);
    });
    function addCommand() {
      if (!preset.value) {
        return;
      }
      preset.value.commands.push({
        id: createId(),
        label: "CMD",
        template: "CMD {input}"
      });
    }
    function deleteCommand(cmd) {
      if (!preset.value) {
        return;
      }
      preset.value.commands = preset.value.commands.filter((x) => x !== cmd);
    }
    return (_ctx, _cache) => {
      return !unref(preset) ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: normalizeClass(_ctx.$style.center)
      }, [..._cache[0] || (_cache[0] = [
        createBaseVNode("span", null, "Preset not found.", -1)
      ])], 2)) : (openBlock(), createElementBlock("div", {
        key: 1,
        class: normalizeClass(_ctx.$style.root)
      }, [
        createVNode(Header, null, {
          default: withCtx(() => [
            createTextVNode("Edit: " + toDisplayString(unref(preset).name), 1)
          ]),
          _: 1
        }),
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createVNode(GripHeaderCell),
              _cache[1] || (_cache[1] = createBaseVNode("th", null, "Label", -1)),
              _cache[2] || (_cache[2] = createBaseVNode("th", null, "Template", -1)),
              _cache[3] || (_cache[3] = createBaseVNode("th", null, null, -1))
            ])
          ]),
          unref(preset).commands.length === 0 ? (openBlock(), createElementBlock("tbody", _hoisted_1, [..._cache[4] || (_cache[4] = [
            createBaseVNode("tr", null, [
              createBaseVNode("td", { colspan: "4" }, "No commands.")
            ], -1)
          ])])) : withDirectives((openBlock(), createElementBlock("tbody", _hoisted_2, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(preset).commands, (cmd) => {
              return openBlock(), createElementBlock("tr", {
                key: cmd.id
              }, [
                createVNode(GripCell),
                createBaseVNode("td", null, [
                  withDirectives(createBaseVNode("input", {
                    "onUpdate:modelValue": ($event) => cmd.label = $event,
                    type: "text",
                    class: normalizeClass([_ctx.$style.gameInput, _ctx.$style.labelInput]),
                    autocomplete: "off",
                    "data-1p-ignore": "true",
                    "data-lpignore": "true"
                  }, null, 10, _hoisted_3), [
                    [vModelText, cmd.label]
                  ])
                ]),
                createBaseVNode("td", null, [
                  withDirectives(createBaseVNode("input", {
                    "onUpdate:modelValue": ($event) => cmd.template = $event,
                    type: "text",
                    class: normalizeClass([_ctx.$style.gameInput, _ctx.$style.templateInput]),
                    autocomplete: "off",
                    "data-1p-ignore": "true",
                    "data-lpignore": "true"
                  }, null, 10, _hoisted_4), [
                    [vModelText, cmd.template]
                  ])
                ]),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$1, {
                    danger: "",
                    onClick: ($event) => deleteCommand(cmd)
                  }, {
                    default: withCtx(() => [..._cache[5] || (_cache[5] = [
                      createTextVNode("DELETE", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ])
              ]);
            }), 128))
          ])), [
            [unref(so), [unref(preset).commands, unref(grip).draggable]]
          ])
        ]),
        createVNode(_sfc_main$2, null, {
          default: withCtx(() => [
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: addCommand
            }, {
              default: withCtx(() => [..._cache[6] || (_cache[6] = [
                createTextVNode("ADD COMMAND", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        }),
        createBaseVNode("div", {
          class: normalizeClass(_ctx.$style.hint)
        }, "Close and reopen the LB control panel to apply layout changes.", 2)
      ], 2));
    };
  }
});
export {
  _sfc_main as default
};
