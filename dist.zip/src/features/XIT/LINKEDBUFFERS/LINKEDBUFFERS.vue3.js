const root = "rp-LINKEDBUFFERS__root___362f403";
const inputSection = "rp-LINKEDBUFFERS__inputSection___78ae916";
const label = "rp-LINKEDBUFFERS__label___772f782";
const gameInput = "rp-LINKEDBUFFERS__gameInput___5dd198e";
const commandCell = "rp-LINKEDBUFFERS__commandCell___d320a60";
const commandLink = "rp-LINKEDBUFFERS__commandLink___9a5184b";
const status = "rp-LINKEDBUFFERS__status___277dc50";
const create = "rp-LINKEDBUFFERS__create___9d2172a";
const createButton = "rp-LINKEDBUFFERS__createButton___3f89e6d";
const style0 = {
  root,
  inputSection,
  label,
  gameInput,
  commandCell,
  commandLink,
  status,
  create,
  createButton
};
export {
  commandCell,
  commandLink,
  create,
  createButton,
  style0 as default,
  gameInput,
  inputSection,
  label,
  root,
  status
};
