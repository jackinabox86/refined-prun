import _sfc_main from "./EditPreset.vue2.js";
import style0 from "./EditPreset.vue3.js";
import _export_sfc from "../../../../virtual/plugin-vue_export-helper.js";
const cssModules = {
  "$style": style0
};
const EditPreset = /* @__PURE__ */ _export_sfc(_sfc_main, [["__cssModules", cssModules]]);
export {
  EditPreset as default
};
