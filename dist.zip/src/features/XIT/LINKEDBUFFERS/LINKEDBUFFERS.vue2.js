import { vModelText } from "../../../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import { _$, _$$, $ } from "../../../utils/select-dom.js";
import Header from "../../../components/Header.vue.js";
import _sfc_main$3 from "../../../components/ActionBar.vue.js";
import _sfc_main$2 from "../../../components/PrunButton.vue.js";
import _sfc_main$1 from "./PresetList.vue.js";
import { useXitParameters } from "../../../hooks/use-xit-parameters.js";
import { useTile } from "../../../hooks/use-tile.js";
import { userData } from "../../../store/user-data.js";
import { createId } from "../../../store/create-id.js";
import { getPrunId } from "../../../infrastructure/prun-ui/attributes.js";
import { showBuffer, setBufferSize } from "../../../infrastructure/prun-ui/buffers.js";
import { UI_WINDOWS_REQUEST_FOCUS, UI_TILES_CHANGE_COMMAND } from "../../../infrastructure/prun-api/client-messages.js";
import { dispatchClientPrunMessage } from "../../../infrastructure/prun-api/prun-api-listener.js";
import { changeInputValue } from "../../../util.js";
import { sleep } from "../../../utils/sleep.js";
import onNodeDisconnected from "../../../utils/on-node-disconnected.js";
import { isEmpty } from "../../../../npm/ts-extras@0.15.0-ts-extras-is-empty.js";
import { defineComponent, computed, onMounted, onBeforeUnmount, openBlock, createBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, withDirectives, createCommentVNode, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _hoisted_2 = ["onClick"];
const DEFAULT_CHILD_WIDTH = 400;
const DEFAULT_CHILD_HEIGHT = 300;
const H_GAP = 15;
const V_GAP = 35;
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "LINKEDBUFFERS",
  setup(__props) {
    const tile = useTile();
    const parameters = useXitParameters();
    const preset = computed(() => {
      if (isEmpty(parameters)) {
        return void 0;
      }
      const byId = userData.linkedBuffersPresets.find((x) => x.id.startsWith(parameters[0]));
      if (byId) {
        return byId;
      }
      const name = parameters.join(" ");
      return userData.linkedBuffersPresets.find((x) => x.name === name);
    });
    const inputText = ref("");
    const isProcessing = ref(false);
    const spawning = ref(false);
    const childWindows = ref([]);
    const isFloating = tile.container.classList.contains(C.Window.body);
    onMounted(async () => {
      if (!isFloating || !preset.value) {
        return;
      }
      const controlWindow = tile.frame.closest(`.${C.Window.window}`);
      if (controlWindow) {
        const saved = preset.value.controlPosition;
        if (saved) {
          controlWindow.style.left = `${saved[0]}px`;
          controlWindow.style.top = `${saved[1]}px`;
        } else {
          controlWindow.style.left = "30px";
          controlWindow.style.top = "50px";
        }
      }
      if (preset.value.commands.length > 0) {
        await spawnChildWindows();
      }
    });
    onBeforeUnmount(() => {
      closeAllChildren();
    });
    function getSavedLayout(commandId) {
      return preset.value?.childLayouts?.find((l) => l.commandId === commandId);
    }
    function getChildSize(commandId) {
      const saved = getSavedLayout(commandId);
      if (saved) {
        return [saved.width, saved.height];
      }
      return [DEFAULT_CHILD_WIDTH, DEFAULT_CHILD_HEIGHT];
    }
    async function spawnChildWindows() {
      spawning.value = true;
      const commands = preset.value.commands;
      const created = [];
      for (let i = 0; i < commands.length; i++) {
        const window = await showBuffer(" ", { force: true, autoSubmit: false });
        const input = _$(window, C.PanelSelector.input);
        if (input) {
          changeInputValue(input, "");
        }
        const child = {
          window,
          commandIndex: i,
          commandId: commands[i].id
        };
        created.push(child);
        onNodeDisconnected(window, () => {
          childWindows.value = childWindows.value.filter((c) => c !== child);
        });
      }
      childWindows.value = created;
      layoutChildren();
      for (const child of created) {
        const tileEl = _$(child.window, C.Tile.tile);
        if (tileEl) {
          const id = getPrunId(tileEl);
          if (id) {
            const [w, h] = getChildSize(child.commandId);
            setBufferSize(id, w, h);
          }
        }
      }
      dispatchClientPrunMessage(UI_WINDOWS_REQUEST_FOCUS(tile.id));
      spawning.value = false;
    }
    function layoutChildren() {
      const controlWindow = tile.frame.closest(`.${C.Window.window}`);
      if (!controlWindow) {
        return;
      }
      const rect = controlWindow.getBoundingClientRect();
      const count = childWindows.value.length;
      const hasSavedLayouts = preset.value?.childLayouts && preset.value.childLayouts.length > 0;
      for (let i = 0; i < count; i++) {
        const child = childWindows.value[i];
        const saved = getSavedLayout(child.commandId);
        const win = child.window;
        if (hasSavedLayouts && saved) {
          win.style.left = `${saved.left}px`;
          win.style.top = `${saved.top}px`;
        } else {
          const cols = count <= 2 ? count : 2;
          const col = i % cols;
          const row = Math.floor(i / cols);
          const [w, h] = getChildSize(child.commandId);
          const left = rect.right + H_GAP + col * (w + H_GAP);
          const top = rect.top + row * (h + V_GAP);
          win.style.left = `${left}px`;
          win.style.top = `${top}px`;
        }
      }
    }
    function closeAllChildren() {
      for (const child of childWindows.value) {
        if (child.window.isConnected) {
          const closeButton = _$$(child.window, C.Window.button).find((x) => x.textContent === "x");
          closeButton?.click();
        }
      }
      childWindows.value = [];
    }
    function resolveCommand(template) {
      return template.replace(/\{input\}/g, inputText.value.trim()).toUpperCase();
    }
    async function changeTileCommand(windowEl, command, commandId) {
      const tileEl = _$(windowEl, C.Tile.tile);
      if (!tileEl) {
        return;
      }
      const id = getPrunId(tileEl);
      const [w, h] = getChildSize(commandId);
      const existingInput = _$(windowEl, C.PanelSelector.input);
      if (existingInput?.form?.isConnected) {
        changeInputValue(existingInput, command);
        existingInput.form.requestSubmit();
        await sleep(200);
        setBufferSize(id, w, h);
        return;
      }
      let message = UI_TILES_CHANGE_COMMAND(id, null);
      if (!dispatchClientPrunMessage(message)) {
        const changeButton = _$$(tileEl, C.TileControls.control).find((x) => x.textContent === ":");
        if (changeButton) {
          changeButton.click();
        }
      } else {
        await sleep(0);
      }
      message = UI_TILES_CHANGE_COMMAND(id, command);
      if (!dispatchClientPrunMessage(message)) {
        const input = await $(windowEl, C.PanelSelector.input);
        changeInputValue(input, command);
        input.form.requestSubmit();
      }
      await sleep(200);
      const newTileEl = _$(windowEl, C.Tile.tile);
      const newId = newTileEl ? getPrunId(newTileEl) : id;
      setBufferSize(newId ?? id, w, h);
    }
    async function onCommandClick(cmd, index) {
      if (!inputText.value.trim() || isProcessing.value) {
        return;
      }
      const resolved = resolveCommand(cmd.template);
      isProcessing.value = true;
      try {
        const child = childWindows.value.find((c) => c.commandIndex === index);
        if (child?.window.isConnected) {
          await changeTileCommand(child.window, resolved, child.commandId);
        }
      } finally {
        isProcessing.value = false;
      }
    }
    function saveLayout() {
      if (!preset.value) {
        return;
      }
      const controlWindow = tile.frame.closest(`.${C.Window.window}`);
      if (controlWindow) {
        const rect = controlWindow.getBoundingClientRect();
        preset.value.controlPosition = [Math.round(rect.left), Math.round(rect.top)];
      }
      const layouts = [];
      for (const child of childWindows.value) {
        if (!child.window.isConnected) {
          continue;
        }
        const rect = child.window.getBoundingClientRect();
        layouts.push({
          commandId: child.commandId,
          left: Math.round(rect.left),
          top: Math.round(rect.top),
          width: Math.round(rect.width),
          height: Math.round(rect.height)
        });
      }
      preset.value.childLayouts = layouts;
    }
    async function openEditor() {
      if (!preset.value) {
        return;
      }
      const window = await showBuffer(`XIT LB EDIT ${preset.value.id.substring(0, 8)}`);
      const tileEl = _$(window, C.Tile.tile);
      if (tileEl) {
        const id = getPrunId(tileEl);
        if (id) {
          setBufferSize(id, 500, 400);
        }
      }
    }
    function onCreateClick() {
      if (isEmpty(parameters)) {
        return;
      }
      const name = parameters.join(" ");
      userData.linkedBuffersPresets.push({
        id: createId(),
        name,
        commands: []
      });
    }
    return (_ctx, _cache) => {
      return unref(isEmpty)(unref(parameters)) ? (openBlock(), createBlock(_sfc_main$1, { key: 0 })) : !unref(preset) ? (openBlock(), createElementBlock("div", {
        key: 1,
        class: normalizeClass(_ctx.$style.create)
      }, [
        createBaseVNode("span", null, 'Preset "' + toDisplayString(unref(parameters).join(" ")) + '" not found.', 1),
        createVNode(_sfc_main$2, {
          primary: "",
          class: normalizeClass(_ctx.$style.createButton),
          onClick: onCreateClick
        }, {
          default: withCtx(() => [..._cache[1] || (_cache[1] = [
            createTextVNode("CREATE", -1)
          ])]),
          _: 1
        }, 8, ["class"])
      ], 2)) : (openBlock(), createElementBlock("div", {
        key: 2,
        class: normalizeClass(_ctx.$style.root)
      }, [
        createVNode(Header, null, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(unref(preset).name), 1)
          ]),
          _: 1
        }),
        createBaseVNode("div", {
          class: normalizeClass(_ctx.$style.inputSection)
        }, [
          createBaseVNode("label", {
            class: normalizeClass(_ctx.$style.label)
          }, "Input", 2),
          withDirectives(createBaseVNode("input", {
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(inputText) ? inputText.value = $event : null),
            type: "text",
            class: normalizeClass(_ctx.$style.gameInput),
            autocomplete: "off",
            "data-1p-ignore": "true",
            "data-lpignore": "true"
          }, null, 2), [
            [vModelText, unref(inputText)]
          ])
        ], 2),
        unref(spawning) ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(_ctx.$style.status)
        }, "Opening buffers...", 2)) : createCommentVNode("", true),
        createBaseVNode("table", null, [
          _cache[3] || (_cache[3] = createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", null, "Commands")
            ])
          ], -1)),
          createBaseVNode("tbody", null, [
            unref(preset).commands.length === 0 ? (openBlock(), createElementBlock("tr", _hoisted_1, [..._cache[2] || (_cache[2] = [
              createBaseVNode("td", null, "No commands.", -1)
            ])])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(unref(preset).commands, (cmd, index) => {
              return openBlock(), createElementBlock("tr", {
                key: cmd.id,
                onClick: ($event) => onCommandClick(cmd, index)
              }, [
                createBaseVNode("td", {
                  class: normalizeClass(_ctx.$style.commandCell)
                }, [
                  createBaseVNode("span", {
                    class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).Link.link, _ctx.$style.commandLink])
                  }, toDisplayString(resolveCommand(cmd.template) || cmd.template), 3)
                ], 2)
              ], 8, _hoisted_2);
            }), 128))
          ])
        ]),
        createVNode(_sfc_main$3, null, {
          default: withCtx(() => [
            createVNode(_sfc_main$2, {
              primary: "",
              onClick: saveLayout
            }, {
              default: withCtx(() => [..._cache[4] || (_cache[4] = [
                createTextVNode("SAVE LAYOUT", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$2, {
              primary: "",
              onClick: openEditor
            }, {
              default: withCtx(() => [..._cache[5] || (_cache[5] = [
                createTextVNode("EDIT", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        })
      ], 2));
    };
  }
});
export {
  _sfc_main as default
};
