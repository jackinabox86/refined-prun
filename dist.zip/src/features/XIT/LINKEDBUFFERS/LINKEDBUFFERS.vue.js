import _sfc_main from "./LINKEDBUFFERS.vue2.js";
import style0 from "./LINKEDBUFFERS.vue3.js";
import _export_sfc from "../../../../virtual/plugin-vue_export-helper.js";
const cssModules = {
  "$style": style0
};
const LINKEDBUFFERS = /* @__PURE__ */ _export_sfc(_sfc_main, [["__cssModules", cssModules]]);
export {
  LINKEDBUFFERS as default
};
