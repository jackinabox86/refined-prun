const root = "rp-EditPreset__root___13a0774";
const center = "rp-EditPreset__center___2898e27";
const gameInput = "rp-EditPreset__gameInput___fb49c99";
const labelInput = "rp-EditPreset__labelInput___50cfaeb";
const templateInput = "rp-EditPreset__templateInput___435dad4";
const hint = "rp-EditPreset__hint___63749d6";
const style0 = {
  root,
  center,
  gameInput,
  labelInput,
  templateInput,
  hint
};
export {
  center,
  style0 as default,
  gameInput,
  hint,
  labelInput,
  root,
  templateInput
};
