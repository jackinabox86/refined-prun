import LineChart from "./LineChart.vue.js";
import { percent0 } from "../../../utils/format.js";
import { balanceHistory } from "../../../store/user-data-balance.js";
import { useTileState } from "../../../store/user-data-tiles.js";
import dayjs from "../../../../npm/dayjs@1.11.18-dayjs-dayjs.min.js";
import RangeInput from "../../../components/forms/RangeInput.vue.js";
import _sfc_main$2 from "../../../components/forms/Active.vue.js";
import SelectInput from "../../../components/forms/SelectInput.vue.js";
import { charts } from "./charts.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import _sfc_main$1 from "../../../components/forms/Passive.vue.js";
import { defineComponent, computed, watch, openBlock, createElementBlock, Fragment, createElementVNode as createBaseVNode, createBlock, withCtx, createVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "HistoryChart",
  props: {
    chartDef: {}
  },
  setup(__props) {
    const maintainAspectRatio = computed(() => !__props.chartDef);
    const pan = computed(() => !!__props.chartDef);
    const zoom = computed(() => !!__props.chartDef);
    const averageFactor = useTileState("averageFactor", 0.1);
    const averageFactorText = ref(averageFactor.value);
    watch(averageFactorText, (x) => {
      const parsed = typeof x === "number" ? x : parseFloat(x);
      if (isFinite(parsed)) {
        averageFactor.value = parsed;
      }
    });
    const selectedChart = useTileState("selectedChart", "EQUITY");
    const selectedChartDef = computed(
      () => __props.chartDef ?? charts.value.find((x) => x.value === selectedChart.value)
    );
    const yLabel = computed(() => {
      let label = selectedChartDef.value?.label;
      if (!label) {
        return "Value";
      }
      while (label.startsWith("-") || label.startsWith(" ")) {
        label = label.slice(1);
      }
      return label;
    });
    const lineChartData = computed(() => {
      const date = [];
      const equityValues = [];
      if (!selectedChartDef.value) {
        return {
          date,
          equity: equityValues
        };
      }
      for (const entry of balanceHistory.value) {
        const value = selectedChartDef.value.getValue(entry);
        if (value === void 0) {
          continue;
        }
        const previousDay = date[date.length - 1];
        if (previousDay !== void 0 && dayjs(previousDay).isSame(entry.timestamp, "day")) {
          date[date.length - 1] = entry.timestamp;
          equityValues[equityValues.length - 1] = value;
        } else {
          date.push(entry.timestamp);
          equityValues.push(value);
        }
      }
      return {
        date,
        equity: equityValues
      };
    });
    function onChartClick() {
      if (!__props.chartDef) {
        showBuffer(`XIT FINCH ${selectedChart.value}`);
      }
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("form", null, [
          _ctx.chartDef ? (openBlock(), createBlock(_sfc_main$1, {
            key: 0,
            label: "Chart"
          }, {
            default: withCtx(() => [
              createBaseVNode("span", null, toDisplayString(unref(yLabel)), 1)
            ]),
            _: 1
          })) : (openBlock(), createBlock(_sfc_main$2, {
            key: 1,
            label: "Chart"
          }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: unref(selectedChart),
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(selectedChart) ? selectedChart.value = $event : null),
                options: unref(charts)
              }, null, 8, ["modelValue", "options"])
            ]),
            _: 1
          })),
          createVNode(_sfc_main$2, {
            label: `Smoothing: ${unref(percent0)(unref(averageFactor))}`
          }, {
            default: withCtx(() => [
              createVNode(RangeInput, {
                modelValue: unref(averageFactorText),
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(averageFactorText) ? averageFactorText.value = $event : null),
                class: normalizeClass(_ctx.$style.wide),
                min: 0,
                max: 1,
                step: 0.01
              }, null, 8, ["modelValue", "class"])
            ]),
            _: 1
          }, 8, ["label"])
        ]),
        createVNode(LineChart, {
          "maintain-aspect-ratio": unref(maintainAspectRatio),
          "average-factor": unref(averageFactor),
          ydata: unref(lineChartData).equity,
          xdata: unref(lineChartData).date,
          "y-label": unref(yLabel),
          pan: unref(pan),
          zoom: unref(zoom),
          onClick: onChartClick
        }, null, 8, ["maintain-aspect-ratio", "average-factor", "ydata", "xdata", "y-label", "pan", "zoom"])
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
