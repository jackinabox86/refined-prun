const wide = "rp-HistoryChart__wide___46c9e78";
const style0 = {
  wide
};
export {
  style0 as default,
  wide
};
