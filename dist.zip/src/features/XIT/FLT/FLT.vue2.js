import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import { shipsStore } from "../../../infrastructure/prun-api/data/ships.js";
import { flightsStore } from "../../../infrastructure/prun-api/data/flights.js";
import { storagesStore } from "../../../infrastructure/prun-api/data/storage.js";
import { exchangesStore } from "../../../infrastructure/prun-api/data/exchanges.js";
import { getDestinationName } from "../../../infrastructure/prun-api/data/addresses.js";
import { getInvStore } from "../../../core/store-id.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import { useTileState } from "../../../store/user-data-tiles.js";
import LoadingSpinner from "../../../components/LoadingSpinner.vue.js";
import _sfc_main$1 from "../../../components/forms/RadioItem.vue.js";
import FleetStatusCell from "./FleetStatusCell.vue.js";
import CargoBar from "./CargoBar.vue.js";
import { fixed0 } from "../../../utils/format.js";
import { defineComponent, computed, openBlock, createBlock, createElementBlock, createElementVNode as createBaseVNode, createCommentVNode, createVNode, withCtx, createTextVNode, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref, isRef } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = ["onClick"];
const _hoisted_2 = ["onClick"];
const _hoisted_3 = ["onClick"];
const _hoisted_4 = ["value"];
const _hoisted_5 = ["value"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FLT",
  setup(__props) {
    const primarySortKey = useTileState("primarySortKey", "name");
    const secondarySortKey = useTileState("secondarySortKey", "status");
    const sortDirectionByKey = useTileState("sortDirectionByKey", {
      name: "asc",
      cargo: "asc",
      status: "asc",
      fuel: "asc"
    });
    const showFilters = useTileState("showFilters", false);
    const showStlShips = useTileState("showStlShips", true);
    const showFtlShips = useTileState("showFtlShips", true);
    const showInFlightShips = useTileState("showInFlightShips", true);
    const showNotInFlightShips = useTileState("showNotInFlightShips", true);
    const hideReturningToCx = useTileState("hideReturningToCx", false);
    const inventorySizeFilters = useTileState("inventorySizeFilters", []);
    const shipClassFilters = useTileState("shipClassFilters", []);
    const conditionFilters = useTileState("conditionFilters", []);
    const cargoStateFilters = useTileState("cargoStateFilters", []);
    const etaFilters = useTileState("etaFilters", []);
    const fuelAlertFilter = useTileState("fuelAlertFilter", "any");
    const conditionOptions = ["100-90", "90-80", "80-0"];
    const etaOptions = ["DOCKED", "<1H", "1-6H", "6-12H", "12-24H", ">24H"];
    const cargoStateOptions = ["EMPTY", "PARTIAL", "FULL"];
    const fuelAlertOptions = ["75", "50", "35", "25", "10"];
    const fuelAlertThresholdMap = {
      any: 1,
      "75": 0.75,
      "50": 0.5,
      "35": 0.35,
      "25": 0.25,
      "10": 0.1
    };
    const sortColumns = [
      { key: "name", label: "Name" },
      { key: "cargo", label: "Cargo" },
      { key: "status", label: "Status" },
      { key: "fuel", label: "Fuel" }
    ];
    const cxCodes = computed(() => {
      const exchanges = exchangesStore.all.value ?? [];
      return new Set(exchanges.map((x) => x.code.toUpperCase()));
    });
    const rawRows = computed(() => {
      const ships = shipsStore.all.value;
      if (!ships) {
        return void 0;
      }
      return ships.map((ship) => {
        const flight = flightsStore.getById(ship.flightId);
        const inventory = getInvStore(ship.idShipStore);
        const stlStore = storagesStore.getById(ship.idStlFuelStore);
        const ftlStore = storagesStore.getById(ship.idFtlFuelStore);
        const stlCapacity = stlStore?.weightCapacity;
        const ftlCapacity = ftlStore?.weightCapacity;
        const stlFuelRatio = stlStore != null && stlCapacity != null && stlCapacity > 0 ? stlStore.weightLoad / stlCapacity : void 0;
        const ftlFuelRatio = ftlStore != null && ftlCapacity != null && ftlCapacity > 0 ? ftlStore.weightLoad / ftlCapacity : void 0;
        const condition = ship.condition <= 1 ? ship.condition * 100 : ship.condition;
        const cargoRatio = inventory ? Math.max(
          inventory.weightCapacity > 0 ? inventory.weightLoad / inventory.weightCapacity : 0,
          inventory.volumeCapacity > 0 ? inventory.volumeLoad / inventory.volumeCapacity : 0
        ) : 0;
        const fuelRatio = Math.max(stlFuelRatio ?? 0, ftlFuelRatio ?? 0);
        const now = Date.now();
        const arrivalTimestamp = flight?.arrival.timestamp;
        const statusSortValue = arrivalTimestamp != null && !Number.isNaN(arrivalTimestamp) ? Math.max(0, arrivalTimestamp - now) : 0;
        const isFtlCapable = (ftlCapacity ?? 0) > 0;
        const warningFuelRatio = isFtlCapable ? Math.min(stlFuelRatio ?? 0, ftlFuelRatio ?? 0) : stlFuelRatio ?? 0;
        const inFlight = ship.flightId != null;
        const destinationCode = getDestinationName(flight?.destination)?.toUpperCase();
        const isReturningToCx = destinationCode != null && cxCodes.value.has(destinationCode);
        const shipClass = getShipClass(ship);
        const conditionBand = getConditionBand(condition);
        const etaBucket = getEtaBucket(inFlight, statusSortValue);
        const cargoState = getCargoState(cargoRatio);
        return {
          ship,
          stlFuelRatio,
          ftlFuelRatio,
          cargoRatio,
          fuelRatio,
          warningFuelRatio,
          statusSortValue,
          conditionText: `${Math.round(condition)}%`,
          cargoSizeText: getCargoSizeText(inventory),
          isFtlCapable,
          inFlight,
          isReturningToCx,
          shipClass,
          conditionBand,
          etaBucket,
          cargoState
        };
      });
    });
    const shipClassOptions = computed(() => {
      const source = rawRows.value;
      if (!source) {
        return [];
      }
      return uniqueOptionValues(source, (x) => x.shipClass);
    });
    const inventorySizeOptions = computed(() => {
      const source = rawRows.value;
      if (!source) {
        return [];
      }
      return uniqueOptionValues(source, (x) => x.cargoSizeText);
    });
    const filteredRows = computed(() => {
      const source = rawRows.value;
      if (!source) {
        return void 0;
      }
      return source.filter((x) => {
        if (!showStlShips.value && !x.isFtlCapable) {
          return false;
        }
        if (!showFtlShips.value && x.isFtlCapable) {
          return false;
        }
        if (!showInFlightShips.value && x.inFlight) {
          return false;
        }
        if (!showNotInFlightShips.value && !x.inFlight) {
          return false;
        }
        if (hideReturningToCx.value && x.isReturningToCx) {
          return false;
        }
        if (!isOptionSelected(shipClassFilters.value, x.shipClass)) {
          return false;
        }
        if (!isOptionSelected(conditionFilters.value, x.conditionBand)) {
          return false;
        }
        if (!isOptionSelected(cargoStateFilters.value, x.cargoState)) {
          return false;
        }
        if (!isOptionSelected(etaFilters.value, x.etaBucket)) {
          return false;
        }
        const threshold = fuelAlertThresholdMap[fuelAlertFilter.value];
        if (threshold < 1 && x.warningFuelRatio > threshold) {
          return false;
        }
        const selectedSizes = inventorySizeFilters.value;
        if (!isOptionSelected(selectedSizes, x.cargoSizeText)) {
          return false;
        }
        return true;
      });
    });
    const rows = computed(() => {
      const source = filteredRows.value;
      if (!source) {
        return void 0;
      }
      const sorted = [...source];
      const primaryKey = primarySortKey.value;
      let secondaryKey = secondarySortKey.value;
      if (secondaryKey === primaryKey) {
        secondaryKey = "name";
      }
      const primaryDirection = getSortDirection(primaryKey) === "asc" ? 1 : -1;
      const secondaryDirection = getSortDirection(secondaryKey) === "asc" ? 1 : -1;
      sorted.sort((a, b) => {
        const primary = compareByKey(a, b, primaryKey) * primaryDirection;
        if (primary !== 0) {
          return primary;
        }
        const secondary = compareByKey(a, b, secondaryKey) * secondaryDirection;
        if (secondary !== 0) {
          return secondary;
        }
        return compareByKey(a, b, "name");
      });
      return sorted;
    });
    const activeFilterCount = computed(() => {
      let count = 0;
      if (!showStlShips.value || !showFtlShips.value) {
        count += 1;
      }
      if (!showInFlightShips.value || !showNotInFlightShips.value) {
        count += 1;
      }
      if (inventorySizeFilters.value.length > 0) {
        count += 1;
      }
      if (hideReturningToCx.value) {
        count += 1;
      }
      if (shipClassFilters.value.length > 0) {
        count += 1;
      }
      if (conditionFilters.value.length > 0) {
        count += 1;
      }
      if (cargoStateFilters.value.length > 0) {
        count += 1;
      }
      if (etaFilters.value.length > 0) {
        count += 1;
      }
      if (fuelAlertFilter.value !== "any") {
        count += 1;
      }
      return count;
    });
    const filterSymbol = computed(() => showFilters.value ? "-" : "+");
    const optionFilterGroups = computed(() => [
      {
        key: "ship-class",
        title: "Ship class",
        options: shipClassOptions.value,
        selected: shipClassFilters.value,
        onToggle: onShipClassClick
      },
      {
        key: "eta-bucket",
        title: "ETA bucket",
        options: etaOptions,
        selected: etaFilters.value,
        onToggle: onEtaClick
      },
      {
        key: "inventory-size",
        title: "Inventory size",
        options: inventorySizeOptions.value,
        selected: inventorySizeFilters.value,
        onToggle: onInventorySizeClick
      },
      {
        key: "cargo-state",
        title: "Cargo state",
        options: cargoStateOptions,
        selected: cargoStateFilters.value,
        onToggle: onCargoStateClick
      },
      {
        key: "condition",
        title: "Condition",
        options: conditionOptions,
        selected: conditionFilters.value,
        onToggle: onConditionClick
      }
    ]);
    function setSort(key) {
      if (primarySortKey.value === key) {
        const nextDirection = getSortDirection(key) === "asc" ? "desc" : "asc";
        sortDirectionByKey.value = {
          ...sortDirectionByKey.value,
          [key]: nextDirection
        };
        return;
      }
      secondarySortKey.value = primarySortKey.value;
      primarySortKey.value = key;
    }
    function getSortIndicator(key) {
      if (primarySortKey.value === key) {
        return getSortDirection(key) === "asc" ? "▲" : "▼";
      }
      if (secondarySortKey.value === key && primarySortKey.value !== key) {
        return getSortDirection(key) === "asc" ? "▲" : "▼";
      }
      return void 0;
    }
    function isPrimarySort(key) {
      return primarySortKey.value === key;
    }
    function isSecondarySort(key) {
      return secondarySortKey.value === key && primarySortKey.value !== key;
    }
    function getSortDirection(key) {
      return sortDirectionByKey.value[key] ?? "asc";
    }
    function compareByKey(a, b, key) {
      const nameCompare = (a.ship.name || a.ship.registration).localeCompare(
        b.ship.name || b.ship.registration
      );
      switch (key) {
        case "name":
          return nameCompare;
        case "cargo": {
          const primary = a.cargoRatio - b.cargoRatio;
          return primary !== 0 ? primary : nameCompare;
        }
        case "status": {
          const primary = a.statusSortValue - b.statusSortValue;
          return primary !== 0 ? primary : nameCompare;
        }
        case "fuel": {
          const primary = a.fuelRatio - b.fuelRatio;
          return primary !== 0 ? primary : nameCompare;
        }
      }
    }
    function getCargoSizeText(inventory) {
      if (!inventory) {
        return "--/--";
      }
      return `${toCompactK(inventory.weightCapacity)}/${toCompactK(inventory.volumeCapacity)}`;
    }
    function toCompactK(value) {
      if (value >= 1e3) {
        return `${Math.round(value / 1e3)}k`;
      }
      return fixed0(value);
    }
    function onFuel(registration) {
      showBuffer(`SHPF ${registration}`);
    }
    function toggleFilters() {
      showFilters.value = !showFilters.value;
    }
    function isOptionSelected(selected, option) {
      return selected.length === 0 || selected.includes(option);
    }
    function uniqueOptionValues(source, getValue) {
      const seen = /* @__PURE__ */ new Set();
      const options = [];
      for (const x of source) {
        const value = getValue(x);
        if (!seen.has(value)) {
          seen.add(value);
          options.push(value);
        }
      }
      return options;
    }
    function toggleOptionFilter(target, options, option) {
      const selected = target.value;
      if (selected.length === 0) {
        target.value = options.filter((x) => x !== option);
        return;
      }
      let next;
      if (selected.includes(option)) {
        next = selected.filter((x) => x !== option);
      } else {
        next = [...selected, option];
      }
      if (next.length === 0 || next.length === options.length) {
        target.value = [];
        return;
      }
      target.value = next;
    }
    function onShipClassClick(shipClass) {
      toggleOptionFilter(shipClassFilters, shipClassOptions.value, shipClass);
    }
    function onEtaClick(eta) {
      toggleOptionFilter(etaFilters, etaOptions, eta);
    }
    function onInventorySizeClick(size) {
      toggleOptionFilter(inventorySizeFilters, inventorySizeOptions.value, size);
    }
    function onCargoStateClick(cargoState) {
      toggleOptionFilter(cargoStateFilters, cargoStateOptions, cargoState);
    }
    function onConditionClick(band) {
      toggleOptionFilter(conditionFilters, conditionOptions, band);
    }
    function onFuelAlertToggle(threshold, enabled) {
      fuelAlertFilter.value = enabled === true ? threshold : "any";
    }
    function clearFilters() {
      showStlShips.value = true;
      showFtlShips.value = true;
      showInFlightShips.value = true;
      showNotInFlightShips.value = true;
      hideReturningToCx.value = false;
      inventorySizeFilters.value = [];
      shipClassFilters.value = [];
      conditionFilters.value = [];
      cargoStateFilters.value = [];
      etaFilters.value = [];
      fuelAlertFilter.value = "any";
    }
    function getShipClass(ship) {
      const name = ship.name?.toUpperCase() ?? "";
      const nameMatch = name.match(/^\[([A-Z0-9]{2,6})]/) ?? name.match(/^\(([A-Z0-9]{2,6})\)/) ?? name.match(/^([A-Z0-9]{2,6})(?=[\s\-_])/);
      if (nameMatch) {
        return nameMatch[1];
      }
      const registration = ship.registration.toUpperCase();
      const match = registration.match(/^([A-Z0-9]{2,6})/);
      if (match) {
        return match[1];
      }
      return "UNK";
    }
    function getConditionBand(condition) {
      if (condition >= 90) {
        return "100-90";
      }
      if (condition >= 80) {
        return "90-80";
      }
      return "80-0";
    }
    function getEtaBucket(inFlight, statusSortValue) {
      if (!inFlight) {
        return "DOCKED";
      }
      const hour = 36e5;
      if (statusSortValue < hour) {
        return "<1H";
      }
      if (statusSortValue < 6 * hour) {
        return "1-6H";
      }
      if (statusSortValue < 12 * hour) {
        return "6-12H";
      }
      if (statusSortValue < 24 * hour) {
        return "12-24H";
      }
      return ">24H";
    }
    function getCargoState(cargoRatio) {
      if (cargoRatio <= 1e-4) {
        return "EMPTY";
      }
      if (cargoRatio > 0.95) {
        return "FULL";
      }
      return "PARTIAL";
    }
    return (_ctx, _cache) => {
      return !rows.value ? (openBlock(), createBlock(LoadingSpinner, { key: 0 })) : (openBlock(), createElementBlock("div", {
        key: 1,
        class: normalizeClass(_ctx.$style.content)
      }, [
        createBaseVNode("div", {
          class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).FormComponent.containerPassive, ("C" in _ctx ? _ctx.C : unref(C)).forms.passive, ("C" in _ctx ? _ctx.C : unref(C)).forms.formComponent])
        }, [
          createBaseVNode("label", {
            class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).FormComponent.label, ("C" in _ctx ? _ctx.C : unref(C)).fonts.fontRegular, ("C" in _ctx ? _ctx.C : unref(C)).type.typeRegular])
          }, " Minimize ", 2),
          createBaseVNode("div", {
            class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).FormComponent.input, ("C" in _ctx ? _ctx.C : unref(C)).forms.input])
          }, [
            createBaseVNode("div", null, [
              createBaseVNode("div", {
                class: normalizeClass(_ctx.$style.minimize),
                onClick: toggleFilters
              }, toDisplayString(filterSymbol.value), 3)
            ])
          ], 2)
        ], 2),
        unref(showFilters) ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(_ctx.$style.filterPanel)
        }, [
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.filterMeta)
          }, [
            activeFilterCount.value > 0 ? (openBlock(), createElementBlock("span", {
              key: 0,
              class: normalizeClass(_ctx.$style.activeCount)
            }, toDisplayString(activeFilterCount.value) + " active ", 3)) : createCommentVNode("", true),
            activeFilterCount.value > 0 ? (openBlock(), createElementBlock("span", {
              key: 1,
              class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).Link.link, _ctx.$style.clearFilters]),
              onClick: clearFilters
            }, " reset ", 2)) : createCommentVNode("", true)
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.filterGroup)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(_ctx.$style.filterTitle)
            }, "Ship list", 2),
            createBaseVNode("div", {
              class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).ComExOrdersPanel.filter)
            }, [
              createVNode(_sfc_main$1, {
                modelValue: unref(showStlShips),
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(showStlShips) ? showStlShips.value = $event : null),
                horizontal: ""
              }, {
                default: withCtx(() => [..._cache[5] || (_cache[5] = [
                  createTextVNode("STL", -1)
                ])]),
                _: 1
              }, 8, ["modelValue"]),
              createVNode(_sfc_main$1, {
                modelValue: unref(showFtlShips),
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(showFtlShips) ? showFtlShips.value = $event : null),
                horizontal: ""
              }, {
                default: withCtx(() => [..._cache[6] || (_cache[6] = [
                  createTextVNode("FTL", -1)
                ])]),
                _: 1
              }, 8, ["modelValue"])
            ], 2)
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.filterGroup)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(_ctx.$style.filterTitle)
            }, "Flight state", 2),
            createBaseVNode("div", {
              class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).ComExOrdersPanel.filter)
            }, [
              createVNode(_sfc_main$1, {
                modelValue: unref(showInFlightShips),
                "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(showInFlightShips) ? showInFlightShips.value = $event : null),
                horizontal: ""
              }, {
                default: withCtx(() => [..._cache[7] || (_cache[7] = [
                  createTextVNode("IN FLIGHT", -1)
                ])]),
                _: 1
              }, 8, ["modelValue"]),
              createVNode(_sfc_main$1, {
                modelValue: unref(showNotInFlightShips),
                "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(showNotInFlightShips) ? showNotInFlightShips.value = $event : null),
                horizontal: ""
              }, {
                default: withCtx(() => [..._cache[8] || (_cache[8] = [
                  createTextVNode("DOCKED", -1)
                ])]),
                _: 1
              }, 8, ["modelValue"])
            ], 2)
          ], 2),
          (openBlock(true), createElementBlock(Fragment, null, renderList(optionFilterGroups.value, (group) => {
            return openBlock(), createElementBlock("div", {
              key: group.key,
              class: normalizeClass(_ctx.$style.filterGroup)
            }, [
              createBaseVNode("div", {
                class: normalizeClass(_ctx.$style.filterTitle)
              }, toDisplayString(group.title), 3),
              createBaseVNode("div", {
                class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).ComExOrdersPanel.filter)
              }, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(group.options, (option) => {
                  return openBlock(), createBlock(_sfc_main$1, {
                    key: `${group.key}-${option}`,
                    "model-value": isOptionSelected(group.selected, option),
                    horizontal: "",
                    "onUpdate:modelValue": ($event) => group.onToggle(option)
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(option), 1)
                    ]),
                    _: 2
                  }, 1032, ["model-value", "onUpdate:modelValue"]);
                }), 128))
              ], 2)
            ], 2);
          }), 128)),
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.filterGroup)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(_ctx.$style.filterTitle)
            }, "Route", 2),
            createBaseVNode("div", {
              class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).ComExOrdersPanel.filter)
            }, [
              createVNode(_sfc_main$1, {
                modelValue: unref(hideReturningToCx),
                "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => isRef(hideReturningToCx) ? hideReturningToCx.value = $event : null),
                horizontal: ""
              }, {
                default: withCtx(() => [..._cache[9] || (_cache[9] = [
                  createTextVNode("HIDE CX RETURNS", -1)
                ])]),
                _: 1
              }, 8, ["modelValue"])
            ], 2)
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.filterGroup)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(_ctx.$style.filterTitle)
            }, "Fuel warning", 2),
            createBaseVNode("div", {
              class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).ComExOrdersPanel.filter)
            }, [
              (openBlock(), createElementBlock(Fragment, null, renderList(fuelAlertOptions, (threshold) => {
                return createVNode(_sfc_main$1, {
                  key: threshold,
                  "model-value": unref(fuelAlertFilter) === threshold,
                  horizontal: "",
                  "onUpdate:modelValue": ($event) => onFuelAlertToggle(threshold, $event)
                }, {
                  default: withCtx(() => [
                    createTextVNode(" ≤" + toDisplayString(threshold) + "% ", 1)
                  ]),
                  _: 2
                }, 1032, ["model-value", "onUpdate:modelValue"]);
              }), 64))
            ], 2)
          ], 2)
        ], 2)) : createCommentVNode("", true),
        createBaseVNode("table", {
          class: normalizeClass(_ctx.$style.table)
        }, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              (openBlock(), createElementBlock(Fragment, null, renderList(sortColumns, (column) => {
                return createBaseVNode("th", {
                  key: column.key,
                  class: normalizeClass([_ctx.$style.headerCell, _ctx.$style.sortable]),
                  onClick: ($event) => setSort(column.key)
                }, [
                  createTextVNode(toDisplayString(column.label) + " ", 1),
                  createBaseVNode("span", {
                    class: normalizeClass({
                      [_ctx.$style.sortPrimary]: isPrimarySort(column.key),
                      [_ctx.$style.sortSecondary]: isSecondarySort(column.key)
                    })
                  }, toDisplayString(getSortIndicator(column.key)), 3)
                ], 10, _hoisted_1);
              }), 64))
            ])
          ]),
          createBaseVNode("tbody", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(rows.value, (x) => {
              return openBlock(), createElementBlock("tr", {
                key: x.ship.id
              }, [
                createBaseVNode("td", {
                  class: normalizeClass(_ctx.$style.bodyCell)
                }, [
                  createBaseVNode("span", {
                    class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).Link.link),
                    onClick: ($event) => unref(showBuffer)(`SFC ${x.ship.registration}`)
                  }, toDisplayString(x.ship.name || x.ship.registration), 11, _hoisted_2),
                  createBaseVNode("span", {
                    class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).ColoredValue.positive)
                  }, " " + toDisplayString(x.conditionText), 3)
                ], 2),
                createBaseVNode("td", {
                  class: normalizeClass([_ctx.$style.bodyCell, _ctx.$style.cargoCell])
                }, [
                  createVNode(CargoBar, {
                    "ship-id": x.ship.id
                  }, null, 8, ["ship-id"]),
                  createBaseVNode("div", {
                    class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).ShipStore.pointer, ("C" in _ctx ? _ctx.C : unref(C)).ShipStore.store, _ctx.$style.cargoSize])
                  }, toDisplayString(x.cargoSizeText), 3)
                ], 2),
                createBaseVNode("td", {
                  class: normalizeClass(_ctx.$style.bodyCell)
                }, [
                  createVNode(FleetStatusCell, {
                    "ship-id": x.ship.id
                  }, null, 8, ["ship-id"])
                ], 2),
                createBaseVNode("td", {
                  class: normalizeClass([_ctx.$style.bodyCell, _ctx.$style.fuelCell])
                }, [
                  createBaseVNode("div", {
                    class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).ShipFuel.container, ("C" in _ctx ? _ctx.C : unref(C)).ShipFuel.pointer, _ctx.$style.fuelBars]),
                    onClick: ($event) => onFuel(x.ship.registration)
                  }, [
                    createBaseVNode("div", {
                      class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).ProgressBar.container)
                    }, [
                      createBaseVNode("progress", {
                        class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).ProgressBar.primary, ("C" in _ctx ? _ctx.C : unref(C)).ProgressBar.progress]),
                        value: x.stlFuelRatio ?? 0,
                        max: "1"
                      }, null, 10, _hoisted_4)
                    ], 2),
                    createBaseVNode("div", {
                      class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).ProgressBar.container)
                    }, [
                      createBaseVNode("progress", {
                        class: normalizeClass([
                          ("C" in _ctx ? _ctx.C : unref(C)).ProgressBar.secondary,
                          ("C" in _ctx ? _ctx.C : unref(C)).ProgressBar.progress,
                          !x.isFtlCapable ? ("C" in _ctx ? _ctx.C : unref(C)).ProgressBar.warning : void 0
                        ]),
                        value: x.ftlFuelRatio ?? 0,
                        max: "1"
                      }, null, 10, _hoisted_5)
                    ], 2)
                  ], 10, _hoisted_3)
                ], 2)
              ]);
            }), 128))
          ])
        ], 2)
      ], 2));
    };
  }
});
export {
  _sfc_main as default
};
