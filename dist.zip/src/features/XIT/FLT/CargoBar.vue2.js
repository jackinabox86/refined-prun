import { useCssModule } from "../../../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import { shipsStore } from "../../../infrastructure/prun-api/data/ships.js";
import { storagesStore } from "../../../infrastructure/prun-api/data/storage.js";
import { getMaterialCategoryCssClass } from "../../../infrastructure/prun-ui/item-tracker.js";
import { materialCategoriesStore } from "../../../infrastructure/prun-api/data/material-categories.js";
import { fixed02 } from "../../../utils/format.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import { defineComponent, computed, watch, openBlock, createElementBlock, createElementVNode as createBaseVNode, Fragment, renderList, createCommentVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { ref, unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { normalizeStyle, normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _hoisted_1 = ["title"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CargoBar",
  props: {
    shipId: {}
  },
  setup(__props) {
    const props = __props;
    const $style = useCssModule();
    const cargoBar = computed(() => {
      const ship = shipsStore.getById(props.shipId);
      const inv = storagesStore.getById(ship?.idShipStore);
      if (!inv || inv.items.length === 0) {
        return {
          segments: [],
          miniMode: false
        };
      }
      const wCap = inv.weightCapacity;
      const vCap = inv.volumeCapacity;
      const wLoad = inv.weightLoad;
      const vLoad = inv.volumeLoad;
      const weightRatio = wLoad / wCap;
      const volumeRatio = vLoad / vCap;
      const maxRatio = Math.max(weightRatio, volumeRatio);
      const useVolume = volumeRatio > weightRatio;
      const isMiniMode = maxRatio <= 0.05 && maxRatio > 0;
      const activeLoad = useVolume ? vLoad : wLoad;
      const activeCapacity = useVolume ? vCap : wCap;
      let divisor = isMiniMode ? activeLoad : activeCapacity;
      if (divisor === 0) {
        divisor = 1;
      }
      const formatTitle = (name, weight, volume) => {
        const load = useVolume ? fixed02(volume) + "m³" : fixed02(weight) + "t";
        return `${name}: ${load}`;
      };
      const segments = [];
      const summary = getInventorySummary(inv);
      const categories = [...summary.categories.keys()].sort((a, b) => a.name.localeCompare(b.name));
      for (const category of categories) {
        const categorySummary = summary.categories.get(category);
        const value = useVolume ? categorySummary.volume : categorySummary.weight;
        const percentage = value * 100 / divisor;
        segments.push({
          name: category.name,
          class: getMaterialCategoryCssClass(category),
          width: `${percentage}%`,
          title: formatTitle(category.name, categorySummary.weight, categorySummary.volume)
        });
      }
      if (summary.shipments.weight > 0 || summary.shipments.volume > 0) {
        const value = useVolume ? summary.shipments.volume : summary.shipments.weight;
        const percentage = value * 100 / divisor;
        segments.push({
          name: "shipments",
          class: "rp-category-none",
          width: `${percentage}%`,
          title: formatTitle("shipments", summary.shipments.weight, summary.shipments.volume)
        });
      }
      if (!isMiniMode) {
        enhanceSegmentVisibility(segments, maxRatio);
      }
      return {
        segments,
        miniMode: isMiniMode
      };
    });
    function enhanceSegmentVisibility(segments, loadRatio) {
      const lowContrastCategories = /* @__PURE__ */ new Set(["elements", "metals", "shipments", "unit prefabs"]);
      const isAlmostFull = loadRatio > 0.98;
      if (segments.length === 1 && isAlmostFull) {
        return;
      }
      for (let i = 1; i < segments.length; i++) {
        const current = segments[i];
        const previous = segments[i - 1];
        const currentLowContrast = lowContrastCategories.has(current.name);
        const previousLowContrast = lowContrastCategories.has(previous.name);
        if (currentLowContrast && previousLowContrast) {
          current.borderClasses = [$style.borderLeft];
        }
      }
      if (!isAlmostFull) {
        const last = segments[segments.length - 1];
        last.borderClasses ??= [];
        last.borderClasses.push($style.borderRight);
      }
    }
    function getInventorySummary(store) {
      const shipments = {
        weight: 0,
        volume: 0
      };
      const categories = /* @__PURE__ */ new Map();
      for (const item of store.items) {
        if (item.type === "SHIPMENT") {
          shipments.weight += item.weight;
          shipments.volume += item.volume;
          continue;
        }
        const material = item.quantity?.material;
        if (!material) {
          continue;
        }
        const category = materialCategoriesStore.getById(material.category);
        if (!category) {
          continue;
        }
        let categorySummary = categories.get(category);
        if (!categorySummary) {
          categorySummary = { weight: 0, volume: 0 };
          categories.set(category, categorySummary);
        }
        categorySummary.weight += item.weight;
        categorySummary.volume += item.volume;
      }
      return { shipments, categories };
    }
    const miniBarClass = computed(() => ({
      [$style.miniBar]: cargoBar.value.miniMode
    }));
    const isAnimating = ref(false);
    let animationTimeout = null;
    watch(
      () => cargoBar.value.segments,
      () => {
        if (animationTimeout) {
          clearTimeout(animationTimeout);
        }
        isAnimating.value = true;
        animationTimeout = setTimeout(() => {
          isAnimating.value = false;
        }, 1e3);
      },
      { deep: true }
    );
    const totalLoadRatio = computed(() => {
      const ship = shipsStore.getById(props.shipId);
      const inv = storagesStore.getById(ship?.idShipStore);
      if (!inv) {
        return 0;
      }
      return Math.max(inv.weightLoad / inv.weightCapacity, inv.volumeLoad / inv.volumeCapacity);
    });
    const stripeAlertColor = computed(() => {
      const ratio = totalLoadRatio.value;
      const start = { r: 50, g: 50, b: 50 };
      const target = { r: 100, g: 100, b: 100 };
      if (ratio < 0.7) {
        return `rgb(${start.r}, ${start.g}, ${start.b})`;
      }
      const normalized = (ratio - 0.7) / 0.3;
      const r = Math.round(start.r + (target.r - start.r) * normalized);
      const g = Math.round(start.g + (target.g - start.g) * normalized);
      const b = Math.round(start.b + (target.b - start.b) * normalized);
      return `rgb(${r}, ${g}, ${b})`;
    });
    const stripeWidth = computed(() => {
      const ratio = totalLoadRatio.value;
      const startWidth = 10;
      const smallWidth = 2;
      if (ratio < 0.7) {
        return `${startWidth}px`;
      }
      const normalized = (ratio - 0.7) / 0.3;
      const width = startWidth - (startWidth - smallWidth) * normalized;
      return `${width}px`;
    });
    function onClick() {
      const ship = shipsStore.getById(props.shipId);
      if (ship) {
        showBuffer(`SHPI ${ship.registration}`);
      }
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).ProgressBar.progress, unref($style).container, { [unref($style).isUpdating]: isAnimating.value }]),
        style: normalizeStyle({ "--stripe-color": stripeAlertColor.value, "--stripe-width": stripeWidth.value }),
        onClick
      }, [
        createBaseVNode("div", {
          class: normalizeClass([unref($style).bar, miniBarClass.value])
        }, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(cargoBar.value.segments, (segment) => {
            return openBlock(), createElementBlock("div", {
              key: segment.name,
              class: normalizeClass([segment.class, segment.borderClasses]),
              style: normalizeStyle({ width: segment.width }),
              title: segment.title
            }, [
              segment.load ? (openBlock(), createElementBlock("div", {
                key: 0,
                class: normalizeClass(unref($style).full)
              }, toDisplayString(segment.load), 3)) : createCommentVNode("", true)
            ], 14, _hoisted_1);
          }), 128))
        ], 2)
      ], 6);
    };
  }
});
export {
  _sfc_main as default
};
