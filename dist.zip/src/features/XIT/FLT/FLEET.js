import xit from "../xit-registry.js";
import FLT from "./FLT.vue.js";
xit.add({
  command: ["FLT", "FLEET"],
  name: "FLEET",
  description: "Enhanced fleet table with detailed status, cargo, fuel, and quick actions.",
  component: () => FLT
});
