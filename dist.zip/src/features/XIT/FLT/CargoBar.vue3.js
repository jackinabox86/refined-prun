const container = "rp-CargoBar__container___06bd863";
const isUpdating = "rp-CargoBar__isUpdating___af10582";
const bar = "rp-CargoBar__bar___3ecab12";
const miniBar = "rp-CargoBar__miniBar___5783aa5";
const borderLeft = "rp-CargoBar__borderLeft___9a83a02";
const borderRight = "rp-CargoBar__borderRight___c38b639";
const full = "rp-CargoBar__full___5af5308";
const style0 = {
  container,
  isUpdating,
  "move-stripes": "rp-CargoBar__move-stripes___a6430d7",
  bar,
  miniBar,
  borderLeft,
  borderRight,
  full
};
export {
  bar,
  borderLeft,
  borderRight,
  container,
  style0 as default,
  full,
  isUpdating,
  miniBar
};
