import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import { withModifiers } from "../../../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import { shipsStore } from "../../../infrastructure/prun-api/data/ships.js";
import { flightsStore } from "../../../infrastructure/prun-api/data/flights.js";
import { hhmm, displaytimeBetween } from "../../../utils/format.js";
import { timestampEachMinute } from "../../../utils/dayjs.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import { getInvStore } from "../../../core/store-id.js";
import { stationaryShipStatusIcon, getShipStatusIcon } from "../../../core/ship-status-icons.js";
import { getLocationLineFromAddress, getEntityNameFromAddress } from "../../../infrastructure/prun-api/data/addresses.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = { style: { "color": "#99d5ff" } };
const _hoisted_2 = { style: { "color": "#888" } };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FleetStatusCell",
  props: {
    shipId: {}
  },
  setup(__props) {
    const props = __props;
    const ship = computed(() => shipsStore.getById(props.shipId));
    const flight = computed(() => flightsStore.getById(ship.value?.flightId));
    const inventory = computed(() => getInvStore(ship.value?.idShipStore));
    const statusIcon = computed(() => {
      if (!ship.value) {
        return "";
      }
      if (!flight.value) {
        return stationaryShipStatusIcon;
      }
      const segment = flight.value.segments[flight.value.currentSegmentIndex];
      return segment != null ? getShipStatusIcon(segment.type) : stationaryShipStatusIcon;
    });
    const posData = computed(() => {
      const address = flight.value?.destination ?? ship.value?.address ?? void 0;
      const location = getLocationLineFromAddress(address);
      const prefix = location?.type === "STATION" ? "STNS" : "PLI";
      return {
        name: getEntityNameFromAddress(address) ?? address?.lines[0]?.entity?.naturalId ?? "",
        command: `${prefix} ${location?.entity.naturalId}`,
        invCommand: `INV ${location?.entity.naturalId}`
      };
    });
    const timeData = computed(() => {
      const arrival = flight.value?.arrival.timestamp;
      if (arrival == null || Number.isNaN(arrival)) {
        return null;
      }
      return {
        relative: displaytimeBetween(timestampEachMinute.value, arrival),
        absolute: hhmm(arrival)
      };
    });
    const hasItems = computed(() => (inventory.value?.items.length ?? 0) > 0);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(_ctx.$style.mainContainer)
      }, [
        createBaseVNode("div", {
          class: normalizeClass([_ctx.$style.columnContainer, _ctx.$style.alignLeft])
        }, [
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.gapContainer)
          }, [
            createBaseVNode("span", {
              class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).Link.link),
              style: { "color": "#3fa2de" },
              onClick: _cache[0] || (_cache[0] = withModifiers(($event) => unref(showBuffer)(posData.value.invCommand), ["stop"]))
            }, "☒", 2),
            createBaseVNode("span", {
              style: { "color": "#3fa2de", "cursor": "pointer" },
              onClick: _cache[1] || (_cache[1] = withModifiers(($event) => unref(showBuffer)(`SFC ${ship.value?.registration}`), ["stop"]))
            }, toDisplayString(statusIcon.value), 1)
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).Link.link),
            style: { "color": "#3fa2de" },
            onClick: _cache[2] || (_cache[2] = withModifiers(($event) => unref(showBuffer)(posData.value.command), ["stop"]))
          }, toDisplayString(posData.value.name), 3)
        ], 2),
        createBaseVNode("div", {
          class: normalizeClass([_ctx.$style.columnContainer, _ctx.$style.alignRight])
        }, [
          timeData.value ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass(_ctx.$style.columnContainer),
            onClick: _cache[3] || (_cache[3] = withModifiers(($event) => unref(showBuffer)(`SFC ${ship.value?.registration}`), ["stop"]))
          }, [
            createBaseVNode("span", _hoisted_1, toDisplayString(timeData.value.relative), 1),
            createBaseVNode("span", _hoisted_2, "(" + toDisplayString(timeData.value.absolute) + ")", 1)
          ], 2)) : (openBlock(), createElementBlock("div", {
            key: 1,
            class: normalizeClass([_ctx.$style.gapContainer, _ctx.$style.rowContainer])
          }, [
            createBaseVNode("span", {
              class: normalizeClass([_ctx.$style.actionBtn, hasItems.value ? _ctx.$style.bgOrange : _ctx.$style.bgBlue]),
              style: { paddingRight: "5px" },
              onClick: _cache[4] || (_cache[4] = withModifiers(($event) => unref(showBuffer)(`SHPI ${ship.value?.registration}`), ["stop"]))
            }, toDisplayString(hasItems.value ? "⭱" : "⭳"), 3),
            createBaseVNode("span", {
              class: normalizeClass([_ctx.$style.actionBtn, _ctx.$style.bgGreen]),
              onClick: _cache[5] || (_cache[5] = withModifiers(($event) => unref(showBuffer)(`SFC ${ship.value?.registration}`), ["stop"]))
            }, " ✈ ", 2)
          ], 2))
        ], 2)
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
