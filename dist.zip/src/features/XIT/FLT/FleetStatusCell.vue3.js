const mainContainer = "rp-FleetStatusCell__mainContainer___9688cc2";
const columnContainer = "rp-FleetStatusCell__columnContainer___b232436";
const rowContainer = "rp-FleetStatusCell__rowContainer___d5a0f08";
const alignLeft = "rp-FleetStatusCell__alignLeft___eb44721";
const alignRight = "rp-FleetStatusCell__alignRight___3a5b63a";
const gapContainer = "rp-FleetStatusCell__gapContainer___8c98b02";
const actionBtn = "rp-FleetStatusCell__actionBtn___54bd29b";
const bgOrange = "rp-FleetStatusCell__bgOrange___0946f82";
const bgBlue = "rp-FleetStatusCell__bgBlue___b35d019";
const bgGreen = "rp-FleetStatusCell__bgGreen___bf29deb";
const style0 = {
  mainContainer,
  columnContainer,
  rowContainer,
  alignLeft,
  alignRight,
  gapContainer,
  actionBtn,
  bgOrange,
  bgBlue,
  bgGreen
};
export {
  actionBtn,
  alignLeft,
  alignRight,
  bgBlue,
  bgGreen,
  bgOrange,
  columnContainer,
  style0 as default,
  gapContainer,
  mainContainer,
  rowContainer
};
