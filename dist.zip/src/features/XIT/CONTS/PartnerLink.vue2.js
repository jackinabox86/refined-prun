import PrunLink from "../../../components/PrunLink.vue.js";
import { isFactionContract } from "./utils.js";
import fa from "../../../utils/font-awesome.module.css.js";
import coloredValue from "../../../infrastructure/prun-ui/css/colored-value.module.css.js";
import distrust from "../../../infrastructure/prun-ui/css/distrust.module.css.js";
import { isDistrustedPartner } from "../../../store/distrust.js";
import { defineComponent, computed, openBlock, createBlock, withCtx, createElementVNode as createBaseVNode, createTextVNode, createElementBlock } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _hoisted_1 = { key: 4 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "PartnerLink",
  props: {
    contract: {}
  },
  setup(__props) {
    const distrustedClass = computed(
      () => !isFactionContract(__props.contract) && isDistrustedPartner(__props.contract.partner) ? distrust.distrusted : void 0
    );
    return (_ctx, _cache) => {
      return unref(isFactionContract)(_ctx.contract) ? (openBlock(), createBlock(PrunLink, {
        key: 0,
        command: `FA ${_ctx.contract.partner.countryCode}`
      }, {
        default: withCtx(() => [
          createBaseVNode("span", {
            class: normalizeClass([unref(fa).regular, unref(coloredValue).warning])
          }, toDisplayString(""), 2),
          createTextVNode(" " + toDisplayString(_ctx.contract.partner.name), 1)
        ]),
        _: 1
      }, 8, ["command"])) : _ctx.contract.partner.name ? (openBlock(), createBlock(PrunLink, {
        key: 1,
        command: `CO ${_ctx.contract.partner.code}`,
        class: normalizeClass(unref(distrustedClass))
      }, {
        default: withCtx(() => [
          createTextVNode(toDisplayString(_ctx.contract.partner.name), 1)
        ]),
        _: 1
      }, 8, ["command", "class"])) : _ctx.contract.partner.code ? (openBlock(), createBlock(PrunLink, {
        key: 2,
        command: `CO ${_ctx.contract.partner.code}`,
        class: normalizeClass(unref(distrustedClass))
      }, null, 8, ["command", "class"])) : _ctx.contract.partner.currency ? (openBlock(), createElementBlock("div", {
        key: 3,
        "data-tooltip": "Refined PrUn is unable to fetch government information. Check the contract info for more details.",
        "data-tooltip-position": "down",
        class: normalizeClass(_ctx.$style.overrideTooltipStyle)
      }, " Planetary Government ", 2)) : (openBlock(), createElementBlock("div", _hoisted_1, "Unknown"));
    };
  }
});
export {
  _sfc_main as default
};
