import LoadingSpinner from "../../../components/LoadingSpinner.vue.js";
import { contractsStore } from "../../../infrastructure/prun-api/data/contracts.js";
import _sfc_main$1 from "./ContractRow.vue.js";
import { canAcceptContract } from "./utils.js";
import { isEmpty } from "../../../../npm/ts-extras@0.15.0-ts-extras-is-empty.js";
import { defineComponent, computed, openBlock, createBlock, createElementBlock, createElementVNode as createBaseVNode, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = { key: 1 };
const _hoisted_2 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CONTS",
  setup(__props) {
    const filtered = computed(
      () => contractsStore.all.value.filter(shouldShowContract).sort(compareContracts)
    );
    function shouldShowContract(contract) {
      switch (contract.status) {
        case "OPEN":
        case "CLOSED":
        case "PARTIALLY_FULFILLED":
        case "DEADLINE_EXCEEDED": {
          return true;
        }
        default: {
          return false;
        }
      }
    }
    function compareContracts(a, b) {
      if (canAcceptContract(a) && !canAcceptContract(b)) {
        return -1;
      }
      if (canAcceptContract(b) && !canAcceptContract(a)) {
        return 1;
      }
      return (b.date?.timestamp ?? 0) - (a.date?.timestamp ?? 0);
    }
    return (_ctx, _cache) => {
      return !unref(contractsStore).fetched ? (openBlock(), createBlock(LoadingSpinner, { key: 0 })) : (openBlock(), createElementBlock("table", _hoisted_1, [
        _cache[1] || (_cache[1] = createBaseVNode("thead", null, [
          createBaseVNode("tr", null, [
            createBaseVNode("th", null, "Contract"),
            createBaseVNode("th", null, "Item"),
            createBaseVNode("th", null, "Partner"),
            createBaseVNode("th", null, "Self")
          ])
        ], -1)),
        createBaseVNode("tbody", null, [
          unref(isEmpty)(unref(filtered)) ? (openBlock(), createElementBlock("tr", _hoisted_2, [..._cache[0] || (_cache[0] = [
            createBaseVNode("td", { colspan: "4" }, "No active contracts", -1)
          ])])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(unref(filtered), (contract) => {
            return openBlock(), createBlock(_sfc_main$1, {
              key: contract.id,
              contract
            }, null, 8, ["contract"]);
          }), 128))
        ])
      ]));
    };
  }
});
export {
  _sfc_main as default
};
