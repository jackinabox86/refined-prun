import PrunLink from "../../../components/PrunLink.vue.js";
import { canAcceptContract, canPartnerAcceptContract, isFactionContract } from "./utils.js";
import fa from "../../../utils/font-awesome.module.css.js";
import coloredValue from "../../../infrastructure/prun-ui/css/colored-value.module.css.js";
import { defineComponent, computed, openBlock, createBlock, withCtx, createTextVNode, createElementBlock, createCommentVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeStyle, toDisplayString, normalizeClass } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ContractLink",
  props: {
    contract: {}
  },
  setup(__props) {
    const canAccept = computed(() => canAcceptContract(__props.contract));
    const canPartnerAccept = computed(() => canPartnerAcceptContract(__props.contract));
    const linkStyle = computed(() => ({
      display: isFactionContract(__props.contract) ? "inline" : "block"
    }));
    return (_ctx, _cache) => {
      return openBlock(), createBlock(PrunLink, {
        command: `CONT ${_ctx.contract.localId}`,
        style: normalizeStyle(unref(linkStyle))
      }, {
        default: withCtx(() => [
          createTextVNode(toDisplayString(_ctx.contract.name || _ctx.contract.localId) + " ", 1),
          unref(canAccept) ? (openBlock(), createElementBlock("span", {
            key: 0,
            class: normalizeClass([unref(fa).solid, unref(coloredValue).warning])
          }, toDisplayString(""), 2)) : createCommentVNode("", true),
          unref(canPartnerAccept) ? (openBlock(), createElementBlock("span", {
            key: 1,
            class: normalizeClass([unref(fa).solid, unref(coloredValue).warning])
          }, toDisplayString(""), 2)) : createCommentVNode("", true)
        ]),
        _: 1
      }, 8, ["command", "style"]);
    };
  }
});
export {
  _sfc_main as default
};
