import { calculateLocationAssets } from "../../../core/financials.js";
import KeyFigures from "./KeyFigures.vue.js";
import _sfc_main$1 from "./FinHeader.vue.js";
import { formatCurrency, fixed0, fixed1, fixed2, percent0, percent1, percent2 } from "../../../utils/format.js";
import { liveBalanceSummary } from "../../../core/balance/balance-sheet-live.js";
import { userData } from "../../../store/user-data.js";
import { defineComponent, computed, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FIN",
  setup(__props) {
    const locations = computed(() => calculateLocationAssets());
    function formatRatio(ratio) {
      if (ratio === void 0) {
        return "--";
      }
      if (!isFinite(ratio)) {
        return "N/A";
      }
      const absRatio = Math.abs(ratio);
      if (absRatio > 1e3) {
        return ratio > 0 ? "> 1,000" : "< -1,000";
      }
      if (absRatio > 100) {
        return fixed0(ratio);
      }
      if (absRatio > 10) {
        return fixed1(ratio);
      }
      return fixed2(ratio);
    }
    function formatPercentage(ratio) {
      if (ratio === void 0) {
        return "--";
      }
      if (!isFinite(ratio)) {
        return "N/A";
      }
      const absRatio = Math.abs(ratio);
      if (absRatio > 10) {
        return ratio > 0 ? "> 1,000%" : "< -1,000%";
      }
      if (absRatio > 1) {
        return percent0(ratio);
      }
      if (absRatio > 0.1) {
        return percent1(ratio);
      }
      return percent2(ratio);
    }
    const figures = computed(() => {
      return [
        {
          name: "Quick Assets",
          value: formatCurrency(liveBalanceSummary.quickAssets),
          tooltip: "Quick Assets are: Cash and Cash Equivalents, Current Accounts Receivable, and Current Loans Receivable (see XIT FINBS for more details). These assets are either liquid or close-to-liquid and are used in Quick Ratio calculation."
        },
        {
          name: "Current Assets",
          value: formatCurrency(liveBalanceSummary.currentAssets)
        },
        { name: "Total Assets", value: formatCurrency(liveBalanceSummary.assets) },
        { name: "Equity", value: formatCurrency(liveBalanceSummary.equity) },
        {
          name: "Quick Liabilities",
          value: formatCurrency(liveBalanceSummary.quickLiabilities),
          tooltip: "Quick Liabilities are: Current Accounts Payable and Current Loans Payable (see XIT FINBS for more details). These liabilities represent immediate financial obligations and are used in Quick Ratio calculation."
        },
        {
          name: "Current Liabilities",
          value: formatCurrency(liveBalanceSummary.currentLiabilities)
        },
        {
          name: "Total Liabilities",
          value: formatCurrency(liveBalanceSummary.liabilities)
        },
        {
          name: "Liquidation Value",
          hidden: !userData.fullEquityMode,
          value: formatCurrency(liveBalanceSummary.liquidationValue),
          tooltip: "The market value of all company’s assets that can be converted to cash directly. The Liquidation Value excludes such assets as ships, HQ upgrades, and ARC, since they cannot be sold on the market."
        },
        {
          name: "Quick Ratio",
          value: formatRatio(liveBalanceSummary.acidTestRatio),
          tooltip: "The quick, or acid-test ratio, compares a company's quick assets to its quick liabilities to see if it has enough cash to pay its immediate liabilities, such as short-term debt. Generally, a ratio of 1.0 or more indicates a company can pay its short-term obligations, while a ratio of less than 1.0 indicates it might struggle to pay them."
        },
        {
          name: "Debt Ratio",
          value: formatPercentage(liveBalanceSummary.debtRatio),
          tooltip: "The debt ratio is defined as the ratio of total debt to total assets. A debt ratio of greater than 100% means a company has more debt than assets while a debt ratio of less than 100% indicates that a company has more assets than debt."
        }
      ];
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(_sfc_main$1, null, {
          default: withCtx(() => [..._cache[0] || (_cache[0] = [
            createTextVNode("Key Figures", -1)
          ])]),
          _: 1
        }),
        createVNode(KeyFigures, { figures: unref(figures) }, null, 8, ["figures"]),
        createVNode(_sfc_main$1, null, {
          default: withCtx(() => [..._cache[1] || (_cache[1] = [
            createTextVNode("Inventory Breakdown", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("table", null, [
          _cache[2] || (_cache[2] = createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", null, "Name"),
              createBaseVNode("th", null, "Non-Current Assets"),
              createBaseVNode("th", null, "Current Assets"),
              createBaseVNode("th", null, "Total Assets")
            ])
          ], -1)),
          createBaseVNode("tbody", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(locations), (location) => {
              return openBlock(), createElementBlock("tr", {
                key: location.name
              }, [
                createBaseVNode("td", null, toDisplayString(location.name), 1),
                createBaseVNode("td", null, toDisplayString(unref(fixed0)(location.nonCurrent)), 1),
                createBaseVNode("td", null, toDisplayString(unref(fixed0)(location.current)), 1),
                createBaseVNode("td", null, toDisplayString(unref(fixed0)(location.total)), 1)
              ]);
            }), 128))
          ])
        ])
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
