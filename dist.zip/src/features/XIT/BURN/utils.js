import { materialsStore } from "../../../infrastructure/prun-api/data/materials.js";
import { sortMaterials } from "../../../core/sort-materials.js";
function getSortedTickers(burn) {
  const materials = Object.keys(burn.burn).map(materialsStore.getByTicker);
  return sortMaterials(materials.filter((x) => x !== void 0));
}
function countDays(burn) {
  let days = 1e3;
  for (const key of Object.keys(burn)) {
    const mat = burn[key];
    if (!isNaN(mat.dailyAmount) && mat.dailyAmount < 0 && mat.daysLeft < days) {
      days = mat.daysLeft;
    }
  }
  return days;
}
export {
  countDays,
  getSortedTickers
};
