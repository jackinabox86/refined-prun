import _sfc_main from "./BurnActWindow.vue.js";
export {
  _sfc_main as default
};
