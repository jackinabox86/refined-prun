import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import { _$ } from "../../../utils/select-dom.js";
import { useXitParameters } from "../../../hooks/use-xit-parameters.js";
import { useTile } from "../../../hooks/use-tile.js";
import ExecuteActionPackage from "../ACT/ExecuteActionPackage.vue.js";
import { sitesStore } from "../../../infrastructure/prun-api/data/sites.js";
import { getEntityNameFromAddress } from "../../../infrastructure/prun-api/data/addresses.js";
import { configurableValue } from "../ACT/shared-types.js";
import { defineComponent, onMounted, nextTick, computed, openBlock, createElementBlock, createBlock } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "BurnActWindow",
  setup(__props) {
    const parameters = useXitParameters();
    const naturalId = parameters.join(" ");
    const tile = useTile();
    onMounted(async () => {
      await nextTick();
      const windowEl = tile.frame.closest(`.${C.Window.window}`);
      const bodyEl = windowEl ? _$(windowEl, C.Window.body) : null;
      if (!bodyEl) {
        return;
      }
      let overflow = 0;
      for (const el of tile.anchor.querySelectorAll("*")) {
        const htmlEl = el;
        overflow = Math.max(overflow, htmlEl.scrollHeight - htmlEl.clientHeight);
      }
      if (overflow > 0) {
        bodyEl.style.height = `${bodyEl.offsetHeight + overflow}px`;
      }
    });
    const site = computed(() => sitesStore.getByPlanetNaturalIdOrName(naturalId));
    const planetName = computed(
      () => site.value ? getEntityNameFromAddress(site.value.address) : void 0
    );
    const pkg = computed(
      () => ({
        global: { name: `Burn Resupply: ${planetName.value ?? naturalId}` },
        groups: [
          {
            type: "Resupply",
            name: "Resupply",
            planet: planetName.value,
            days: configurableValue,
            useBaseInv: true
          }
        ],
        actions: [
          {
            type: "CX Buy",
            name: "CX Buy",
            group: "Resupply",
            exchange: configurableValue,
            useCXInv: true,
            skippable: true
          },
          {
            type: "MTRA",
            name: "MTRA",
            group: "Resupply",
            origin: configurableValue,
            dest: configurableValue
          }
        ]
      })
    );
    return (_ctx, _cache) => {
      return !unref(planetName) ? (openBlock(), createElementBlock("div", _hoisted_1, 'Planet "' + toDisplayString(unref(naturalId)) + '" not found.', 1)) : (openBlock(), createBlock(ExecuteActionPackage, {
        key: 1,
        pkg: unref(pkg)
      }, null, 8, ["pkg"]));
    };
  }
});
export {
  _sfc_main as default
};
