import xit from "../xit-registry.js";
import BURN from "./BURN.vue.js";
import { sitesStore } from "../../../infrastructure/prun-api/data/sites.js";
import { getEntityNameFromAddress } from "../../../infrastructure/prun-api/data/addresses.js";
xit.add({
  command: "BURN",
  name: (parameters) => {
    if (parameters[0] && !parameters[1]) {
      const site = sitesStore.getByPlanetNaturalIdOrName(parameters[0]);
      if (site) {
        const name = getEntityNameFromAddress(site.address);
        return `ENHANCED BURN - ${name}`;
      }
    }
    return "ENHANCED BURN";
  },
  description: "Shows the number of days of consumables left.",
  optionalParameters: "Planet Identifier(s), OVERALL, NOT",
  component: () => BURN
});
