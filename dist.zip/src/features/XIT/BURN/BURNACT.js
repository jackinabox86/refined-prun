import xit from "../xit-registry.js";
import "../ACT/actions/cx-buy/cx-buy.js";
import "../ACT/actions/mtra/mtra.js";
import "../ACT/material-groups/resupply/resupply.js";
import _sfc_main from "./BurnActWindow.vue.js";
import { sitesStore } from "../../../infrastructure/prun-api/data/sites.js";
import { getEntityNameFromAddress } from "../../../infrastructure/prun-api/data/addresses.js";
xit.add({
  command: "BURNACT",
  name: (parameters) => {
    if (parameters[0]) {
      const site = sitesStore.getByPlanetNaturalIdOrName(parameters[0]);
      const name = site ? getEntityNameFromAddress(site.address) : parameters[0];
      return `BURN RESUPPLY - ${name}`;
    }
    return "BURN RESUPPLY";
  },
  description: "Executes a resupply action package for a planet from the burn screen.",
  component: () => _sfc_main
});
