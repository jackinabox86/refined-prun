import MaterialRow from "./MaterialRow.vue.js";
import { getSortedTickers } from "./utils.js";
import { defineComponent, computed, openBlock, createElementBlock, Fragment, renderList, createBlock } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "MaterialList",
  props: {
    burn: {}
  },
  setup(__props) {
    const sorted = computed(() => getSortedTickers(__props.burn));
    return (_ctx, _cache) => {
      return openBlock(true), createElementBlock(Fragment, null, renderList(unref(sorted), (material) => {
        return openBlock(), createBlock(MaterialRow, {
          key: material.id,
          burn: _ctx.burn.burn[material.ticker],
          material
        }, null, 8, ["burn", "material"]);
      }), 128);
    };
  }
});
export {
  _sfc_main as default
};
