const fakeRow = "rp-BURN__fakeRow___931b8ea";
const spacer = "rp-BURN__spacer___e59de81";
const expand = "rp-BURN__expand___4888051";
const style0 = {
  fakeRow,
  spacer,
  expand
};
export {
  style0 as default,
  expand,
  fakeRow,
  spacer
};
