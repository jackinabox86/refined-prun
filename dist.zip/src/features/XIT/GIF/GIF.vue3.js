const container = "rp-GIF__container___41f92a2";
const containerClickable = "rp-GIF__containerClickable___6b84abc";
const wrap = "rp-GIF__wrap___a8ad47f";
const image = "rp-GIF__image___7c61666";
const watermark = "rp-GIF__watermark___bfc9bb4";
const style0 = {
  container,
  containerClickable,
  wrap,
  image,
  watermark
};
export {
  container,
  containerClickable,
  style0 as default,
  image,
  watermark,
  wrap
};
