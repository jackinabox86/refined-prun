import PrunLink from "../../components/PrunLink.vue.js";
import { defineComponent, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "HELP",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("table", null, [
        _cache[6] || (_cache[6] = createBaseVNode("thead", null, [
          createBaseVNode("tr", null, [
            createBaseVNode("th", null, "I want to..."),
            createBaseVNode("th", null, "Command")
          ])
        ], -1)),
        createBaseVNode("tbody", null, [
          createBaseVNode("tr", null, [
            _cache[0] || (_cache[0] = createBaseVNode("td", null, "Change Refined PrUn settings.", -1)),
            createBaseVNode("td", null, [
              createVNode(PrunLink, { command: "XIT SET" })
            ])
          ]),
          createBaseVNode("tr", null, [
            _cache[1] || (_cache[1] = createBaseVNode("td", null, "Change the feature set to Basic/Full.", -1)),
            createBaseVNode("td", null, [
              createVNode(PrunLink, { command: "XIT SET FEAT" })
            ])
          ]),
          createBaseVNode("tr", null, [
            _cache[2] || (_cache[2] = createBaseVNode("td", null, "Disable some Refined PrUn feature.", -1)),
            createBaseVNode("td", null, [
              createVNode(PrunLink, { command: "XIT SET FEAT" })
            ])
          ]),
          createBaseVNode("tr", null, [
            _cache[3] || (_cache[3] = createBaseVNode("td", null, "Find out which XIT commands are available.", -1)),
            createBaseVNode("td", null, [
              createVNode(PrunLink, { command: "XIT CMDS" })
            ])
          ]),
          createBaseVNode("tr", null, [
            _cache[4] || (_cache[4] = createBaseVNode("td", null, "Import PMMG settings.", -1)),
            createBaseVNode("td", null, [
              createVNode(PrunLink, { command: "XIT SET PMMG" })
            ])
          ]),
          createBaseVNode("tr", null, [
            _cache[5] || (_cache[5] = createBaseVNode("td", null, "Get a random corgi gif.", -1)),
            createBaseVNode("td", null, [
              createVNode(PrunLink, { command: "XIT GIF CORGI" })
            ])
          ])
        ])
      ]);
    };
  }
});
export {
  _sfc_main as default
};
