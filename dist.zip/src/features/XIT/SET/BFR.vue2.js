import { useCssModule } from "../../../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import { $, _$ } from "../../../utils/select-dom.js";
import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import _sfc_main$3 from "../../../components/ActionBar.vue.js";
import _sfc_main$2 from "../../../components/PrunButton.vue.js";
import SectionHeader from "../../../components/SectionHeader.vue.js";
import { userData } from "../../../store/user-data.js";
import removeArrayElement from "../../../utils/remove-array-element.js";
import { vDraggable as so } from "../../../../npm/vue-draggable-plus@0.6.0_@types+sortablejs@1.15.8-vue-draggable-plus-vue-draggable-plus.js";
import _sfc_main$4 from "../../../components/forms/TextInput.vue.js";
import { grip } from "../../../components/grip/index.js";
import GripCell from "../../../components/grip/GripCell.vue.js";
import GripHeaderCell from "../../../components/grip/GripHeaderCell.vue.js";
import _sfc_main$1 from "../../../components/Tooltip.vue.js";
import _sfc_main$5 from "../../../components/forms/NumberInput.vue.js";
import { objectId } from "../../../utils/object-id.js";
import InlineFlex from "../../../components/InlineFlex.vue.js";
import { defineComponent, useTemplateRef, computed, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createBlock, Fragment, createElementVNode as createBaseVNode, withDirectives, renderList, createCommentVNode, Teleport } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { ref, unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString, normalizeStyle } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _hoisted_2 = { key: 1 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "BFR",
  setup(__props) {
    const $style = useCssModule();
    const picking = ref(false);
    const overlay = useTemplateRef("overlay");
    const pickedBuffer = ref(null);
    const overlayCursor = computed(() => pickedBuffer.value ? "pointer" : "default");
    function onOverlayMouseMove(e) {
      if (!picking.value) {
        return;
      }
      const lastPickedBuffer = pickedBuffer.value;
      pickedBuffer.value = getBufferUnderCursor(e);
      lastPickedBuffer?.classList.remove($style.highlight);
      pickedBuffer.value?.classList.add($style.highlight);
    }
    async function onOverlayMouseClick(e) {
      const buffer = getBufferUnderCursor(e);
      pickedBuffer.value?.classList.remove($style.highlight);
      pickedBuffer.value = null;
      picking.value = false;
      if (!buffer) {
        return;
      }
      const cmd = await $(buffer, C.TileFrame.cmd);
      if (!cmd.textContent) {
        return;
      }
      const body = await $(buffer, C.Window.body);
      const width = parseInt(body.style.width.replace("px", ""), 10);
      const height = parseInt(body.style.height.replace("px", ""), 10);
      userData.settings.buffers.unshift([cmd.textContent, width, height]);
    }
    function getBufferUnderCursor(e) {
      const element = getElementUnderCursor(e);
      if (!element) {
        return void 0;
      }
      const window = element.closest(`.${C.Window.window}`);
      if (!window) {
        return void 0;
      }
      const cmd = _$(window, C.TileFrame.cmd);
      if (!cmd) {
        return void 0;
      }
      return window;
    }
    function getElementUnderCursor(e) {
      overlay.value.style.pointerEvents = "none";
      const element = document.elementFromPoint(e.clientX, e.clientY);
      overlay.value.style.pointerEvents = "all";
      return element;
    }
    function addNewRule() {
      userData.settings.buffers.unshift(["", 450, 300]);
    }
    function deleteRule(rule) {
      removeArrayElement(userData.settings.buffers, rule);
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(SectionHeader, null, {
          default: withCtx(() => [
            _cache[1] || (_cache[1] = createTextVNode(" Override Default Buffer Sizes ", -1)),
            createVNode(_sfc_main$1, {
              position: "bottom",
              class: normalizeClass(unref($style).tooltip),
              tooltip: "The first matched rule will be used. If no rules match, the default buffer size will be used.\n        You can reorganize the rules by dragging them up and down."
            }, null, 8, ["class"])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$3, null, {
          default: withCtx(() => [
            unref(picking) ? (openBlock(), createBlock(_sfc_main$2, {
              key: 0,
              neutral: ""
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(unref(pickedBuffer) ? "CLICK TO PICK THIS BUFFER" : "CLICK ANYWHERE TO CANCEL"), 1)
              ]),
              _: 1
            })) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
              createVNode(_sfc_main$2, {
                primary: "",
                onClick: _cache[0] || (_cache[0] = ($event) => picking.value = true)
              }, {
                default: withCtx(() => [..._cache[2] || (_cache[2] = [
                  createTextVNode("PICK BUFFER", -1)
                ])]),
                _: 1
              }),
              createVNode(_sfc_main$2, {
                primary: "",
                onClick: addNewRule
              }, {
                default: withCtx(() => [..._cache[3] || (_cache[3] = [
                  createTextVNode("ADD NEW RULE", -1)
                ])]),
                _: 1
              })
            ], 64))
          ]),
          _: 1
        }),
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createVNode(GripHeaderCell),
              createBaseVNode("th", null, [
                createVNode(InlineFlex, null, {
                  default: withCtx(() => [
                    _cache[4] || (_cache[4] = createTextVNode(" Command ", -1)),
                    createVNode(_sfc_main$1, {
                      position: "right",
                      tooltip: "Can be a full command, a part of it, or a regular expression. Case-insensitive."
                    })
                  ]),
                  _: 1
                })
              ]),
              _cache[5] || (_cache[5] = createBaseVNode("th", null, "Width", -1)),
              _cache[6] || (_cache[6] = createBaseVNode("th", null, "Height", -1)),
              _cache[7] || (_cache[7] = createBaseVNode("th", null, null, -1))
            ])
          ]),
          unref(userData).settings.buffers.length === 0 ? (openBlock(), createElementBlock("tbody", _hoisted_1, [..._cache[8] || (_cache[8] = [
            createBaseVNode("tr", null, [
              createBaseVNode("td", { colspan: "5" }, "Nothing here yet.")
            ], -1)
          ])])) : withDirectives((openBlock(), createElementBlock("tbody", _hoisted_2, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(userData).settings.buffers, (rule) => {
              return openBlock(), createElementBlock("tr", {
                key: unref(objectId)(rule)
              }, [
                createVNode(GripCell),
                createBaseVNode("td", {
                  class: normalizeClass(unref($style).commandCell)
                }, [
                  createBaseVNode("div", {
                    class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).forms.input, unref($style).inline])
                  }, [
                    createVNode(_sfc_main$4, {
                      modelValue: rule[0],
                      "onUpdate:modelValue": ($event) => rule[0] = $event
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ], 2)
                ], 2),
                createBaseVNode("td", {
                  class: normalizeClass(unref($style).sizeCell)
                }, [
                  createBaseVNode("div", {
                    class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).forms.input, unref($style).inline])
                  }, [
                    createVNode(_sfc_main$5, {
                      modelValue: rule[1],
                      "onUpdate:modelValue": ($event) => rule[1] = $event
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ], 2)
                ], 2),
                createBaseVNode("td", {
                  class: normalizeClass(unref($style).sizeCell)
                }, [
                  createBaseVNode("div", {
                    class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).forms.input, unref($style).inline])
                  }, [
                    createVNode(_sfc_main$5, {
                      modelValue: rule[2],
                      "onUpdate:modelValue": ($event) => rule[2] = $event
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ], 2)
                ], 2),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$2, {
                    danger: "",
                    onClick: ($event) => deleteRule(rule)
                  }, {
                    default: withCtx(() => [..._cache[9] || (_cache[9] = [
                      createTextVNode("DELETE", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ])
              ]);
            }), 128))
          ])), [
            [unref(so), [unref(userData).settings.buffers, unref(grip).draggable]]
          ])
        ]),
        (openBlock(), createBlock(Teleport, { to: "body" }, [
          unref(picking) ? (openBlock(), createElementBlock("div", {
            key: 0,
            ref_key: "overlay",
            ref: overlay,
            class: normalizeClass(unref($style).overlay),
            style: normalizeStyle({ cursor: unref(overlayCursor) }),
            onClick: onOverlayMouseClick,
            onMousemove: onOverlayMouseMove
          }, null, 38)) : createCommentVNode("", true)
        ]))
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
