import _sfc_main$6 from "../../../components/PrunButton.vue.js";
import SectionHeader from "../../../components/SectionHeader.vue.js";
import _sfc_main$2 from "../../../components/Tooltip.vue.js";
import _sfc_main$3 from "../../../components/forms/TextInput.vue.js";
import _sfc_main$1 from "../../../components/forms/Active.vue.js";
import _sfc_main$4 from "../../../components/forms/NumberInput.vue.js";
import _sfc_main$7 from "../../../components/forms/Commands.vue.js";
import { showConfirmationOverlay } from "../../../infrastructure/prun-ui/tile-overlay.js";
import { userData, initialUserData } from "../../../store/user-data.js";
import { exportUserData, downloadBackup, importUserData, saveUserData, restoreBackup, resetUserData } from "../../../infrastructure/storage/user-data-serializer.js";
import SelectInput from "../../../components/forms/SelectInput.vue.js";
import { objectId } from "../../../utils/object-id.js";
import { getUserDataBackups, deleteUserDataBackup } from "../../../infrastructure/storage/user-data-backup.js";
import { hhForXitSet, ddmmyyyy, hhmm } from "../../../utils/format.js";
import dayjs from "../../../../npm/dayjs@1.11.18-dayjs-dayjs.min.js";
import { vDraggable as so } from "../../../../npm/vue-draggable-plus@0.6.0_@types+sortablejs@1.15.8-vue-draggable-plus-vue-draggable-plus.js";
import { grip } from "../../../components/grip/index.js";
import _sfc_main$5 from "../../../components/grip/GripChar.vue.js";
import { defineComponent, computed, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, createBlock, createCommentVNode, withDirectives, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref, isRef } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { normalizeClass } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "GAME",
  setup(__props) {
    const isDefault24 = computed(() => {
      return hhForXitSet.value(dayjs.duration(12, "hours").asMilliseconds()) === "13";
    });
    const timeFormats = computed(() => {
      return [
        {
          label: "24h",
          value: "24H"
        },
        {
          label: "12h",
          value: "12H"
        }
      ];
    });
    const timeFormat = computed({
      get: () => {
        const format = userData.settings.time;
        if (format === "DEFAULT") {
          return isDefault24.value ? "24H" : "12H";
        }
        return format;
      },
      set: (value) => userData.settings.time = value
    });
    const exchangeChartTypes = [
      {
        label: "Smooth",
        value: "SMOOTH"
      },
      {
        label: "Aligned",
        value: "ALIGNED"
      },
      {
        label: "Raw",
        value: "RAW"
      }
    ];
    const currencySettings = computed(() => userData.settings.currency);
    const currencyPresets = [
      {
        label: "Default",
        value: "DEFAULT"
      },
      {
        label: "₳",
        value: "AIC"
      },
      {
        label: "₡",
        value: "CIS"
      },
      {
        label: "ǂ",
        value: "ICA"
      },
      {
        label: "₦",
        value: "NCC"
      },
      {
        label: "Custom",
        value: "CUSTOM"
      }
    ];
    const currencyPosition = [
      {
        label: "After",
        value: "AFTER"
      },
      {
        label: "Before",
        value: "BEFORE"
      }
    ];
    const currencySpacing = [
      {
        label: "Has space",
        value: "HAS_SPACE"
      },
      {
        label: "No space",
        value: "NO_SPACE"
      }
    ];
    const backups = computed(() => getUserDataBackups());
    function addSidebarButton() {
      userData.settings.sidebar.push(["SET", "XIT SET"]);
    }
    function deleteSidebarButton(index) {
      userData.settings.sidebar.splice(index, 1);
    }
    function confirmResetSidebar(ev) {
      showConfirmationOverlay(ev, () => {
        userData.settings.sidebar = structuredClone(initialUserData.settings.sidebar);
      });
    }
    function importUserDataAndReload() {
      importUserData(async () => {
        await saveUserData();
        window.location.reload();
      });
    }
    async function restoreBackupAndReload(ev, backup) {
      showConfirmationOverlay(
        ev,
        async () => {
          restoreBackup(backup);
          await saveUserData();
          window.location.reload();
        },
        {
          message: "Are you sure you want to restore this backup? This will overwrite your current data."
        }
      );
    }
    function confirmDeleteBackup(ev, backup) {
      showConfirmationOverlay(ev, () => deleteUserDataBackup(backup));
    }
    function confirmResetAllData(ev) {
      showConfirmationOverlay(ev, async () => {
        resetUserData();
        await saveUserData();
        window.location.reload();
      });
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[9] || (_cache[9] = [
            createTextVNode("Appearance", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$1, { label: "Time format" }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: unref(timeFormat),
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(timeFormat) ? timeFormat.value = $event : null),
                options: unref(timeFormats)
              }, null, 8, ["modelValue", "options"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, { label: "Default CX Chart Type" }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: unref(userData).settings.defaultChartType,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => unref(userData).settings.defaultChartType = $event),
                options: exchangeChartTypes
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          })
        ]),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [
            _cache[10] || (_cache[10] = createTextVNode(" Currency Symbol ", -1)),
            createVNode(_sfc_main$2, {
              class: normalizeClass(_ctx.$style.tooltip),
              tooltip: "Currency symbol used when displaying money values.\n       Only shown in UI added by Refined PrUn."
            }, null, 8, ["class"])
          ]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$1, { label: "Symbol" }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: unref(currencySettings).preset,
                "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => unref(currencySettings).preset = $event),
                options: currencyPresets
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          }),
          unref(currencySettings).preset === "CUSTOM" ? (openBlock(), createBlock(_sfc_main$1, {
            key: 0,
            label: "Custom symbol"
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$3, {
                modelValue: unref(currencySettings).custom,
                "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => unref(currencySettings).custom = $event)
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          })) : createCommentVNode("", true),
          unref(currencySettings).preset !== "DEFAULT" ? (openBlock(), createBlock(_sfc_main$1, {
            key: 1,
            label: "Position"
          }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: unref(currencySettings).position,
                "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => unref(currencySettings).position = $event),
                options: currencyPosition
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          })) : createCommentVNode("", true),
          unref(currencySettings).preset !== "DEFAULT" ? (openBlock(), createBlock(_sfc_main$1, {
            key: 2,
            label: "Spacing",
            tooltip: "The space between symbol and value."
          }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: unref(currencySettings).spacing,
                "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => unref(currencySettings).spacing = $event),
                options: currencySpacing
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          })) : createCommentVNode("", true)
        ]),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[11] || (_cache[11] = [
            createTextVNode("Burn Settings", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$1, {
            label: "Red",
            tooltip: "Threshold for red consumable level in burn calculations (in days)."
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$4, {
                modelValue: unref(userData).settings.burn.red,
                "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => unref(userData).settings.burn.red = $event)
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, {
            label: "Yellow",
            tooltip: "Threshold for yellow consumable level in burn calculations (in days)."
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$4, {
                modelValue: unref(userData).settings.burn.yellow,
                "onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => unref(userData).settings.burn.yellow = $event)
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, {
            label: "Resupply",
            tooltip: "Target amount of supplied days for the 'Need' column in XIT BURN."
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$4, {
                modelValue: unref(userData).settings.burn.resupply,
                "onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => unref(userData).settings.burn.resupply = $event)
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          })
        ]),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [
            _cache[12] || (_cache[12] = createTextVNode(" Left Sidebar Buttons ", -1)),
            createVNode(_sfc_main$2, {
              class: normalizeClass(_ctx.$style.tooltip),
              tooltip: "Create hotkeys on the left sidebar.\n         The first value is what will be displayed, the second is the command."
            }, null, 8, ["class"])
          ]),
          _: 1
        }),
        withDirectives((openBlock(), createElementBlock("form", null, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(userData).settings.sidebar, (button, i) => {
            return openBlock(), createBlock(_sfc_main$1, {
              key: unref(objectId)(button),
              label: `Button ${i + 1}`,
              class: normalizeClass(_ctx.$style.sidebarRow)
            }, {
              default: withCtx(() => [
                createBaseVNode("div", {
                  class: normalizeClass(_ctx.$style.sidebarInputPair)
                }, [
                  createVNode(_sfc_main$5, {
                    class: normalizeClass([_ctx.$style.grip, unref(grip).class])
                  }, null, 8, ["class"]),
                  createVNode(_sfc_main$3, {
                    modelValue: button[0],
                    "onUpdate:modelValue": ($event) => button[0] = $event,
                    class: normalizeClass(_ctx.$style.sidebarInput)
                  }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                  createVNode(_sfc_main$3, {
                    modelValue: button[1],
                    "onUpdate:modelValue": ($event) => button[1] = $event,
                    class: normalizeClass(_ctx.$style.sidebarInput)
                  }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                  createVNode(_sfc_main$6, {
                    danger: "",
                    onClick: ($event) => deleteSidebarButton(i)
                  }, {
                    default: withCtx(() => [..._cache[13] || (_cache[13] = [
                      createTextVNode("x", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ], 2)
              ]),
              _: 2
            }, 1032, ["label", "class"]);
          }), 128))
        ])), [
          [unref(so), [unref(userData).settings.sidebar, unref(grip).draggable]]
        ]),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$7, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$6, {
                primary: "",
                onClick: confirmResetSidebar
              }, {
                default: withCtx(() => [..._cache[14] || (_cache[14] = [
                  createTextVNode("RESET", -1)
                ])]),
                _: 1
              }),
              createVNode(_sfc_main$6, {
                primary: "",
                onClick: addSidebarButton
              }, {
                default: withCtx(() => [..._cache[15] || (_cache[15] = [
                  createTextVNode("ADD NEW", -1)
                ])]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[16] || (_cache[16] = [
            createTextVNode("Import/Export", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$7, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$6, {
                primary: "",
                onClick: importUserDataAndReload
              }, {
                default: withCtx(() => [..._cache[17] || (_cache[17] = [
                  createTextVNode("Import User Data", -1)
                ])]),
                _: 1
              }),
              createVNode(_sfc_main$6, {
                primary: "",
                onClick: unref(exportUserData)
              }, {
                default: withCtx(() => [..._cache[18] || (_cache[18] = [
                  createTextVNode("Export User Data", -1)
                ])]),
                _: 1
              }, 8, ["onClick"])
            ]),
            _: 1
          })
        ]),
        unref(backups).length > 0 ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
          createVNode(SectionHeader, null, {
            default: withCtx(() => [..._cache[19] || (_cache[19] = [
              createTextVNode("Backups", -1)
            ])]),
            _: 1
          }),
          createBaseVNode("form", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(backups), (backup) => {
              return openBlock(), createBlock(_sfc_main$7, {
                key: backup.timestamp,
                label: unref(ddmmyyyy)(backup.timestamp) + " " + unref(hhmm)(backup.timestamp)
              }, {
                default: withCtx(() => [
                  createVNode(_sfc_main$6, {
                    primary: "",
                    onClick: ($event) => unref(downloadBackup)(backup.data, backup.timestamp)
                  }, {
                    default: withCtx(() => [..._cache[20] || (_cache[20] = [
                      createTextVNode(" Export ", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"]),
                  createVNode(_sfc_main$6, {
                    primary: "",
                    onClick: ($event) => restoreBackupAndReload($event, backup.data)
                  }, {
                    default: withCtx(() => [..._cache[21] || (_cache[21] = [
                      createTextVNode(" Restore ", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"]),
                  createVNode(_sfc_main$6, {
                    danger: "",
                    onClick: ($event) => confirmDeleteBackup($event, backup)
                  }, {
                    default: withCtx(() => [..._cache[22] || (_cache[22] = [
                      createTextVNode("Delete", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ]),
                _: 2
              }, 1032, ["label"]);
            }), 128))
          ])
        ], 64)) : createCommentVNode("", true),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[23] || (_cache[23] = [
            createTextVNode("Danger Zone", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$7, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$6, {
                danger: "",
                onClick: confirmResetAllData
              }, {
                default: withCtx(() => [..._cache[24] || (_cache[24] = [
                  createTextVNode("Reset All Data", -1)
                ])]),
                _: 1
              })
            ]),
            _: 1
          })
        ])
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
