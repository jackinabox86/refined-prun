import { withKeys } from "../../../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import SectionHeader from "../../../components/SectionHeader.vue.js";
import _sfc_main$6 from "../../../components/Tooltip.vue.js";
import _sfc_main$5 from "../../../components/forms/Commands.vue.js";
import _sfc_main$4 from "../../../components/PrunButton.vue.js";
import { hhmm, ddmmyyyy, fixed0 } from "../../../utils/format.js";
import { userData, clearBalanceHistory } from "../../../store/user-data.js";
import { calcEquity } from "../../../core/balance/balance-sheet-summary.js";
import { showConfirmationOverlay } from "../../../infrastructure/prun-ui/tile-overlay.js";
import { balanceHistory, collectFinDataPoint, canCollectFinDataPoint } from "../../../store/user-data-balance.js";
import _sfc_main$2 from "../../../components/forms/Active.vue.js";
import _sfc_main$3 from "../../../components/forms/TextInput.vue.js";
import { objectId } from "../../../utils/object-id.js";
import _sfc_main$1 from "../../../components/forms/RadioItem.vue.js";
import { defineComponent, computed, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FIN",
  setup(__props) {
    const sortedData = computed(() => balanceHistory.value.slice().reverse());
    function confirmDataPointDelete(ev, index) {
      index = balanceHistory.value.length - index - 1;
      showConfirmationOverlay(ev, () => deleteBalanceHistoryDataPoint(index), {
        message: `You are about to delete a historical data point. Do you want to continue?`
      });
    }
    function deleteBalanceHistoryDataPoint(index) {
      const history = userData.balanceHistory;
      if (index < history.v1.length) {
        history.v1.splice(index, 1);
      } else {
        history.v2.splice(index - history.v1.length, 1);
      }
    }
    function confirmAllDataDelete(ev) {
      showConfirmationOverlay(ev, clearBalanceHistory, {
        message: `You are about to clear all historical financial data. Do you want to continue?`
      });
    }
    function formatValue(number) {
      return number !== void 0 ? fixed0(number) : "--";
    }
    const mmMaterials = ref(userData.settings.financial.mmMaterials);
    function onMMMaterialsSubmit() {
      const formatted = (mmMaterials.value ?? "").replaceAll(" ", "").toUpperCase();
      userData.settings.financial.mmMaterials = formatted;
      mmMaterials.value = formatted;
    }
    const ignoredMaterials = ref(userData.settings.financial.ignoredMaterials);
    function onIgnoredMaterialsSubmit() {
      const formatted = (ignoredMaterials.value ?? "").replaceAll(" ", "").toUpperCase();
      userData.settings.financial.ignoredMaterials = formatted;
      ignoredMaterials.value = formatted;
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[3] || (_cache[3] = [
            createTextVNode("Equity Mode", -1)
          ])]),
          _: 1
        }),
        createVNode(_sfc_main$2, {
          label: "Equity Mode",
          tooltip: "In this mode, equity includes the market value of all assets,\n     including ships, HQ upgrades, and ARC. Not recommended for beginners,\n     as starter ships have a disproportionate value compared to starting resources.\n     Note that even with this mode disabled, your financial data history is still\n     collected in full, so you can always switch to full equity mode later.",
          "tooltip-position": "bottom"
        }, {
          default: withCtx(() => [
            createVNode(_sfc_main$1, {
              modelValue: unref(userData).fullEquityMode,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => unref(userData).fullEquityMode = $event)
            }, {
              default: withCtx(() => [..._cache[4] || (_cache[4] = [
                createTextVNode("full equity", -1)
              ])]),
              _: 1
            }, 8, ["modelValue"])
          ]),
          _: 1
        }),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[5] || (_cache[5] = [
            createTextVNode("Price Settings", -1)
          ])]),
          _: 1
        }),
        createVNode(_sfc_main$2, {
          label: "MM Materials",
          tooltip: "Comma-separated list of Market Maker materials.\n     The price of these materials will be equal to MM Bid price."
        }, {
          default: withCtx(() => [
            createVNode(_sfc_main$3, {
              modelValue: unref(mmMaterials),
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(mmMaterials) ? mmMaterials.value = $event : null),
              onKeyup: withKeys(onMMMaterialsSubmit, ["enter"]),
              onFocusout: onMMMaterialsSubmit
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$2, {
          label: "Ignored Materials",
          tooltip: "Comma-separated list of ignored materials.\n     The price of these materials is considered to be zero."
        }, {
          default: withCtx(() => [
            createVNode(_sfc_main$3, {
              modelValue: unref(ignoredMaterials),
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(ignoredMaterials) ? ignoredMaterials.value = $event : null),
              onKeyup: withKeys(onIgnoredMaterialsSubmit, ["enter"]),
              onFocusout: onIgnoredMaterialsSubmit
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[6] || (_cache[6] = [
            createTextVNode("Collected Data Points", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$5, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$4, {
                primary: "",
                disabled: !unref(canCollectFinDataPoint)(),
                onClick: unref(collectFinDataPoint)
              }, {
                default: withCtx(() => [..._cache[7] || (_cache[7] = [
                  createTextVNode(" Collect Data Point ", -1)
                ])]),
                _: 1
              }, 8, ["disabled", "onClick"])
            ]),
            _: 1
          })
        ]),
        createBaseVNode("table", null, [
          _cache[9] || (_cache[9] = createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", null, "Date"),
              createBaseVNode("th", null, "Equity"),
              createBaseVNode("th", null, "Command")
            ])
          ], -1)),
          createBaseVNode("tbody", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(sortedData), (balance, i) => {
              return openBlock(), createElementBlock("tr", {
                key: unref(objectId)(balance)
              }, [
                createBaseVNode("td", null, toDisplayString(unref(hhmm)(balance.timestamp)) + " " + toDisplayString(unref(ddmmyyyy)(balance.timestamp)), 1),
                createBaseVNode("td", null, toDisplayString(formatValue(unref(calcEquity)(balance))), 1),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$4, {
                    dark: "",
                    inline: "",
                    onClick: ($event) => confirmDataPointDelete($event, i)
                  }, {
                    default: withCtx(() => [..._cache[8] || (_cache[8] = [
                      createTextVNode("delete", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ])
              ]);
            }), 128))
          ])
        ]),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [
            _cache[10] || (_cache[10] = createTextVNode(" Danger Zone ", -1)),
            createVNode(_sfc_main$6, {
              class: normalizeClass(_ctx.$style.tooltip),
              tooltip: "Clear all historical financial data"
            }, null, 8, ["class"])
          ]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$5, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$4, {
                danger: "",
                onClick: confirmAllDataDelete
              }, {
                default: withCtx(() => [..._cache[11] || (_cache[11] = [
                  createTextVNode("Clear Financial Data", -1)
                ])]),
                _: 1
              })
            ]),
            _: 1
          })
        ])
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
