import { useXitParameters } from "../../../hooks/use-xit-parameters.js";
import _sfc_main$1 from "../../../components/Tabs.vue.js";
import GAME from "./GAME.vue.js";
import FEAT from "./FEAT.vue.js";
import FIN from "./FIN.vue.js";
import BFR from "./BFR.vue.js";
import { defineComponent, openBlock, createBlock } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { shallowRef, isRef, unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "SET",
  setup(__props) {
    const tabs = [
      {
        id: "GAME",
        label: "Gameplay",
        component: GAME
      },
      {
        id: "FEAT",
        label: "Features",
        component: FEAT
      },
      {
        id: "FIN",
        label: "Financial",
        component: FIN
      },
      {
        id: "BFR",
        label: "Buffers",
        component: BFR
      }
    ];
    const parameters = useXitParameters();
    const parameter = parameters[0];
    const activeTab = shallowRef(tabs.find((x) => x.id === parameter?.toUpperCase()) ?? tabs[0]);
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$1, {
        modelValue: unref(activeTab),
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(activeTab) ? activeTab.value = $event : null),
        tabs
      }, null, 8, ["modelValue"]);
    };
  }
});
export {
  _sfc_main as default
};
