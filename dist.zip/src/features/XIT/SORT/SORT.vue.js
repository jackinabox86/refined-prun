import { storagesStore } from "../../../infrastructure/prun-api/data/storage.js";
import _sfc_main$3 from "../../../components/CopyButton.vue.js";
import _sfc_main$1 from "../../../components/PrunButton.vue.js";
import _sfc_main$2 from "../../../components/ActionBar.vue.js";
import { showTileOverlay, showConfirmationOverlay } from "../../../infrastructure/prun-ui/tile-overlay.js";
import _sfc_main$4 from "./SortingModeEditor.vue.js";
import { useXitParameters } from "../../../hooks/use-xit-parameters.js";
import { objectId } from "../../../utils/object-id.js";
import { getSortingData } from "../../../store/user-data-sorting.js";
import removeArrayElement from "../../../utils/remove-array-element.js";
import { vDraggable as so } from "../../../../npm/vue-draggable-plus@0.6.0_@types+sortablejs@1.15.8-vue-draggable-plus-vue-draggable-plus.js";
import { grip } from "../../../components/grip/index.js";
import GripCell from "../../../components/grip/GripCell.vue.js";
import GripHeaderCell from "../../../components/grip/GripHeaderCell.vue.js";
import { isEmpty } from "../../../../npm/ts-extras@0.15.0-ts-extras-is-empty.js";
import { defineComponent, computed, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, withDirectives, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _hoisted_2 = { key: 0 };
const _hoisted_3 = { key: 1 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "SORT",
  setup(__props) {
    const parameters = useXitParameters();
    const storeId = parameters[0];
    const storage = computed(() => storagesStore.getById(storeId));
    const sortingData = computed(() => getSortingData(storeId));
    function createSortingMode(ev) {
      showTileOverlay(ev, _sfc_main$4, {
        storeId,
        onSave: (sorting) => sortingData.value.modes.push(sorting)
      });
    }
    function editSortingMode(ev, sorting) {
      showTileOverlay(ev, _sfc_main$4, {
        storeId,
        sorting,
        onSave: (saved) => Object.assign(sorting, saved)
      });
    }
    function deleteSortingMode(ev, sorting) {
      showConfirmationOverlay(
        ev,
        () => {
          removeArrayElement(sortingData.value.modes, sorting);
        },
        {
          message: `Are you sure you want to delete ${sorting.label}?`
        }
      );
    }
    function copySortingMode(sorting) {
      return JSON.stringify(sorting);
    }
    async function pasteSortingMode(ev) {
      const clipText = await navigator.clipboard.readText();
      const sorting = JSON.parse(clipText);
      showTileOverlay(ev, _sfc_main$4, {
        storeId,
        sorting,
        onSave: (sorting2) => sortingData.value.modes.push(sorting2)
      });
    }
    return (_ctx, _cache) => {
      return !unref(storage) ? (openBlock(), createElementBlock("div", _hoisted_1, "Invalid inventory ID")) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
        createVNode(_sfc_main$2, null, {
          default: withCtx(() => [
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: createSortingMode
            }, {
              default: withCtx(() => [..._cache[0] || (_cache[0] = [
                createTextVNode("CREATE NEW", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: pasteSortingMode
            }, {
              default: withCtx(() => [..._cache[1] || (_cache[1] = [
                createTextVNode("PASTE", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        }),
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createVNode(GripHeaderCell),
              _cache[2] || (_cache[2] = createBaseVNode("th", null, "Name", -1)),
              _cache[3] || (_cache[3] = createBaseVNode("th", null, "Categories", -1)),
              _cache[4] || (_cache[4] = createBaseVNode("th", null, null, -1))
            ])
          ]),
          !unref(isEmpty)(unref(sortingData).modes) ? withDirectives((openBlock(), createElementBlock("tbody", _hoisted_2, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(sortingData).modes, (mode) => {
              return openBlock(), createElementBlock("tr", {
                key: unref(objectId)(mode)
              }, [
                createVNode(GripCell),
                createBaseVNode("td", null, toDisplayString(mode.label), 1),
                createBaseVNode("td", null, toDisplayString(mode.categories.map((x) => x.name).join(", ")), 1),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$1, {
                    primary: "",
                    onClick: ($event) => editSortingMode($event, mode)
                  }, {
                    default: withCtx(() => [..._cache[5] || (_cache[5] = [
                      createTextVNode("edit", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"]),
                  createVNode(_sfc_main$3, {
                    "copy-fn": () => copySortingMode(mode)
                  }, null, 8, ["copy-fn"]),
                  createVNode(_sfc_main$1, {
                    danger: "",
                    onClick: ($event) => deleteSortingMode($event, mode)
                  }, {
                    default: withCtx(() => [..._cache[6] || (_cache[6] = [
                      createTextVNode("delete", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ])
              ]);
            }), 128))
          ])), [
            [unref(so), [unref(sortingData).modes, unref(grip).draggable]]
          ]) : (openBlock(), createElementBlock("tbody", _hoisted_3, [..._cache[7] || (_cache[7] = [
            createBaseVNode("tr", null, [
              createBaseVNode("td", { colspan: "3" }, "No Sorting Options")
            ], -1)
          ])]))
        ])
      ], 64));
    };
  }
});
export {
  _sfc_main as default
};
