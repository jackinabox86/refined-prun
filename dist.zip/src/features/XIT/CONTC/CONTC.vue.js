import { selfCurrentConditions, selfNonCurrentConditions } from "../../../core/balance/contract-conditions.js";
import { contractsStore } from "../../../infrastructure/prun-api/data/contracts.js";
import LoadingSpinner from "../../../components/LoadingSpinner.vue.js";
import _sfc_main$1 from "./ConditionRow.vue.js";
import { isEmpty } from "../../../../npm/ts-extras@0.15.0-ts-extras-is-empty.js";
import { defineComponent, computed, openBlock, createBlock, createElementBlock, createElementVNode as createBaseVNode, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = { key: 1 };
const _hoisted_2 = { key: 0 };
const _hoisted_3 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CONTC",
  setup(__props) {
    const current = computed(
      () => selfCurrentConditions.value.filter((x) => x.dependencies.every((x2) => x2.status === "FULFILLED"))
    );
    const nonCurrent = computed(
      () => selfNonCurrentConditions.value.filter((x) => x.dependencies.every((x2) => x2.status === "FULFILLED"))
    );
    return (_ctx, _cache) => {
      return !unref(contractsStore).fetched ? (openBlock(), createBlock(LoadingSpinner, { key: 0 })) : (openBlock(), createElementBlock("table", _hoisted_1, [
        _cache[2] || (_cache[2] = createBaseVNode("thead", null, [
          createBaseVNode("tr", null, [
            createBaseVNode("th", null, "Contract"),
            createBaseVNode("th", null, "Deadline"),
            createBaseVNode("th", null, "Condition")
          ])
        ], -1)),
        _cache[3] || (_cache[3] = createBaseVNode("thead", null, [
          createBaseVNode("tr", null, [
            createBaseVNode("th", { colspan: "3" }, "Current Conditions")
          ])
        ], -1)),
        createBaseVNode("tbody", null, [
          unref(isEmpty)(unref(current)) ? (openBlock(), createElementBlock("tr", _hoisted_2, [..._cache[0] || (_cache[0] = [
            createBaseVNode("td", { colspan: "3" }, "No pending conditions", -1)
          ])])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(unref(current), (x) => {
            return openBlock(), createBlock(_sfc_main$1, {
              key: x.condition.id,
              contract: x.contract,
              condition: x.condition,
              deadline: x.deadline
            }, null, 8, ["contract", "condition", "deadline"]);
          }), 128))
        ]),
        _cache[4] || (_cache[4] = createBaseVNode("thead", null, [
          createBaseVNode("tr", null, [
            createBaseVNode("th", { colspan: "3" }, "Non-Current Conditions")
          ])
        ], -1)),
        createBaseVNode("tbody", null, [
          unref(isEmpty)(unref(nonCurrent)) ? (openBlock(), createElementBlock("tr", _hoisted_3, [..._cache[1] || (_cache[1] = [
            createBaseVNode("td", { colspan: "3" }, "No pending conditions", -1)
          ])])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(unref(nonCurrent), (x) => {
            return openBlock(), createBlock(_sfc_main$1, {
              key: x.condition.id,
              contract: x.contract,
              condition: x.condition,
              deadline: x.deadline
            }, null, 8, ["contract", "condition", "deadline"]);
          }), 128))
        ])
      ]));
    };
  }
});
export {
  _sfc_main as default
};
