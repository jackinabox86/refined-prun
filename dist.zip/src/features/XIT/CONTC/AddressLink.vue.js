import PrunLink from "../../../components/PrunLink.vue.js";
import { isPlanetLine } from "../../../infrastructure/prun-api/data/addresses.js";
import { defineComponent, computed, openBlock, createBlock, withCtx, createTextVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "AddressLink",
  props: {
    address: {}
  },
  setup(__props) {
    const body = computed(() => __props.address.lines[1]);
    const isPlanet = computed(() => isPlanetLine(body.value));
    const naturalId = computed(() => body.value.entity?.naturalId);
    const name = computed(() => body.value.entity?.name);
    return (_ctx, _cache) => {
      return unref(isPlanet) ? (openBlock(), createBlock(PrunLink, {
        key: 0,
        inline: "",
        command: `PLI ${unref(naturalId)}`
      }, {
        default: withCtx(() => [
          createTextVNode(toDisplayString(unref(name)), 1)
        ]),
        _: 1
      }, 8, ["command"])) : (openBlock(), createBlock(PrunLink, {
        key: 1,
        inline: "",
        command: `STNS ${unref(naturalId)}`
      }, {
        default: withCtx(() => [
          createTextVNode(toDisplayString(unref(name)), 1)
        ]),
        _: 1
      }, 8, ["command"]));
    };
  }
});
export {
  _sfc_main as default
};
