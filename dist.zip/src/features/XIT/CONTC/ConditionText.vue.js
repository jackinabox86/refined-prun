import { fixed02 } from "../../../utils/format.js";
import _sfc_main$1 from "./AddressLink.vue.js";
import PrunLink from "../../../components/PrunLink.vue.js";
import { defineComponent, openBlock, createElementBlock, Fragment, createTextVNode, createVNode, withCtx } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ConditionText",
  props: {
    condition: {}
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return _ctx.condition.type === "BASE_CONSTRUCTION" ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
        createTextVNode("Construct Base")
      ], 64)) : _ctx.condition.type === "COMEX_PURCHASE_PICKUP" ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [
        createTextVNode(" Pick up " + toDisplayString(_ctx.condition.quantity.amount - _ctx.condition.pickedUp.amount) + " " + toDisplayString(_ctx.condition.quantity.material.ticker) + " @ ", 1),
        createVNode(_sfc_main$1, {
          address: _ctx.condition.address
        }, null, 8, ["address"])
      ], 64)) : _ctx.condition.type === "CONSTRUCT_SHIP" ? (openBlock(), createElementBlock(Fragment, { key: 2 }, [
        createTextVNode("Construct Ship")
      ], 64)) : _ctx.condition.type === "CONTRIBUTION" ? (openBlock(), createElementBlock(Fragment, { key: 3 }, [
        createTextVNode("Contribution")
      ], 64)) : _ctx.condition.type === "DELIVERY" ? (openBlock(), createElementBlock(Fragment, { key: 4 }, [
        createTextVNode(" Deliver " + toDisplayString(_ctx.condition.quantity.amount) + " " + toDisplayString(_ctx.condition.quantity.material.ticker) + " @ ", 1),
        createVNode(_sfc_main$1, {
          address: _ctx.condition.address
        }, null, 8, ["address"])
      ], 64)) : _ctx.condition.type === "DELIVERY_SHIPMENT" ? (openBlock(), createElementBlock(Fragment, { key: 5 }, [
        _cache[0] || (_cache[0] = createTextVNode(" Deliver SHPT @ ", -1)),
        createVNode(_sfc_main$1, {
          address: _ctx.condition.destination
        }, null, 8, ["address"])
      ], 64)) : _ctx.condition.type === "EXPLORATION" ? (openBlock(), createElementBlock(Fragment, { key: 6 }, [
        _cache[1] || (_cache[1] = createTextVNode(" Explore ", -1)),
        createVNode(_sfc_main$1, {
          address: _ctx.condition.address
        }, null, 8, ["address"])
      ], 64)) : _ctx.condition.type === "FINISH_FLIGHT" ? (openBlock(), createElementBlock(Fragment, { key: 7 }, [
        createTextVNode("Finish Flight")
      ], 64)) : _ctx.condition.type === "GATEWAY_FUEL" ? (openBlock(), createElementBlock(Fragment, { key: 8 }, [
        _cache[2] || (_cache[2] = createTextVNode(" Refuel ", -1)),
        createVNode(PrunLink, {
          inline: "",
          command: `GTW ${_ctx.condition.gatewayId?.naturalId}`
        }, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(_ctx.condition.gatewayId?.name), 1)
          ]),
          _: 1
        }, 8, ["command"])
      ], 64)) : _ctx.condition.type === "HEADQUARTERS_UPGRADE" ? (openBlock(), createElementBlock(Fragment, { key: 9 }, [
        createTextVNode("Upgrade HQ")
      ], 64)) : _ctx.condition.type === "INFRASTRUCTURE_CONSTRUCTION_FINISH" ? (openBlock(), createElementBlock(Fragment, { key: 10 }, [
        createTextVNode(" Finish Building Infrastructure ")
      ], 64)) : _ctx.condition.type === "INFRASTRUCTURE_CONSTRUCTION_START" ? (openBlock(), createElementBlock(Fragment, { key: 11 }, [
        createTextVNode(" Start Building Infrastructure ")
      ], 64)) : _ctx.condition.type === "INFRASTRUCTURE_UPGRADE_FINISH" ? (openBlock(), createElementBlock(Fragment, { key: 12 }, [
        createTextVNode(" Finish Upgrading Infrastructure ")
      ], 64)) : _ctx.condition.type === "INFRASTRUCTURE_UPGRADE_START" ? (openBlock(), createElementBlock(Fragment, { key: 13 }, [
        createTextVNode(" Start Upgrading Infrastructure ")
      ], 64)) : _ctx.condition.type === "INFRASTRUCTURE_UPKEEP" ? (openBlock(), createElementBlock(Fragment, { key: 14 }, [
        _cache[3] || (_cache[3] = createTextVNode(" Upkeep ", -1)),
        createVNode(PrunLink, {
          inline: "",
          command: `INFU ${_ctx.condition.infrastructureId?.naturalId}`
        }, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(_ctx.condition.infrastructureId?.name), 1)
          ]),
          _: 1
        }, 8, ["command"])
      ], 64)) : _ctx.condition.type === "LOAN_INSTALLMENT" ? (openBlock(), createElementBlock(Fragment, { key: 15 }, [
        createTextVNode(" Pay " + toDisplayString(unref(fixed02)(_ctx.condition.repayment.amount + _ctx.condition.interest.amount)) + " " + toDisplayString(_ctx.condition.repayment.currency) + " (auto) ", 1)
      ], 64)) : _ctx.condition.type === "LOAN_PAYOUT" ? (openBlock(), createElementBlock(Fragment, { key: 16 }, [
        createTextVNode(" Pay " + toDisplayString(unref(fixed02)(_ctx.condition.amount.amount)) + " " + toDisplayString(_ctx.condition.amount.currency), 1)
      ], 64)) : _ctx.condition.type === "PAYMENT" ? (openBlock(), createElementBlock(Fragment, { key: 17 }, [
        createTextVNode(" Pay " + toDisplayString(unref(fixed02)(_ctx.condition.amount.amount)) + " " + toDisplayString(_ctx.condition.amount.currency), 1)
      ], 64)) : _ctx.condition.type === "PICKUP" ? (openBlock(), createElementBlock(Fragment, { key: 18 }, [
        createTextVNode("Pickup")
      ], 64)) : _ctx.condition.type === "PICKUP_SHIPMENT" ? (openBlock(), createElementBlock(Fragment, { key: 19 }, [
        _cache[4] || (_cache[4] = createTextVNode(" Pick up SHPT @ ", -1)),
        createVNode(_sfc_main$1, {
          address: _ctx.condition.address
        }, null, 8, ["address"])
      ], 64)) : _ctx.condition.type === "PLACE_ORDER" ? (openBlock(), createElementBlock(Fragment, { key: 20 }, [
        createTextVNode("Place Order")
      ], 64)) : _ctx.condition.type === "POWER" ? (openBlock(), createElementBlock(Fragment, { key: 21 }, [
        createTextVNode("Become Governor")
      ], 64)) : _ctx.condition.type === "PRODUCTION_ORDER_COMPLETED" ? (openBlock(), createElementBlock(Fragment, { key: 22 }, [
        createTextVNode(" Complete Production Order ")
      ], 64)) : _ctx.condition.type === "PRODUCTION_RUN" ? (openBlock(), createElementBlock(Fragment, { key: 23 }, [
        createTextVNode("Run Production")
      ], 64)) : _ctx.condition.type === "PROVISION" ? (openBlock(), createElementBlock(Fragment, { key: 24 }, [
        createTextVNode(" Provision " + toDisplayString(_ctx.condition.quantity.amount) + " " + toDisplayString(_ctx.condition.quantity.material.ticker) + " @ ", 1),
        createVNode(_sfc_main$1, {
          address: _ctx.condition.address
        }, null, 8, ["address"])
      ], 64)) : _ctx.condition.type === "PROVISION_SHIPMENT" ? (openBlock(), createElementBlock(Fragment, { key: 25 }, [
        createTextVNode(" Provision " + toDisplayString(_ctx.condition.quantity.amount) + " " + toDisplayString(_ctx.condition.quantity.material.ticker) + " @ ", 1),
        createVNode(_sfc_main$1, {
          address: _ctx.condition.address
        }, null, 8, ["address"])
      ], 64)) : _ctx.condition.type === "REPAIR_SHIP" ? (openBlock(), createElementBlock(Fragment, { key: 26 }, [
        createTextVNode("Repair Ship")
      ], 64)) : _ctx.condition.type === "START_FLIGHT" ? (openBlock(), createElementBlock(Fragment, { key: 27 }, [
        createTextVNode("Start Flight")
      ], 64)) : _ctx.condition.type === "WORKFORCE_PROGRAM_PAYMENT" ? (openBlock(), createElementBlock(Fragment, { key: 28 }, [
        createTextVNode(" Pay " + toDisplayString(unref(fixed02)(_ctx.condition.amount.amount)) + " " + toDisplayString(_ctx.condition.amount.currency), 1)
      ], 64)) : (openBlock(), createElementBlock(Fragment, { key: 29 }, [
        createTextVNode(toDisplayString(_ctx.condition.type), 1)
      ], 64));
    };
  }
});
export {
  _sfc_main as default
};
