import PrunLink from "../../../components/PrunLink.vue.js";
import { isFactionContract } from "../CONTS/utils.js";
import { defineComponent, computed, openBlock, createBlock, withCtx, createTextVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeStyle, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ContractLink",
  props: {
    contract: {}
  },
  setup(__props) {
    const linkStyle = computed(() => ({
      display: isFactionContract(__props.contract) ? "inline" : "block"
    }));
    return (_ctx, _cache) => {
      return openBlock(), createBlock(PrunLink, {
        command: `CONT ${_ctx.contract.localId}`,
        style: normalizeStyle(unref(linkStyle))
      }, {
        default: withCtx(() => [
          createTextVNode(toDisplayString(_ctx.contract.name || _ctx.contract.localId), 1)
        ]),
        _: 1
      }, 8, ["command", "style"]);
    };
  }
});
export {
  _sfc_main as default
};
