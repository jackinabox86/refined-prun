import _sfc_main from "./ProductionList.vue.js";
export {
  _sfc_main as default
};
