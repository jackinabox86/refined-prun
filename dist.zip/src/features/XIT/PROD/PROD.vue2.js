import { sumBy } from "../../../utils/sum-by.js";
import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import _sfc_main$1 from "../../../components/forms/RadioItem.vue.js";
import { getPlanetProduction } from "../../../core/production.js";
import _sfc_main$2 from "./ProdSection.vue.js";
import { useTileState } from "./tile-state.js";
import { useXitParameters } from "../../../hooks/use-xit-parameters.js";
import { sitesStore } from "../../../infrastructure/prun-api/data/sites.js";
import { findWithQuery } from "../../../utils/find-with-query.js";
import { convertToPlanetNaturalId } from "../../../core/planet-natural-id.js";
import { matchesProductionFilter } from "./utils.js";
import FakeRow from "./FakeRow.vue.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, createCommentVNode, Fragment, renderList, createBlock } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { isRef, unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _hoisted_2 = { key: 1 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "PROD",
  setup(__props) {
    const parameters = useXitParameters();
    function findSites(term, parts) {
      if (term === "all") {
        return sitesStore.all.value;
      }
      const naturalId = convertToPlanetNaturalId(term, parts);
      return sitesStore.getByPlanetNaturalId(naturalId);
    }
    function byTotalCapacityDesc(a, b) {
      return sumBy(b.production, (x) => x.capacity) - sumBy(a.production, (x) => x.capacity);
    }
    const displayProduction = useTileState("production");
    const queue = useTileState("queue");
    const inactive = useTileState("inactive");
    const notQueued = useTileState("notQueued");
    const headers = useTileState("headers");
    const expand = useTileState("expandPlanets");
    const planetProduction = computed(() => {
      let sites = findWithQuery(parameters, findSites).include;
      if (sites.length === 0) {
        sites = sitesStore.all.value ?? [];
      }
      return sites.map(getPlanetProduction).filter((x) => x !== void 0).sort(byTotalCapacityDesc).filter(
        (x) => matchesProductionFilter(x.production, {
          production: displayProduction.value,
          inactive: inactive.value,
          queue: queue.value,
          notQueued: notQueued.value
        })
      );
    });
    const anyExpanded = computed(() => expand.value.length > 0);
    function onExpandAllClick() {
      if (expand.value.length > 0) {
        expand.value = [];
      } else {
        expand.value = planetProduction.value?.map((x) => x.naturalId) ?? [];
      }
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", {
          class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).ComExOrdersPanel.filter)
        }, [
          createVNode(_sfc_main$1, {
            modelValue: unref(headers),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(headers) ? headers.value = $event : null),
            horizontal: ""
          }, {
            default: withCtx(() => [..._cache[5] || (_cache[5] = [
              createTextVNode("Headers", -1)
            ])]),
            _: 1
          }, 8, ["modelValue"]),
          createVNode(_sfc_main$1, {
            modelValue: unref(displayProduction),
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(displayProduction) ? displayProduction.value = $event : null),
            horizontal: ""
          }, {
            default: withCtx(() => [..._cache[6] || (_cache[6] = [
              createTextVNode("Production", -1)
            ])]),
            _: 1
          }, 8, ["modelValue"]),
          createVNode(_sfc_main$1, {
            modelValue: unref(inactive),
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(inactive) ? inactive.value = $event : null),
            horizontal: ""
          }, {
            default: withCtx(() => [..._cache[7] || (_cache[7] = [
              createTextVNode("Inactive", -1)
            ])]),
            _: 1
          }, 8, ["modelValue"]),
          createVNode(_sfc_main$1, {
            modelValue: unref(queue),
            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(queue) ? queue.value = $event : null),
            horizontal: ""
          }, {
            default: withCtx(() => [..._cache[8] || (_cache[8] = [
              createTextVNode("Queue", -1)
            ])]),
            _: 1
          }, 8, ["modelValue"]),
          createVNode(_sfc_main$1, {
            modelValue: unref(notQueued),
            "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => isRef(notQueued) ? notQueued.value = $event : null),
            horizontal: ""
          }, {
            default: withCtx(() => [..._cache[9] || (_cache[9] = [
              createTextVNode("Not Queued", -1)
            ])]),
            _: 1
          }, 8, ["modelValue"])
        ], 2),
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            unref(headers) ? (openBlock(), createElementBlock("tr", _hoisted_1, [
              unref(planetProduction).length > 1 ? (openBlock(), createElementBlock("th", {
                key: 0,
                class: normalizeClass(_ctx.$style.expand),
                onClick: onExpandAllClick
              }, toDisplayString(unref(anyExpanded) ? "-" : "+"), 3)) : (openBlock(), createElementBlock("th", _hoisted_2)),
              _cache[10] || (_cache[10] = createBaseVNode("th", null, "Planet", -1)),
              _cache[11] || (_cache[11] = createBaseVNode("th", null, "Efficiency", -1)),
              _cache[12] || (_cache[12] = createBaseVNode("th", null, "Slots", -1)),
              _cache[13] || (_cache[13] = createBaseVNode("th", null, "CMD", -1))
            ])) : createCommentVNode("", true)
          ]),
          createVNode(FakeRow),
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(planetProduction), (production) => {
            return openBlock(), createBlock(_sfc_main$2, {
              key: production.site.siteId,
              "can-minimize": unref(planetProduction).length > 1,
              production,
              headers: unref(headers)
            }, null, 8, ["can-minimize", "production", "headers"]);
          }), 128))
        ])
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
