import { createTileStateHook } from "../../../store/user-data-tiles.js";
const useTileState = createTileStateHook({
  production: true,
  queue: true,
  inactive: true,
  notQueued: true,
  headers: true,
  expandPlanets: [],
  expandInfo: []
});
export {
  useTileState
};
