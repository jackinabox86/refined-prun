import { useTileState } from "./tile-state.js";
import _sfc_main$1 from "./ProductionList.vue.js";
import PlanetHeader from "./PlanetHeader.vue.js";
import { defineComponent, computed, openBlock, createElementBlock, Fragment, createElementVNode as createBaseVNode, createVNode, createCommentVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ProdSection",
  props: {
    production: {},
    canMinimize: { type: Boolean },
    headers: { type: Boolean }
  },
  setup(__props) {
    const expand = useTileState("expandPlanets");
    const naturalId = computed(() => __props.production.naturalId);
    const isMinimized = computed(() => __props.canMinimize && !expand.value.includes(naturalId.value));
    const onHeaderClick = () => {
      if (!__props.canMinimize) {
        return;
      }
      if (isMinimized.value) {
        expand.value = [...expand.value, naturalId.value];
      } else {
        expand.value = expand.value.filter((x) => x !== naturalId.value);
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("tbody", null, [
          createVNode(PlanetHeader, {
            "has-minimize": _ctx.canMinimize,
            production: _ctx.production,
            minimized: unref(isMinimized),
            "on-click": onHeaderClick
          }, null, 8, ["has-minimize", "production", "minimized"])
        ]),
        !unref(isMinimized) ? (openBlock(), createElementBlock("tbody", _hoisted_1, [
          createVNode(_sfc_main$1, {
            production: _ctx.production,
            headers: _ctx.headers
          }, null, 8, ["production", "headers"])
        ])) : createCommentVNode("", true)
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
