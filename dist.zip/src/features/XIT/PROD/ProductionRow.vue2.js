import { useTileState } from "./tile-state.js";
import _sfc_main$2 from "../../../components/PrunButton.vue.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import BuildingIcon from "../../../components/BuildingIcon.vue.js";
import { percent0, percent2 } from "../../../utils/format.js";
import FracCell from "./FracCell.vue.js";
import InlineFlex from "../../../components/InlineFlex.vue.js";
import _sfc_main$1 from "../../../components/Tooltip.vue.js";
import ProductionOrdersTable from "./ProductionOrdersTable.vue.js";
import IconCell from "./IconCell.vue.js";
import { defineComponent, computed, openBlock, createElementBlock, Fragment, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, createCommentVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ProductionRow",
  props: {
    productionLine: {},
    headers: { type: Boolean }
  },
  setup(__props) {
    const capacity = computed(() => __props.productionLine.capacity);
    const efficiency = computed(() => __props.productionLine.efficiency ?? 0);
    const activeOrders = computed(() => __props.productionLine.orders.length);
    const condition = computed(() => __props.productionLine.condition);
    const expandInfo = useTileState("expandInfo");
    const id = computed(() => __props.productionLine.id);
    const displayInfo = computed(() => expandInfo.value.includes(id.value));
    const onHeaderClick = () => {
      if (displayInfo.value) {
        expandInfo.value = expandInfo.value.filter((x) => x !== id.value);
      } else {
        expandInfo.value = [...expandInfo.value, id.value];
      }
    };
    const labels = {
      COGC_PROGRAM: "CoGC",
      COMPANY_HEADQUARTERS: "HQ",
      PRODUCTION_LINE_CONDITION: "Condition"
    };
    const capitalize = (str) => {
      return str.split("_").map((x) => x.charAt(0).toUpperCase() + x.slice(1).toLowerCase()).join(" ");
    };
    const tooltipLines = computed(() => {
      const lines = [`Condition: ${percent0(condition.value)}`];
      if (__props.productionLine.efficiencyFactors.length === 0) {
        return lines;
      }
      for (const factor of __props.productionLine.efficiencyFactors) {
        const label = labels[factor.type] ?? capitalize(factor.type);
        const category = factor.expertiseCategory ? ` (${capitalize(factor.expertiseCategory)})` : "";
        lines.push(`${label}${category}: ${percent2(factor.value)}`);
      }
      return lines;
    });
    const tooltipText = computed(() => tooltipLines.value.join("\n"));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("tr", {
          class: normalizeClass(_ctx.$style.row)
        }, [
          createVNode(IconCell, null, {
            default: withCtx(() => [
              createVNode(BuildingIcon, {
                size: "inline-table",
                ticker: _ctx.productionLine.reactorTicker
              }, null, 8, ["ticker"])
            ]),
            _: 1
          }),
          createBaseVNode("td", {
            class: normalizeClass(_ctx.$style.trigger),
            onClick: onHeaderClick
          }, [
            createBaseVNode("span", {
              class: normalizeClass([_ctx.$style.caret, unref(displayInfo) && _ctx.$style.expanded])
            }, "▶", 2),
            createBaseVNode("span", {
              class: normalizeClass(_ctx.$style.collapseText)
            }, "INFO", 2)
          ], 2),
          createBaseVNode("td", null, [
            createVNode(InlineFlex, null, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(unref(percent0)(unref(efficiency))) + " ", 1),
                createVNode(_sfc_main$1, {
                  position: "bottom",
                  tooltip: unref(tooltipText),
                  class: normalizeClass(_ctx.$style.multilineTooltip)
                }, null, 8, ["tooltip", "class"])
              ]),
              _: 1
            })
          ]),
          createVNode(FracCell, {
            numerator: unref(activeOrders),
            denominator: unref(capacity)
          }, null, 8, ["numerator", "denominator"]),
          createBaseVNode("td", null, [
            createBaseVNode("div", {
              class: normalizeClass(_ctx.$style.buttons)
            }, [
              createVNode(_sfc_main$2, {
                dark: "",
                inline: "",
                onClick: _cache[0] || (_cache[0] = ($event) => unref(showBuffer)(`PRODCO ${_ctx.productionLine.id}`))
              }, {
                default: withCtx(() => [..._cache[2] || (_cache[2] = [
                  createTextVNode("CO", -1)
                ])]),
                _: 1
              }),
              createVNode(_sfc_main$2, {
                dark: "",
                inline: "",
                onClick: _cache[1] || (_cache[1] = ($event) => unref(showBuffer)(`PRODQ ${_ctx.productionLine.id}`))
              }, {
                default: withCtx(() => [..._cache[3] || (_cache[3] = [
                  createTextVNode("Q", -1)
                ])]),
                _: 1
              })
            ], 2)
          ])
        ], 2),
        unref(displayInfo) ? (openBlock(), createElementBlock("tr", _hoisted_1, [
          _cache[4] || (_cache[4] = createBaseVNode("td", null, [
            createBaseVNode("div")
          ], -1)),
          createBaseVNode("td", {
            colspan: "4",
            class: normalizeClass(_ctx.$style.ordersCell)
          }, [
            createVNode(ProductionOrdersTable, {
              "production-line": _ctx.productionLine,
              headers: _ctx.headers
            }, null, 8, ["production-line", "headers"])
          ], 2)
        ])) : createCommentVNode("", true)
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
