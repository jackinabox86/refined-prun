import { sumBy } from "../../../utils/sum-by.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import _sfc_main$1 from "../../../components/PrunButton.vue.js";
import FracCell from "./FracCell.vue.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, createCommentVNode, createVNode, withCtx, createTextVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "PlanetHeader",
  props: {
    production: {},
    hasMinimize: { type: Boolean },
    minimized: { type: Boolean },
    onClick: { type: Function }
  },
  setup(__props) {
    const totalOrders = computed(() => sumBy(__props.production.production, (x) => x.orders.length));
    const totalCapacity = computed(() => sumBy(__props.production.production, (x) => x.capacity));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("tr", {
        class: normalizeClass(_ctx.$style.row)
      }, [
        createBaseVNode("td", {
          colspan: "3",
          class: normalizeClass(_ctx.$style.cell),
          onClick: _cache[0] || (_cache[0] = //@ts-ignore
          (...args) => _ctx.onClick && _ctx.onClick(...args))
        }, [
          _ctx.hasMinimize ? (openBlock(), createElementBlock("span", {
            key: 0,
            class: normalizeClass(_ctx.$style.minimize)
          }, toDisplayString(_ctx.minimized ? "+" : "-"), 3)) : createCommentVNode("", true),
          createBaseVNode("span", null, toDisplayString(_ctx.production.planetName), 1)
        ], 2),
        createVNode(FracCell, {
          numerator: unref(totalOrders),
          denominator: unref(totalCapacity)
        }, null, 8, ["numerator", "denominator"]),
        createBaseVNode("td", null, [
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.buttons)
          }, [
            createVNode(_sfc_main$1, {
              dark: "",
              inline: "",
              onClick: _cache[1] || (_cache[1] = ($event) => unref(showBuffer)(`BS ${_ctx.production.naturalId}`))
            }, {
              default: withCtx(() => [..._cache[3] || (_cache[3] = [
                createTextVNode("BS", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              dark: "",
              inline: "",
              onClick: _cache[2] || (_cache[2] = ($event) => unref(showBuffer)(`INV ${_ctx.production.storeId.substring(0, 8)}`))
            }, {
              default: withCtx(() => [..._cache[4] || (_cache[4] = [
                createTextVNode(" INV ", -1)
              ])]),
              _: 1
            })
          ], 2)
        ])
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
