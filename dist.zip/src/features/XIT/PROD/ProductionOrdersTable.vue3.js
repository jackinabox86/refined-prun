const placeholderStatus = "rp-ProductionOrdersTable__placeholderStatus___d8b64eb";
const orderTable = "rp-ProductionOrdersTable__orderTable___e9093e2";
const headerRow = "rp-ProductionOrdersTable__headerRow___10b95a6";
const numericColumn = "rp-ProductionOrdersTable__numericColumn___74093a2";
const stackColumn = "rp-ProductionOrdersTable__stackColumn___3f62b51";
const stackCount = "rp-ProductionOrdersTable__stackCount___a305e03";
const activeStatus = "rp-ProductionOrdersTable__activeStatus___3e07df2";
const queuedStatus = "rp-ProductionOrdersTable__queuedStatus___2e17989";
const style0 = {
  placeholderStatus,
  orderTable,
  headerRow,
  numericColumn,
  stackColumn,
  stackCount,
  activeStatus,
  queuedStatus
};
export {
  activeStatus,
  style0 as default,
  headerRow,
  numericColumn,
  orderTable,
  placeholderStatus,
  queuedStatus,
  stackColumn,
  stackCount
};
