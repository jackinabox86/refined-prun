import ProductionRow from "./ProductionRow.vue.js";
import { useTileState } from "./tile-state.js";
import { matchesProductionFilter } from "./utils.js";
import { defineComponent, computed, openBlock, createElementBlock, Fragment, renderList, createBlock } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ProductionList",
  props: {
    production: {},
    headers: { type: Boolean }
  },
  setup(__props) {
    const displayProduction = useTileState("production");
    const queue = useTileState("queue");
    const inactive = useTileState("inactive");
    const notQueued = useTileState("notQueued");
    const filteredProduction = computed(() => {
      return __props.production.production.toSorted((a, b) => b.capacity - a.capacity).filter(
        (x) => matchesProductionFilter(x, {
          production: displayProduction.value,
          inactive: inactive.value,
          queue: queue.value,
          notQueued: notQueued.value
        })
      );
    });
    return (_ctx, _cache) => {
      return openBlock(true), createElementBlock(Fragment, null, renderList(unref(filteredProduction), (line) => {
        return openBlock(), createBlock(ProductionRow, {
          key: line.id,
          "production-line": line,
          headers: _ctx.headers
        }, null, 8, ["production-line", "headers"]);
      }), 128);
    };
  }
});
export {
  _sfc_main as default
};
