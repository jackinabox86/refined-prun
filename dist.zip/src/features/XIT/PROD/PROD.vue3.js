const expand = "rp-PROD__expand___f9bf235";
const style0 = {
  expand
};
export {
  style0 as default,
  expand
};
