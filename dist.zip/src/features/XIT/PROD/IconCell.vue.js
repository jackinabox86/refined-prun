import style0 from "./IconCell.vue2.js";
import _export_sfc from "../../../../virtual/plugin-vue_export-helper.js";
import { openBlock, createElementBlock, renderSlot } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = {};
function _sfc_render(_ctx, _cache) {
  return openBlock(), createElementBlock("td", {
    class: normalizeClass(_ctx.$style.iconCell)
  }, [
    renderSlot(_ctx.$slots, "default")
  ], 2);
}
const cssModules = {
  "$style": style0
};
const IconCell = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render], ["__cssModules", cssModules]]);
export {
  IconCell as default
};
