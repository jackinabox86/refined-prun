import xit from "../xit-registry.js";
import PROD from "./PROD.vue.js";
import { sitesStore } from "../../../infrastructure/prun-api/data/sites.js";
import { getEntityNameFromAddress } from "../../../infrastructure/prun-api/data/addresses.js";
xit.add({
  command: "PROD",
  name: (parameters) => {
    if (parameters[0] && !parameters[1]) {
      const site = sitesStore.getByPlanetNaturalIdOrName(parameters[0]);
      if (site) {
        const name = getEntityNameFromAddress(site.address);
        return `PRODUCTION OVERVIEW - ${name}`;
      }
    }
    return "PRODUCTION OVERVIEW";
  },
  description: "Dense cross-base production overview.",
  optionalParameters: "Planet Identifier(s), OVERALL, NOT",
  component: () => PROD
});
