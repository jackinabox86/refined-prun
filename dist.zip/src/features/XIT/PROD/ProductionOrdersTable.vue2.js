import { useCssModule } from "../../../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import MaterialIcon from "../../../components/MaterialIcon.vue.js";
import IconCell from "./IconCell.vue.js";
import { timestampEachMinute } from "../../../utils/dayjs.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, createCommentVNode, Fragment, renderList, createVNode, withCtx, createTextVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ProductionOrdersTable",
  props: {
    productionLine: {},
    headers: { type: Boolean }
  },
  setup(__props) {
    const $style = useCssModule();
    const stackedActive = computed(() => {
      const groups = {};
      const BUCKET_MS = 10 * 60 * 1e3;
      for (const order of __props.productionLine.orders) {
        const output = order.outputs[0];
        if (output === void 0) {
          continue;
        }
        const ts = order.completion ? new Date(order.completion.timestamp).getTime() : 0;
        const bucket = Math.round(ts / BUCKET_MS);
        const key = `${order.recipeId}-${bucket}`;
        groups[key] ??= { ticker: output.material.ticker, count: 0, amount: 0, ts };
        groups[key].count += 1;
        groups[key].amount += output.amount;
      }
      const results = Object.values(groups);
      if (__props.productionLine.inactiveCapacity > 0) {
        results.push({
          ticker: "N/A",
          count: __props.productionLine.inactiveCapacity,
          amount: 0,
          label: "Inactive",
          isPlaceholder: true
        });
      }
      return results;
    });
    const stackedQueued = computed(() => {
      const groups = {};
      for (const order of __props.productionLine.queuedOrders) {
        const output = order.outputs[0];
        if (output === void 0) {
          continue;
        }
        const key = order.recipeId;
        groups[key] ??= { ticker: output.material.ticker, count: 0, amount: 0 };
        groups[key].count += 1;
        groups[key].amount += output.amount;
      }
      const results = Object.values(groups);
      if (__props.productionLine.queuedOrders.length === 0) {
        results.push({
          ticker: "N/A",
          count: 0,
          amount: 0,
          label: "Not Queued",
          isPlaceholder: true
        });
      }
      return results;
    });
    const allStackedOrders = computed(() => {
      return [
        ...stackedActive.value.map((group) => ({ ...group, isQueued: false })),
        ...stackedQueued.value.map((group) => ({ ...group, isQueued: true }))
      ];
    });
    function statusClass(group) {
      if (group.isPlaceholder) {
        return $style.placeholderStatus;
      }
      return group.isQueued ? $style.queuedStatus : $style.activeStatus;
    }
    function groupKey(group, index) {
      return (group.isQueued ? "q-" : "a-") + group.ticker + (group.ts ?? index);
    }
    const hasStacks = computed(() => allStackedOrders.value.some((x) => x.count > 1));
    const formatTime = (ts) => {
      const mins = Math.max(0, Math.floor((ts - timestampEachMinute.value) / 6e4));
      if (mins === 0) {
        return "Finishing...";
      }
      return mins > 60 ? `in ${Math.floor(mins / 60)}h ${mins % 60}m` : `in ${mins}m`;
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("table", {
          class: normalizeClass(unref($style).orderTable)
        }, [
          createBaseVNode("thead", null, [
            _ctx.headers ? (openBlock(), createElementBlock("tr", {
              key: 0,
              class: normalizeClass(unref($style).headerRow)
            }, [
              _cache[0] || (_cache[0] = createBaseVNode("th", null, null, -1)),
              unref(hasStacks) ? (openBlock(), createElementBlock("th", _hoisted_1)) : createCommentVNode("", true),
              createBaseVNode("th", {
                class: normalizeClass(unref($style).numericColumn)
              }, "Qty", 2),
              createBaseVNode("th", {
                class: normalizeClass(unref($style).numericColumn)
              }, "Status / ETA", 2)
            ], 2)) : createCommentVNode("", true)
          ]),
          createBaseVNode("tbody", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(allStackedOrders), (group, index) => {
              return openBlock(), createElementBlock("tr", {
                key: groupKey(group, index)
              }, [
                createVNode(IconCell, null, {
                  default: withCtx(() => [
                    createVNode(MaterialIcon, {
                      ticker: group.ticker,
                      size: "inline-table"
                    }, null, 8, ["ticker"])
                  ]),
                  _: 2
                }, 1024),
                unref(hasStacks) ? (openBlock(), createElementBlock("td", {
                  key: 0,
                  class: normalizeClass(unref($style).stackColumn)
                }, [
                  group.count > 1 ? (openBlock(), createElementBlock("div", {
                    key: 0,
                    class: normalizeClass(unref($style).stackCount)
                  }, "x" + toDisplayString(group.count), 3)) : createCommentVNode("", true)
                ], 2)) : createCommentVNode("", true),
                createBaseVNode("td", {
                  class: normalizeClass(unref($style).numericColumn)
                }, toDisplayString(group.isPlaceholder ? "-" : group.amount), 3),
                createBaseVNode("td", {
                  class: normalizeClass([unref($style).numericColumn, statusClass(group)])
                }, [
                  group.isPlaceholder ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                    createTextVNode(toDisplayString(group.label), 1)
                  ], 64)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                    createTextVNode(toDisplayString(group.isQueued ? "Queued" : group.ts ? formatTime(group.ts) : "Error"), 1)
                  ], 64))
                ], 2)
              ]);
            }), 128))
          ])
        ], 2)
      ]);
    };
  }
});
export {
  _sfc_main as default
};
