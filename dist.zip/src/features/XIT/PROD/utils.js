import { castArray } from "../../../utils/cast-array.js";
function matchesProductionFilter(lines, filters) {
  let activeCapacity = 0;
  let inactiveCapacity = 0;
  let queuedOrders = 0;
  for (const line of castArray(lines)) {
    activeCapacity += line.activeCapacity;
    inactiveCapacity += line.inactiveCapacity;
    queuedOrders += line.queuedOrders.length;
  }
  if (activeCapacity > 0 && filters.production) {
    return true;
  }
  if (inactiveCapacity > 0 && filters.inactive) {
    return true;
  }
  if (queuedOrders > 0 && filters.queue) {
    return true;
  }
  if (queuedOrders === 0 && filters.notQueued) {
    return true;
  }
  return false;
}
export {
  matchesProductionFilter
};
