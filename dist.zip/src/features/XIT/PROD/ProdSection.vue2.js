import _sfc_main from "./ProdSection.vue.js";
export {
  _sfc_main as default
};
