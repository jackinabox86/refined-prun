const iconCell = "rp-IconCell__iconCell___939d210";
const style0 = {
  iconCell
};
export {
  style0 as default,
  iconCell
};
