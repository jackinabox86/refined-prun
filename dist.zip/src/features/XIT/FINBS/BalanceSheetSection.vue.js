import _sfc_main from "./BalanceSheetSection.vue2.js";
/* empty css                         */
import _export_sfc from "../../../../virtual/plugin-vue_export-helper.js";
const BalanceSheetSection = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-3b2b5081"]]);
export {
  BalanceSheetSection as default
};
