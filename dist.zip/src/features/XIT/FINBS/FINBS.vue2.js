import BalanceSheetSection from "./BalanceSheetSection.vue.js";
import { calcTotalDeposits, calcTotalCashAndCashEquivalents, calcTotalLoansReceivable, calcTotalBaseInventory, calcTotalInventory, calcTotalCurrentAssets, calcTotalBuildingsMarketValue, calcTotalBuildings, calcTotalShips, calcTotalLongTermReceivables, calcTotalIntangibleAssets, calcTotalNonCurrentAssets, calcTotalLoansPayable, calcTotalCurrentLiabilities, calcTotalLongTermPayables, calcTotalNonCurrentLiabilities, calcTotalAssets, calcTotalLiabilities, calcEquity } from "../../../core/balance/balance-sheet-summary.js";
import { liveBalanceSheet } from "../../../core/balance/balance-sheet-live.js";
import { ddmmyyyy } from "../../../utils/format.js";
import { lastBalance, previousBalance } from "../../../store/user-data-balance.js";
import { userData } from "../../../store/user-data.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, Fragment, createTextVNode, renderList, createVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FINBS",
  setup(__props) {
    const currentAssets = computed(() => ({
      name: "Current Assets",
      chartId: "CURRENT ASSETS",
      value: calcTotalCurrentAssets,
      children: [
        {
          name: "Cash and Cash Equivalents",
          chartId: "CA CASH EQUIVALENTS",
          value: calcTotalCashAndCashEquivalents,
          children: [
            {
              name: "Cash",
              chartId: "CA CASH",
              value: (x) => x.assets?.current?.cashAndCashEquivalents?.cash
            },
            {
              name: "Deposits",
              chartId: "CA DEPOSITS",
              value: calcTotalDeposits,
              children: [
                {
                  name: "CX",
                  chartId: "CA DEPOSITS CX",
                  value: (x) => x.assets?.current?.cashAndCashEquivalents?.deposits?.cx
                },
                {
                  name: "FX",
                  chartId: "CA DEPOSITS FX",
                  value: (x) => x.assets?.current?.cashAndCashEquivalents?.deposits?.fx
                }
              ]
            },
            {
              name: "MM Materials",
              chartId: "CA MM MATERIALS",
              tooltip: "Market Maker materials currently stored in CX warehouses. You can customize the list of these materials using XIT SET FIN. Since these materials can be converted into cash immediately, they are considered Cash Equivalents.",
              value: (x) => x.assets?.current?.cashAndCashEquivalents?.mmMaterials
            }
          ]
        },
        {
          name: "Accounts Receivable",
          chartId: "CA ACCOUNTS RECEIVABLE",
          value: (x) => x.assets?.current?.accountsReceivable
        },
        {
          name: "Loans Receivable",
          chartId: "CA LOANS RECEIVABLE",
          value: calcTotalLoansReceivable,
          children: [
            {
              name: "Principal",
              chartId: "CA LOANS PRINCIPAL",
              value: (x) => x.assets?.current?.loansReceivable?.principal
            },
            {
              name: "Interest",
              chartId: "CA LOANS INTEREST",
              value: (x) => x.assets?.current?.loansReceivable?.interest
            }
          ]
        },
        {
          name: "Inventory",
          chartId: "CA INVENTORY",
          value: calcTotalInventory,
          children: [
            {
              name: "CX-Listed Materials",
              chartId: "CA CX LISTED MATERIALS",
              value: (x) => x.assets?.current?.inventory?.cxListedMaterials
            },
            {
              name: "CX Inventory",
              chartId: "CA CX INVENTORY",
              value: (x) => x.assets?.current?.inventory?.cxInventory
            },
            {
              name: "Materials in Transit",
              chartId: "CA MATERIALS IN TRANSIT",
              value: (x) => x.assets?.current?.inventory?.materialsInTransit
            },
            {
              name: "Base Inventory",
              chartId: "CA BASE INVENTORY",
              value: calcTotalBaseInventory,
              children: [
                {
                  name: "Finished Goods",
                  chartId: "CA FINISHED GOODS",
                  value: (x) => x.assets?.current?.inventory?.baseInventory?.finishedGoods
                },
                {
                  name: "Work-in-Progress (WIP)",
                  chartId: "CA WORK IN PROGRESS",
                  value: (x) => x.assets?.current?.inventory?.baseInventory?.workInProgress
                },
                {
                  name: "Raw Materials",
                  chartId: "CA RAW MATERIALS",
                  value: (x) => x.assets?.current?.inventory?.baseInventory?.rawMaterials
                },
                {
                  name: "Workforce Consumables",
                  chartId: "CA WORKFORCE CONSUMABLES",
                  value: (x) => x.assets?.current?.inventory?.baseInventory?.workforceConsumables
                },
                {
                  name: "Other Items",
                  chartId: "CA OTHER ITEMS",
                  value: (x) => x.assets?.current?.inventory?.baseInventory?.otherItems
                }
              ]
            },
            {
              name: "Fuel Tanks",
              chartId: "CA FUEL TANKS",
              value: (x) => x.assets?.current?.inventory?.fuelTanks
            },
            {
              name: "Materials Receivable",
              chartId: "CA MATERIALS RECEIVABLE",
              value: (x) => x.assets?.current?.inventory?.materialsReceivable
            }
          ]
        }
      ]
    }));
    const nonCurrentAssets = computed(() => ({
      name: "Non-Current Assets",
      chartId: "NON CURRENT ASSETS",
      value: calcTotalNonCurrentAssets,
      children: [
        {
          name: "Buildings, net",
          chartId: "NCA BUILDINGS",
          value: calcTotalBuildings,
          children: [
            {
              name: "Market Value",
              chartId: "NCA BUILDINGS VALUE",
              value: calcTotalBuildingsMarketValue,
              children: [
                {
                  name: "Infrastructure",
                  chartId: "NCA BUILDINGS INFRASTRUCTURE",
                  value: (x) => x.assets?.nonCurrent?.buildings?.marketValue?.infrastructure
                },
                {
                  name: "Resource Extraction",
                  chartId: "NCA BUILDINGS RESOURCE EXTRACTION",
                  value: (x) => x.assets?.nonCurrent?.buildings?.marketValue?.resourceExtraction
                },
                {
                  name: "Production",
                  chartId: "NCA BUILDINGS PRODUCTION",
                  value: (x) => x.assets?.nonCurrent?.buildings?.marketValue?.production
                }
              ]
            },
            {
              name: "Acc. Depreciation",
              chartId: "NCA BUILDINGS DEPRECIATION",
              less: true,
              value: (x) => x.assets?.nonCurrent?.buildings?.accumulatedDepreciation
            }
          ]
        },
        {
          name: "Ships, net",
          chartId: "NCA SHIPS",
          value: calcTotalShips,
          excluded: !userData.fullEquityMode,
          children: [
            {
              name: "Market Value",
              chartId: "NCA SHIPS VALUE",
              value: (x) => x.assets?.nonCurrent?.ships?.marketValue
            },
            {
              name: "Acc. Depreciation",
              chartId: "NCA SHIPS DEPRECIATION",
              less: true,
              value: (x) => x.assets?.nonCurrent?.ships?.accumulatedDepreciation
            }
          ]
        },
        {
          name: "Long-Term Receivables",
          chartId: "NCA LONG TERM RECEIVABLES",
          value: calcTotalLongTermReceivables,
          children: [
            {
              name: "Accounts Receivable",
              chartId: "NCA ACCOUNTS RECEIVABLE",
              value: (x) => x.assets?.nonCurrent?.longTermReceivables?.accountsReceivable
            },
            {
              name: "Materials in Transit",
              chartId: "NCA MATERIALS IN TRANSIT",
              value: (x) => x.assets?.nonCurrent?.longTermReceivables?.materialsInTransit
            },
            {
              name: "Materials Receivable",
              chartId: "NCA MATERIALS RECEIVABLE",
              value: (x) => x.assets?.nonCurrent?.longTermReceivables?.materialsReceivable
            },
            {
              name: "Loans Principal",
              chartId: "NCA LOANS PRINCIPAL",
              value: (x) => x.assets?.nonCurrent?.longTermReceivables?.loansPrincipal
            }
          ]
        },
        {
          name: "Intangible Assets",
          chartId: "NCA INTANGIBLE ASSETS",
          value: calcTotalIntangibleAssets,
          excluded: !userData.fullEquityMode,
          children: [
            {
              name: "HQ Upgrades",
              chartId: "NCA HQ UPGRADES",
              value: (x) => x.assets?.nonCurrent?.intangibleAssets?.hqUpgrades
            },
            {
              name: "APEX Representation Center",
              chartId: "NCA ARC",
              value: (x) => x.assets?.nonCurrent?.intangibleAssets?.arc
            }
          ]
        }
      ]
    }));
    const currentLiabilities = computed(() => ({
      name: "Current Liabilities",
      chartId: "CURRENT LIABILITIES",
      value: calcTotalCurrentLiabilities,
      children: [
        {
          name: "Accounts Payable",
          chartId: "CL ACCOUNTS PAYABLE",
          value: (x) => x.liabilities?.current?.accountsPayable
        },
        {
          name: "Materials Payable",
          chartId: "CL MATERIALS PAYABLE",
          value: (x) => x.liabilities?.current?.materialsPayable
        },
        {
          name: "Loans Payable",
          chartId: "CL LOANS PAYABLE",
          value: calcTotalLoansPayable,
          children: [
            {
              name: "Principal",
              chartId: "CL LOANS PRINCIPAL",
              value: (x) => x.liabilities?.current?.loansPayable?.principal
            },
            {
              name: "Interest",
              chartId: "CL LOANS INTEREST",
              value: (x) => x.liabilities?.current?.loansPayable?.interest
            }
          ]
        }
      ]
    }));
    const nonCurrentLiabilities = computed(() => ({
      name: "Non-Current Liabilities",
      chartId: "NON CURRENT LIABILITIES",
      value: calcTotalNonCurrentLiabilities,
      children: [
        {
          name: "Long-Term Payables",
          chartId: "NCL LONG TERM PAYABLES",
          value: calcTotalLongTermPayables,
          children: [
            {
              name: "Accounts Payable",
              chartId: "NCL ACCOUNTS PAYABLE",
              value: (x) => x.liabilities?.nonCurrent?.longTermPayables?.accountsPayable
            },
            {
              name: "Materials Payable",
              chartId: "NCL MATERIALS PAYABLE",
              value: (x) => x.liabilities?.nonCurrent?.longTermPayables?.materialsPayable
            },
            {
              name: "Loans Principal",
              chartId: "NCL LOANS PRINCIPAL",
              value: (x) => x.liabilities?.nonCurrent?.longTermPayables?.loansPrincipal
            }
          ]
        }
      ]
    }));
    const equity = computed(() => ({
      name: "Equity",
      chartId: "EQUITY",
      coloredChange: true,
      value: calcEquity,
      children: [
        {
          name: "Total Assets",
          chartId: "TOTAL ASSETS",
          value: calcTotalAssets
        },
        {
          name: "Total Liabilities",
          chartId: "TOTAL LIABILITIES",
          less: true,
          value: calcTotalLiabilities
        }
      ]
    }));
    const sections = [
      currentAssets,
      nonCurrentAssets,
      currentLiabilities,
      nonCurrentLiabilities,
      equity
    ];
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("table", null, [
        createBaseVNode("thead", null, [
          createBaseVNode("tr", null, [
            _cache[0] || (_cache[0] = createBaseVNode("th", null, " ", -1)),
            _cache[1] || (_cache[1] = createBaseVNode("th", null, "Current Period", -1)),
            createBaseVNode("th", null, [
              unref(lastBalance) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                createTextVNode(toDisplayString(unref(ddmmyyyy)(unref(lastBalance).timestamp)), 1)
              ], 64)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                createTextVNode("Last Period")
              ], 64))
            ]),
            createBaseVNode("th", null, [
              unref(previousBalance) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                createTextVNode(toDisplayString(unref(ddmmyyyy)(unref(previousBalance).timestamp)), 1)
              ], 64)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                createTextVNode("Previous Period")
              ], 64))
            ]),
            _cache[2] || (_cache[2] = createBaseVNode("th", null, "Change", -1)),
            _cache[3] || (_cache[3] = createBaseVNode("th", null, null, -1))
          ])
        ]),
        (openBlock(), createElementBlock(Fragment, null, renderList(sections, (section) => {
          return createVNode(BalanceSheetSection, {
            key: section.value.name,
            current: unref(liveBalanceSheet),
            last: unref(lastBalance),
            previous: unref(previousBalance),
            section: section.value
          }, null, 8, ["current", "last", "previous", "section"]);
        }), 64))
      ]);
    };
  }
});
export {
  _sfc_main as default
};
