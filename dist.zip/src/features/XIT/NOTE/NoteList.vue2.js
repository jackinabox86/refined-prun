import _sfc_main from "./NoteList.vue.js";
export {
  _sfc_main as default
};
