import { useCssModule, vModelText } from "../../../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import Header from "../../../components/Header.vue.js";
import { defineComponent, computed, useTemplateRef, onMounted, watch, openBlock, createElementBlock, createVNode, createElementVNode as createBaseVNode, withDirectives, Fragment, nextTick } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = ["innerHTML"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "NoteEditor",
  props: {
    note: {}
  },
  setup(__props) {
    const $style = useCssModule();
    const renderedText = computed(() => processText(__props.note.text));
    function processText(text) {
      if (text === void 0) {
        return "";
      }
      if (text[text.length - 1] == "\n") {
        text += " ";
      }
      text = text.replaceAll("&", "&amp;").replaceAll("<", "&lt;");
      const regexp = /\b(?:[a-zA-Z0-9]{1,3}\.(?:CI1|IC1|AI1|NC1|CI2|NC2))(?!<)/g;
      let counter = 0;
      while (true) {
        const matches = text.match(regexp);
        if (!matches) {
          break;
        }
        text = text.replaceAll(
          regexp,
          (match) => `<span class="${C.Link.link} ${$style.link}">${match}</span>`
        );
        counter++;
        if (counter > 100) {
          break;
        }
      }
      return text;
    }
    const textbox = useTemplateRef("textbox");
    const overlay = useTemplateRef("overlay");
    onMounted(() => {
      textbox.value.addEventListener("scroll", () => {
        overlay.value.scrollTop = textbox.value.scrollTop;
        overlay.value.scrollLeft = textbox.value.scrollLeft;
      });
    });
    watch(
      renderedText,
      async () => {
        await nextTick();
        const links = overlay.value?.getElementsByClassName($style.link) ?? [];
        for (const link of Array.from(links)) {
          link.addEventListener("click", () => {
            showBuffer(`CXPO ${link.textContent}`);
          });
        }
      },
      { immediate: true }
    );
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(Header, {
          modelValue: _ctx.note.name,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => _ctx.note.name = $event),
          editable: "",
          class: normalizeClass(unref($style).header)
        }, null, 8, ["modelValue", "class"]),
        createBaseVNode("div", {
          class: normalizeClass(unref($style).header)
        }, toDisplayString(_ctx.note.name), 3),
        createBaseVNode("div", null, [
          withDirectives(createBaseVNode("textarea", {
            ref_key: "textbox",
            ref: textbox,
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => _ctx.note.text = $event),
            class: normalizeClass(unref($style).textarea),
            spellcheck: "false"
          }, null, 2), [
            [vModelText, _ctx.note.text]
          ]),
          createBaseVNode("pre", {
            ref_key: "overlay",
            ref: overlay,
            class: normalizeClass(unref($style).overlay),
            innerHTML: unref(renderedText)
          }, null, 10, _hoisted_1)
        ])
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
