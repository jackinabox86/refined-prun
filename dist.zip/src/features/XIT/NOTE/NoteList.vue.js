import { showTileOverlay, showConfirmationOverlay } from "../../../infrastructure/prun-ui/tile-overlay.js";
import _sfc_main$3 from "./CreateNoteOverlay.vue.js";
import _sfc_main$1 from "../../../components/PrunButton.vue.js";
import _sfc_main$2 from "../../../components/ActionBar.vue.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import { userData } from "../../../store/user-data.js";
import { createNote, deleteNote } from "../../../store/notes.js";
import { vDraggable as so } from "../../../../npm/vue-draggable-plus@0.6.0_@types+sortablejs@1.15.8-vue-draggable-plus-vue-draggable-plus.js";
import { grip } from "../../../components/grip/index.js";
import GripCell from "../../../components/grip/GripCell.vue.js";
import GripHeaderCell from "../../../components/grip/GripHeaderCell.vue.js";
import PrunLink from "../../../components/PrunLink.vue.js";
import { defineComponent, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, withDirectives, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "NoteList",
  setup(__props) {
    function createNewNote(ev) {
      showTileOverlay(ev, _sfc_main$3, {
        onCreate: (name) => {
          const id = createNote(name);
          showBuffer(`XIT NOTE ${id}`);
        }
      });
    }
    function confirmDelete(ev, note) {
      showConfirmationOverlay(ev, () => deleteNote(note), {
        message: `Are you sure you want to delete the note "${note.name}"?`
      });
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(_sfc_main$2, null, {
          default: withCtx(() => [
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: createNewNote
            }, {
              default: withCtx(() => [..._cache[0] || (_cache[0] = [
                createTextVNode("CREATE NEW", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        }),
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createVNode(GripHeaderCell),
              _cache[1] || (_cache[1] = createBaseVNode("th", null, "Name", -1)),
              _cache[2] || (_cache[2] = createBaseVNode("th", null, "Length", -1)),
              _cache[3] || (_cache[3] = createBaseVNode("th", null, null, -1))
            ])
          ]),
          withDirectives((openBlock(), createElementBlock("tbody", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(userData).notes, (note) => {
              return openBlock(), createElementBlock("tr", {
                key: note.id
              }, [
                createVNode(GripCell),
                createBaseVNode("td", null, [
                  createVNode(PrunLink, {
                    inline: "",
                    command: `XIT NOTE ${note.id.substring(0, 8)}`
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(note.name), 1)
                    ]),
                    _: 2
                  }, 1032, ["command"])
                ]),
                createBaseVNode("td", null, [
                  createBaseVNode("span", null, toDisplayString(note.text.length.toLocaleString()) + " character" + toDisplayString(note.text.length !== 1 ? "s" : ""), 1)
                ]),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$1, {
                    danger: "",
                    onClick: ($event) => confirmDelete($event, note)
                  }, {
                    default: withCtx(() => [..._cache[4] || (_cache[4] = [
                      createTextVNode("DELETE", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ])
              ]);
            }), 128))
          ])), [
            [unref(so), [unref(userData).notes, unref(grip).draggable]]
          ])
        ])
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
