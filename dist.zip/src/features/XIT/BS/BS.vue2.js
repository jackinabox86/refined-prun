import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import LoadingSpinner from "../../../components/LoadingSpinner.vue.js";
import _sfc_main$1 from "../../../components/forms/RadioItem.vue.js";
import BaseRow from "./BaseRow.vue.js";
import { sitesStore } from "../../../infrastructure/prun-api/data/sites.js";
import { storagesStore } from "../../../infrastructure/prun-api/data/storage.js";
import { getEntityNameFromAddress, getEntityNaturalIdFromAddress } from "../../../infrastructure/prun-api/data/addresses.js";
import { comparePlanets } from "../../../util.js";
import { useTileState } from "../../../store/user-data-tiles.js";
import { getPlanetBurn } from "../../../core/burn.js";
import { countDays } from "../BURN/utils.js";
import { defineComponent, computed, openBlock, createBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, createCommentVNode, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref, isRef } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "BS",
  setup(__props) {
    const sortKey = useTileState("sortKey", "burn");
    const sortDirection = useTileState("sortDirection", "asc");
    const showBurn = useTileState("showBurn", true);
    const showProd = useTileState("showProd", true);
    function setSort(key) {
      if (sortKey.value === key) {
        sortDirection.value = sortDirection.value === "asc" ? "desc" : "asc";
      } else {
        sortKey.value = key;
        sortDirection.value = "asc";
      }
    }
    function getSortIndicator(key) {
      if (sortKey.value === key) {
        return sortDirection.value === "asc" ? "▲" : "▼";
      }
      return "▲";
    }
    function isSorted(key) {
      return sortKey.value === key;
    }
    const bases = computed(() => {
      const sites = sitesStore.all.value;
      if (!sites) {
        return void 0;
      }
      const entries = sites.map((site) => {
        const burn = getPlanetBurn(site.siteId);
        return {
          siteId: site.siteId,
          naturalId: getEntityNaturalIdFromAddress(site.address) ?? "",
          planetName: getEntityNameFromAddress(site.address) ?? "",
          storeId: storagesStore.getByAddressableId(site.siteId)?.[0]?.id ?? "",
          days: burn ? countDays(burn.burn) : void 0
        };
      }).filter((x) => x.naturalId);
      const dir = sortDirection.value === "asc" ? 1 : -1;
      entries.sort((a, b) => {
        if (sortKey.value === "burn") {
          const daysA = a.days ?? Infinity;
          const daysB = b.days ?? Infinity;
          if (daysA !== daysB) {
            return (daysA - daysB) * dir;
          }
        }
        return comparePlanets(a.naturalId, b.naturalId) * dir;
      });
      return entries;
    });
    return (_ctx, _cache) => {
      return unref(bases) === void 0 ? (openBlock(), createBlock(LoadingSpinner, { key: 0 })) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
        createBaseVNode("div", {
          class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).ComExOrdersPanel.filter)
        }, [
          createVNode(_sfc_main$1, {
            modelValue: unref(showBurn),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(showBurn) ? showBurn.value = $event : null),
            horizontal: ""
          }, {
            default: withCtx(() => [..._cache[4] || (_cache[4] = [
              createTextVNode("Burn", -1)
            ])]),
            _: 1
          }, 8, ["modelValue"]),
          createVNode(_sfc_main$1, {
            modelValue: unref(showProd),
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(showProd) ? showProd.value = $event : null),
            horizontal: ""
          }, {
            default: withCtx(() => [..._cache[5] || (_cache[5] = [
              createTextVNode("Prod", -1)
            ])]),
            _: 1
          }, 8, ["modelValue"])
        ], 2),
        createBaseVNode("table", {
          class: normalizeClass(_ctx.$style.table)
        }, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", {
                class: normalizeClass([_ctx.$style.narrowCol, _ctx.$style.sortable]),
                onClick: _cache[2] || (_cache[2] = ($event) => setSort("name"))
              }, [
                _cache[6] || (_cache[6] = createTextVNode(" Planet ", -1)),
                createBaseVNode("span", {
                  class: normalizeClass(isSorted("name") ? _ctx.$style.sortActive : _ctx.$style.sortInactive)
                }, toDisplayString(getSortIndicator("name")), 3)
              ], 2),
              createBaseVNode("th", {
                class: normalizeClass(_ctx.$style.narrowCol)
              }, "CMD", 2),
              unref(showBurn) ? (openBlock(), createElementBlock("th", {
                key: 0,
                class: normalizeClass([_ctx.$style.narrowCol, _ctx.$style.sortable, _ctx.$style.burnCol]),
                onClick: _cache[3] || (_cache[3] = ($event) => setSort("burn"))
              }, [
                _cache[7] || (_cache[7] = createTextVNode(" Burn ", -1)),
                createBaseVNode("span", {
                  class: normalizeClass(isSorted("burn") ? _ctx.$style.sortActive : _ctx.$style.sortInactive)
                }, toDisplayString(getSortIndicator("burn")), 3)
              ], 2)) : createCommentVNode("", true),
              unref(showProd) ? (openBlock(), createElementBlock("th", {
                key: 1,
                class: normalizeClass(_ctx.$style.narrowCol)
              }, "Prod", 2)) : createCommentVNode("", true),
              createBaseVNode("th", {
                class: normalizeClass(_ctx.$style.invCol)
              }, "Inv", 2),
              createBaseVNode("th", {
                class: normalizeClass(_ctx.$style.warCol)
              }, "War", 2)
            ])
          ]),
          createBaseVNode("tbody", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(bases), (base) => {
              return openBlock(), createBlock(BaseRow, {
                key: base.naturalId,
                "site-id": base.siteId,
                "natural-id": base.naturalId,
                "planet-name": base.planetName,
                "store-id": base.storeId,
                "show-burn": unref(showBurn),
                "show-prod": unref(showProd)
              }, null, 8, ["site-id", "natural-id", "planet-name", "store-id", "show-burn", "show-prod"]);
            }), 128))
          ])
        ], 2)
      ], 64));
    };
  }
});
export {
  _sfc_main as default
};
