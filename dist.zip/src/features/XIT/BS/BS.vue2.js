import LoadingSpinner from "../../../components/LoadingSpinner.vue.js";
import BaseRow from "./BaseRow.vue.js";
import { sitesStore } from "../../../infrastructure/prun-api/data/sites.js";
import { storagesStore } from "../../../infrastructure/prun-api/data/storage.js";
import { getEntityNameFromAddress, getEntityNaturalIdFromAddress } from "../../../infrastructure/prun-api/data/addresses.js";
import { comparePlanets } from "../../../util.js";
import { defineComponent, computed, openBlock, createBlock, createElementBlock, createElementVNode as createBaseVNode, Fragment, renderList } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { normalizeClass } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _hoisted_1 = { key: 1 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "BS",
  setup(__props) {
    const bases = computed(() => {
      const sites = sitesStore.all.value;
      if (!sites) {
        return void 0;
      }
      return sites.map((site) => ({
        siteId: site.siteId,
        naturalId: getEntityNaturalIdFromAddress(site.address) ?? "",
        planetName: getEntityNameFromAddress(site.address) ?? "",
        storeId: storagesStore.getByAddressableId(site.siteId)?.[0]?.id ?? ""
      })).filter((x) => x.naturalId).sort((a, b) => comparePlanets(a.naturalId, b.naturalId));
    });
    return (_ctx, _cache) => {
      return unref(bases) === void 0 ? (openBlock(), createBlock(LoadingSpinner, { key: 0 })) : (openBlock(), createElementBlock("table", _hoisted_1, [
        createBaseVNode("thead", null, [
          createBaseVNode("tr", null, [
            _cache[0] || (_cache[0] = createBaseVNode("th", null, "Planet", -1)),
            createBaseVNode("th", {
              class: normalizeClass(_ctx.$style.narrowCol)
            }, "CMD", 2),
            createBaseVNode("th", {
              class: normalizeClass(_ctx.$style.narrowCol)
            }, "Burn", 2),
            _cache[1] || (_cache[1] = createBaseVNode("th", null, "Inv", -1)),
            _cache[2] || (_cache[2] = createBaseVNode("th", null, "War", -1))
          ])
        ]),
        createBaseVNode("tbody", null, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(bases), (base) => {
            return openBlock(), createBlock(BaseRow, {
              key: base.naturalId,
              "site-id": base.siteId,
              "natural-id": base.naturalId,
              "planet-name": base.planetName,
              "store-id": base.storeId
            }, null, 8, ["site-id", "natural-id", "planet-name", "store-id"]);
          }), 128))
        ])
      ]));
    };
  }
});
export {
  _sfc_main as default
};
