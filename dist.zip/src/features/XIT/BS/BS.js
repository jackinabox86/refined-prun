import xit from "../xit-registry.js";
import BS from "./BS.vue.js";
xit.add({
  command: "BS",
  name: "BASE OVERVIEW",
  description: "Lists all player bases with links to key base commands.",
  component: () => BS
});
