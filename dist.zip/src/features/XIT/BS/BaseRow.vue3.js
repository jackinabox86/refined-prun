const planetCell = "rp-BaseRow__planetCell___dca7307";
const planetLink = "rp-BaseRow__planetLink___7a2d6ee";
const cmdCell = "rp-BaseRow__cmdCell___d43e28e";
const expandedButtons = "rp-BaseRow__expandedButtons___7a5b0d5";
const burnCell = "rp-BaseRow__burnCell___cdf9112";
const burnContent = "rp-BaseRow__burnContent___93312b4";
const daysNum = "rp-BaseRow__daysNum___5d9ca40";
const invCell = "rp-BaseRow__invCell___6150fce";
const style0 = {
  planetCell,
  planetLink,
  cmdCell,
  expandedButtons,
  burnCell,
  burnContent,
  daysNum,
  invCell
};
export {
  burnCell,
  burnContent,
  cmdCell,
  daysNum,
  style0 as default,
  expandedButtons,
  invCell,
  planetCell,
  planetLink
};
