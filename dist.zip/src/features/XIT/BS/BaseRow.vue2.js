import PrunLink from "../../../components/PrunLink.vue.js";
import _sfc_main$1 from "../../../components/PrunButton.vue.js";
import _sfc_main$2 from "../BURN/DaysCell.vue.js";
import InvBar from "./InvBar.vue.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import { getPlanetBurn } from "../../../core/burn.js";
import { countDays } from "../BURN/utils.js";
import { warehousesStore } from "../../../infrastructure/prun-api/data/warehouses.js";
import { storagesStore } from "../../../infrastructure/prun-api/data/storage.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, createBlock, createCommentVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = { key: 1 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "BaseRow",
  props: {
    siteId: {},
    naturalId: {},
    planetName: {},
    storeId: {}
  },
  setup(__props) {
    const burn = computed(() => getPlanetBurn(__props.siteId));
    const days = computed(() => burn.value ? countDays(burn.value.burn) : void 0);
    const warehouse = computed(() => warehousesStore.getByEntityNaturalId(__props.naturalId));
    const warehouseStore = computed(
      () => storagesStore.getByAddressableId(warehouse.value?.warehouseId)?.find((x) => x.type === "WAREHOUSE_STORE")
    );
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("tr", null, [
        createBaseVNode("td", {
          class: normalizeClass(_ctx.$style.planetCell)
        }, [
          createVNode(PrunLink, {
            inline: "",
            command: `PLI ${_ctx.naturalId}`,
            class: normalizeClass(_ctx.$style.planetLink)
          }, {
            default: withCtx(() => [
              createTextVNode(toDisplayString(_ctx.planetName), 1)
            ]),
            _: 1
          }, 8, ["command", "class"])
        ], 2),
        createBaseVNode("td", {
          class: normalizeClass(_ctx.$style.cmdCell)
        }, [
          createVNode(_sfc_main$1, {
            primary: "",
            inline: ""
          }, {
            default: withCtx(() => [..._cache[5] || (_cache[5] = [
              createTextVNode("CMDS▶", -1)
            ])]),
            _: 1
          }),
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.expandedButtons)
          }, [
            createVNode(_sfc_main$1, {
              primary: "",
              inline: "",
              onClick: _cache[0] || (_cache[0] = ($event) => unref(showBuffer)(`BBL ${_ctx.naturalId}`))
            }, {
              default: withCtx(() => [..._cache[6] || (_cache[6] = [
                createTextVNode("BUILDINGS", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              primary: "",
              inline: "",
              onClick: _cache[1] || (_cache[1] = ($event) => unref(showBuffer)(`BBC ${_ctx.naturalId}`))
            }, {
              default: withCtx(() => [..._cache[7] || (_cache[7] = [
                createTextVNode("CONSTRUCT", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              primary: "",
              inline: "",
              onClick: _cache[2] || (_cache[2] = ($event) => unref(showBuffer)(`WF ${_ctx.naturalId}`))
            }, {
              default: withCtx(() => [..._cache[8] || (_cache[8] = [
                createTextVNode("WORKFORCE", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              primary: "",
              inline: "",
              onClick: _cache[3] || (_cache[3] = ($event) => unref(showBuffer)(`EXP ${_ctx.naturalId}`))
            }, {
              default: withCtx(() => [..._cache[9] || (_cache[9] = [
                createTextVNode("EXPERTS", -1)
              ])]),
              _: 1
            })
          ], 2)
        ], 2),
        unref(days) !== void 0 ? (openBlock(), createBlock(_sfc_main$2, {
          key: 0,
          days: unref(days),
          class: normalizeClass(_ctx.$style.burnCell),
          onClick: _cache[4] || (_cache[4] = ($event) => unref(showBuffer)(`XIT BURN ${_ctx.naturalId}`))
        }, null, 8, ["days", "class"])) : (openBlock(), createElementBlock("td", _hoisted_1, "-")),
        createBaseVNode("td", {
          class: normalizeClass(_ctx.$style.invCell)
        }, [
          createVNode(InvBar, {
            "store-id": _ctx.storeId,
            "natural-id": _ctx.naturalId,
            "on-click-cmd": `INV ${_ctx.storeId.substring(0, 8)}`
          }, null, 8, ["store-id", "natural-id", "on-click-cmd"])
        ], 2),
        createBaseVNode("td", {
          class: normalizeClass(_ctx.$style.invCell)
        }, [
          unref(warehouseStore) ? (openBlock(), createBlock(InvBar, {
            key: 0,
            "store-id": unref(warehouseStore).id,
            "on-click-cmd": `WAR ${unref(warehouse).warehouseId}`
          }, null, 8, ["store-id", "on-click-cmd"])) : createCommentVNode("", true)
        ], 2)
      ]);
    };
  }
});
export {
  _sfc_main as default
};
