import { withModifiers } from "../../../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import PrunLink from "../../../components/PrunLink.vue.js";
import _sfc_main$1 from "../../../components/PrunButton.vue.js";
import InvBar from "./InvBar.vue.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import { getPlanetBurn } from "../../../core/burn.js";
import { countDays } from "../BURN/utils.js";
import { warehousesStore } from "../../../infrastructure/prun-api/data/warehouses.js";
import { storagesStore } from "../../../infrastructure/prun-api/data/storage.js";
import { userData } from "../../../store/user-data.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, createCommentVNode, createBlock } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "BaseRow",
  props: {
    siteId: {},
    naturalId: {},
    planetName: {},
    storeId: {},
    showBurn: { type: Boolean }
  },
  setup(__props) {
    const burn = computed(() => getPlanetBurn(__props.siteId));
    const days = computed(() => burn.value ? countDays(burn.value.burn) : void 0);
    const burnBgClass = computed(() => {
      if (days.value === void 0) return {};
      const d = Math.floor(days.value);
      return {
        [C.Workforces.daysMissing]: d <= userData.settings.burn.red,
        [C.Workforces.daysWarning]: d <= userData.settings.burn.yellow,
        [C.Workforces.daysSupplied]: d > userData.settings.burn.yellow
      };
    });
    const daysText = computed(() => {
      if (days.value === void 0) return void 0;
      const d = Math.floor(days.value);
      return d < 500 ? String(d) : "∞";
    });
    const warehouse = computed(() => warehousesStore.getByEntityNaturalId(__props.naturalId));
    const warehouseStore = computed(
      () => storagesStore.getByAddressableId(warehouse.value?.warehouseId)?.find((x) => x.type === "WAREHOUSE_STORE")
    );
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("tr", {
        class: normalizeClass(_ctx.$style.row)
      }, [
        createBaseVNode("td", {
          class: normalizeClass(_ctx.$style.planetCell)
        }, [
          createVNode(PrunLink, {
            inline: "",
            command: `BS ${_ctx.naturalId}`,
            class: normalizeClass(_ctx.$style.planetLink)
          }, {
            default: withCtx(() => [
              createTextVNode(toDisplayString(_ctx.planetName), 1)
            ]),
            _: 1
          }, 8, ["command", "class"])
        ], 2),
        createBaseVNode("td", {
          class: normalizeClass(_ctx.$style.cmdCell)
        }, [
          createVNode(_sfc_main$1, { primary: "" }, {
            default: withCtx(() => [..._cache[6] || (_cache[6] = [
              createTextVNode("CMDS▶", -1)
            ])]),
            _: 1
          }),
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.expandedButtons)
          }, [
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: _cache[0] || (_cache[0] = ($event) => unref(showBuffer)(`BBL ${_ctx.siteId}`))
            }, {
              default: withCtx(() => [..._cache[7] || (_cache[7] = [
                createTextVNode("BUILDINGS", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: _cache[1] || (_cache[1] = ($event) => unref(showBuffer)(`BBC ${_ctx.naturalId}`))
            }, {
              default: withCtx(() => [..._cache[8] || (_cache[8] = [
                createTextVNode("CONSTRUCT", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: _cache[2] || (_cache[2] = ($event) => unref(showBuffer)(`WF ${_ctx.siteId}`))
            }, {
              default: withCtx(() => [..._cache[9] || (_cache[9] = [
                createTextVNode("WORKFORCE", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: _cache[3] || (_cache[3] = ($event) => unref(showBuffer)(`EXP ${_ctx.siteId}`))
            }, {
              default: withCtx(() => [..._cache[10] || (_cache[10] = [
                createTextVNode("EXPERTS", -1)
              ])]),
              _: 1
            })
          ], 2)
        ], 2),
        _ctx.showBurn ? (openBlock(), createElementBlock("td", {
          key: 0,
          style: { position: "relative" },
          class: normalizeClass(_ctx.$style.burnCell),
          onClick: _cache[5] || (_cache[5] = ($event) => unref(showBuffer)(`XIT BURN ${_ctx.naturalId}`))
        }, [
          unref(daysText) !== void 0 ? (openBlock(), createElementBlock("div", {
            key: 0,
            style: { position: "absolute", left: 0, top: 0, width: "100%", height: "100%" },
            class: normalizeClass(unref(burnBgClass))
          }, null, 2)) : createCommentVNode("", true),
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.burnContent)
          }, [
            createVNode(_sfc_main$1, {
              dark: "",
              inline: "",
              onClick: _cache[4] || (_cache[4] = withModifiers(($event) => unref(showBuffer)(`XIT BURNACT ${_ctx.naturalId}`), ["stop"]))
            }, {
              default: withCtx(() => [..._cache[11] || (_cache[11] = [
                createTextVNode(" RESUPPLY ", -1)
              ])]),
              _: 1
            }),
            createBaseVNode("span", {
              class: normalizeClass(_ctx.$style.daysNum)
            }, toDisplayString(unref(daysText) ?? "-"), 3)
          ], 2)
        ], 2)) : createCommentVNode("", true),
        createBaseVNode("td", {
          class: normalizeClass(_ctx.$style.invCell)
        }, [
          createVNode(InvBar, {
            "store-id": _ctx.storeId,
            "natural-id": _ctx.naturalId,
            "on-click-cmd": `INV ${_ctx.storeId.substring(0, 8)}`
          }, null, 8, ["store-id", "natural-id", "on-click-cmd"])
        ], 2),
        createBaseVNode("td", {
          class: normalizeClass(_ctx.$style.invCell)
        }, [
          unref(warehouseStore) ? (openBlock(), createBlock(InvBar, {
            key: 0,
            "store-id": unref(warehouseStore).id,
            "on-click-cmd": `WAR ${_ctx.naturalId}`
          }, null, 8, ["store-id", "on-click-cmd"])) : createCommentVNode("", true)
        ], 2)
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
