const narrowCol = "rp-BS__narrowCol___dde46e9";
const style0 = {
  narrowCol
};
export {
  style0 as default,
  narrowCol
};
