const narrowCol = "rp-BS__narrowCol___dde46e9";
const invCol = "rp-BS__invCol___b86b7d9";
const warCol = "rp-BS__warCol___14ae21a";
const sortable = "rp-BS__sortable___d5ab970";
const sorted = "rp-BS__sorted___1dbf6ba";
const sortIndicator = "rp-BS__sortIndicator___565c53a";
const style0 = {
  narrowCol,
  invCol,
  warCol,
  sortable,
  sorted,
  sortIndicator
};
export {
  style0 as default,
  invCol,
  narrowCol,
  sortIndicator,
  sortable,
  sorted,
  warCol
};
