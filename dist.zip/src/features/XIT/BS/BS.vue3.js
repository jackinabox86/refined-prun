const table = "rp-BS__table___6d7e589";
const narrowCol = "rp-BS__narrowCol___dde46e9";
const invCol = "rp-BS__invCol___b86b7d9";
const warCol = "rp-BS__warCol___14ae21a";
const sortable = "rp-BS__sortable___d5ab970";
const sortActive = "rp-BS__sortActive___2492480";
const sortInactive = "rp-BS__sortInactive___8980050";
const burnCol = "rp-BS__burnCol___3bf8de5";
const style0 = {
  table,
  narrowCol,
  invCol,
  warCol,
  sortable,
  sortActive,
  sortInactive,
  burnCol
};
export {
  burnCol,
  style0 as default,
  invCol,
  narrowCol,
  sortActive,
  sortInactive,
  sortable,
  table,
  warCol
};
