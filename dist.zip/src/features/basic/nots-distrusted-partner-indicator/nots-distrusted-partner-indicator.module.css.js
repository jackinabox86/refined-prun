const distrustedAlert = "rp-nots-distrusted-partner-indicator__distrustedAlert___a7ec7cf";
const $style = {
  distrustedAlert
};
export {
  $style as default,
  distrustedAlert
};
