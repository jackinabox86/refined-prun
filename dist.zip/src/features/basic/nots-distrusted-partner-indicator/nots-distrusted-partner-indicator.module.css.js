const distrustedAlert = "rp-nots-distrusted-partner-indicator__distrustedAlert___a7ec7cf";
const distrustedIndicator = "rp-nots-distrusted-partner-indicator__distrustedIndicator___700f35a";
const $style = {
  distrustedAlert,
  distrustedIndicator
};
export {
  $style as default,
  distrustedAlert,
  distrustedIndicator
};
