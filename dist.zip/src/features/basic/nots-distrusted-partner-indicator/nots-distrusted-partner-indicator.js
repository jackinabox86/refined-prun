import { subscribe } from "../../../utils/subscribe-async-generator.js";
import { $$ } from "../../../utils/select-dom.js";
import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../../infrastructure/prun-ui/tiles.js";
import features from "../../feature-registry.js";
import $style from "./nots-distrusted-partner-indicator.module.css.js";
import { getPrunId } from "../../../infrastructure/prun-ui/attributes.js";
import { alertsStore } from "../../../infrastructure/prun-api/data/alerts.js";
import { waitNotificationLoaded } from "../../../infrastructure/prun-ui/notifications.js";
import { isDistrustedPartner } from "../../../store/distrust.js";
import { watchEffectWhileNodeAlive } from "../../../utils/watch.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, C.AlertListItem.container), processNotification);
}
async function processNotification(container) {
  await waitNotificationLoaded(container);
  const id = getPrunId(container);
  const alert = alertsStore.getById(id);
  if (!alert) {
    return;
  }
  const partnerEntry = alert.data.find((x) => x.key === "partner");
  if (!partnerEntry) {
    return;
  }
  const partner = partnerEntry.value;
  watchEffectWhileNodeAlive(container, () => {
    container.classList.toggle($style.distrustedAlert, isDistrustedPartner(partner));
  });
}
function init() {
  tiles.observe("NOTS", onTileReady);
}
features.add(
  import.meta.url,
  init,
  "NOTS: Marks notifications from distrusted partners with a red indicator."
);
