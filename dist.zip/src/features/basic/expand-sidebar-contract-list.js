import { $$, _$$, $ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { subscribe } from "../../utils/subscribe-async-generator.js";
import { applyCssRule } from "../../infrastructure/prun-ui/refined-prun-css.js";
import features from "../feature-registry.js";
import $style from "./expand-sidebar-contract-list.module.css.js";
import { PrunI18N } from "../../infrastructure/prun-ui/i18n.js";
import { clickElement } from "../../util.js";
async function onSidebarReady(sidebar) {
  const sectionHeads = _$$(sidebar, C.Sidebar.sectionHead);
  if (sectionHeads.length === 0) {
    return;
  }
  const localizedTitle = PrunI18N["Sidebar.header.contracts"]?.[0]?.value;
  const contractTitle = sectionHeads.find((x) => x.textContent === localizedTitle);
  if (!contractTitle) {
    return;
  }
  const contractsSection = contractTitle.parentElement;
  const contractsSectionContent = await $(contractsSection, C.Sidebar.sectionContent);
  contractsSection.classList.add($style.contractsSection);
  contractsSectionContent.classList.add($style.contractsSectionContent);
  subscribe($$(contractsSectionContent, C.EndlessScrollControl.loadMore), (loadMore) => {
    loadMore.style.display = "none";
    void clickLoadMore(loadMore);
  });
}
async function clickLoadMore(loadMore) {
  if (!loadMore.isConnected) {
    return;
  }
  if (!loadMore.classList.contains(C.EndlessScrollControl.hidden)) {
    await clickElement(loadMore);
  }
  requestAnimationFrame(() => void clickLoadMore(loadMore));
}
function init() {
  applyCssRule([`.${C.Sidebar.container}`], $style.sidebarContainer);
  subscribe($$(document, C.Sidebar.container), onSidebarReady);
}
features.add(import.meta.url, init, "Fully expands the contracts list in the sidebar.");
