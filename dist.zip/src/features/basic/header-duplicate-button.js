import { $ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { createFragmentApp } from "../../utils/vue-fragment-app.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { showBuffer } from "../../infrastructure/prun-ui/buffers.js";
import TileControlsButton from "../../components/TileControlsButton.vue.js";
async function onTileReady(tile) {
  const splitControls = await $(tile.frame, C.TileControls.splitControls);
  createFragmentApp(TileControlsButton, {
    icon: "",
    onClick: () => showBuffer(tile.fullCommand, { force: true })
  }).before(splitControls);
}
function init() {
  tiles.observeAll(onTileReady);
}
features.add(import.meta.url, init, "Adds a tile duplicate button to the buffer header.");
