import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$, _$$, $ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { contractDraftsStore } from "../../infrastructure/prun-api/data/contract-drafts.js";
import { getEntityNameFromAddress } from "../../infrastructure/prun-api/data/addresses.js";
import { computed } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function onTileReady(tile) {
  const draft = computed(() => contractDraftsStore.getByNaturalId(tile.parameter));
  let conditionIndex;
  subscribe($$(tile.anchor, C.Draft.conditions), (conditions) => {
    return subscribe($$(conditions, "tr"), (row) => {
      const indexText = row.children[0]?.textContent;
      const conditionEditButton = _$$(row, C.Button.btn)[0];
      if (!indexText || conditionEditButton === void 0) {
        return;
      }
      conditionEditButton.addEventListener("click", () => {
        const index = parseInt(indexText.replace("#", ""));
        if (isFinite(index)) {
          conditionIndex = index - 1;
        }
      });
    });
  });
  subscribe($$(tile.anchor, C.DraftConditionEditor.form), async (form) => {
    if (conditionIndex === void 0) {
      return;
    }
    const address = draft.value?.conditions[conditionIndex]?.address;
    const name = getEntityNameFromAddress(address);
    conditionIndex = void 0;
    if (name) {
      const input = await $(form, C.AddressSelector.input);
      input.placeholder = name;
    }
  });
}
function init() {
  tiles.observe("CONTD", onTileReady);
}
features.add(
  import.meta.url,
  init,
  "CONTD: Sets the current address as the placeholder for the address field of the condition editor."
);
