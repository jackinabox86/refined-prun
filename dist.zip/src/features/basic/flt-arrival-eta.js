import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$ } from "../../utils/select-dom.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { shipsStore } from "../../infrastructure/prun-api/data/ships.js";
import { flightsStore } from "../../infrastructure/prun-api/data/flights.js";
import { formatEta } from "../../utils/format.js";
import { timestampEachMinute } from "../../utils/dayjs.js";
import { refPrunId } from "../../infrastructure/prun-ui/attributes.js";
import { createReactiveSpan } from "../../utils/reactive-element.js";
import { keepLast } from "../../utils/keep-last.js";
import { computed } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, "tr"), onRowReady);
}
function onRowReady(row) {
  const id = refPrunId(row);
  const arrival = computed(() => {
    const ship = shipsStore.getById(id.value);
    const flight = flightsStore.getById(ship?.flightId);
    return flight?.arrival.timestamp;
  });
  const eta = computed(
    () => arrival.value !== void 0 ? ` (${formatEta(timestampEachMinute.value, arrival.value)})` : void 0
  );
  const span = createReactiveSpan(row, eta);
  keepLast(row, () => row.children[7], span);
}
function init() {
  tiles.observe(["FLT", "FLTS", "FLTP"], onTileReady);
}
features.add(import.meta.url, init, 'FLT: Adds an arrival date to the "ETA" column.');
