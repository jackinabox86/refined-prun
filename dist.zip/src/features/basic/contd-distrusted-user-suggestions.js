import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import distrust from "../../infrastructure/prun-ui/css/distrust.module.css.js";
import { isDistrustedUsername } from "../../store/distrust.js";
import { refTextContent } from "../../utils/reactive-dom.js";
import { watchEffectWhileNodeAlive } from "../../utils/watch.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, C.UserSelector.suggestionName), onSuggestionName);
}
function onSuggestionName(suggestionName) {
  const username = refTextContent(suggestionName);
  watchEffectWhileNodeAlive(suggestionName, () => {
    suggestionName.classList.toggle(distrust.distrusted, isDistrustedUsername(username.value));
  });
}
function init() {
  tiles.observe("CONTD", onTileReady);
}
features.add(import.meta.url, init, "CONTD: Highlights distrusted users in recipient suggestions.");
