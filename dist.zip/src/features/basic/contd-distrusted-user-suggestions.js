import { $$, _$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { subscribe } from "../../utils/subscribe-async-generator.js";
import features from "../feature-registry.js";
import distrust from "../../infrastructure/prun-ui/css/distrust.module.css.js";
import { isDistrustedUsername } from "../../store/distrust.js";
import { refTextContent } from "../../utils/reactive-dom.js";
import { watchEffectWhileNodeAlive } from "../../utils/watch.js";
function onSuggestionEntry(entry) {
  const nameElement = _$(entry, C.UserSelector.suggestionName);
  if (!nameElement) {
    return;
  }
  const username = refTextContent(nameElement);
  watchEffectWhileNodeAlive(nameElement, () => {
    nameElement.classList.toggle(distrust.distrusted, isDistrustedUsername(username.value));
  });
}
function init() {
  subscribe($$(document, C.UserSelector.suggestionEntry), onSuggestionEntry);
}
features.add(import.meta.url, init, "Highlights distrusted users in user selector suggestions.");
