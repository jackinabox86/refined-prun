import { $$, $, _$$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { applyCssRule } from "../../infrastructure/prun-ui/refined-prun-css.js";
import { subscribe } from "../../utils/subscribe-async-generator.js";
import features from "../feature-registry.js";
import $style from "./funny-materials.module.css.js";
import { timestampEachMinute } from "../../utils/dayjs.js";
import { computed, watch } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
const isFunny = computed(() => {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/Los_Angeles",
    month: "numeric",
    day: "numeric",
    hour: "numeric",
    hour12: false
  }).formatToParts(new Date(timestampEachMinute.value));
  const get = (type) => Number(parts.find((x) => x.type === type)?.value);
  const month = get("month");
  const day = get("day");
  const hour = get("hour");
  return month === 3 && day === 31 && hour >= 22 || month === 4 && day === 1 && hour < 22;
});
let checked = /* @__PURE__ */ new WeakSet();
function maybeBoost(container) {
  if (checked.has(container)) {
    return;
  }
  checked.add(container);
  if (Math.random() >= 0.01) {
    return;
  }
  void (async () => {
    const coloredIcon = await $(container, C.ColoredIcon.container);
    coloredIcon.classList.add("rp-icon-boost");
  })();
}
function unboost() {
  for (const container of _$$(document.body, C.ColoredIcon.container)) {
    container.classList.remove("rp-icon-boost");
  }
  checked = /* @__PURE__ */ new WeakSet();
}
function init() {
  applyCssRule(`.rp-icon-boost.${C.ColoredIcon.container}`, $style.iconBoost);
  applyCssRule(`.rp-icon-boost.${C.ColoredIcon.container}:before`, $style.hideIcon);
  applyCssRule(`.rp-icon-boost .${C.ColoredIcon.label}:before`, $style.hideIcon);
  subscribe($$(document, C.MaterialIcon.container), (container) => {
    if (!isFunny.value) {
      return;
    }
    maybeBoost(container);
  });
  watch(isFunny, (funny) => {
    if (!funny) {
      unboost();
      return;
    }
    for (const container of _$$(document.body, C.MaterialIcon.container)) {
      maybeBoost(container);
    }
  });
}
features.add(import.meta.url, init, "Improves material icon rendering.");
