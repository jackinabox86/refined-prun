import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import $style from "./sysi-blue-negative-value.module.css.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, C.ColoredValue.negative), (negative) => {
    if (negative.textContent?.includes("▼")) {
      negative.classList.add($style.lowValue);
    }
  });
}
function init() {
  tiles.observe("SYSI", onTileReady);
}
features.add(
  import.meta.url,
  init,
  "SYSI: Makes lower negative planet values blue instead of red."
);
