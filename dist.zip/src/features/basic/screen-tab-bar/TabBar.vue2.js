import { vShow } from "../../../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import _sfc_main$1 from "./HeadItem.vue.js";
import { screensStore } from "../../../infrastructure/prun-api/data/screens.js";
import { userData } from "../../../store/user-data.js";
import { vDraggable as so } from "../../../../npm/vue-draggable-plus@0.6.0_@types+sortablejs@1.15.8-vue-draggable-plus-vue-draggable-plus.js";
import { syncState } from "./sync.js";
import { defineComponent, watchEffect, computed, useTemplateRef, onMounted, openBlock, createElementBlock, createElementVNode as createBaseVNode, withDirectives, Fragment, renderList, createVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = ["href"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "TabBar",
  setup(__props) {
    watchEffect(syncState);
    const current = computed(() => screensStore.current.value);
    function getScreen(id) {
      return screensStore.getById(id);
    }
    const container = useTemplateRef("container");
    onMounted(() => {
      const el = container.value;
      let target = el.scrollLeft;
      let animating = false;
      function step() {
        const diff = target - el.scrollLeft;
        if (Math.abs(diff) < 0.5) {
          el.scrollLeft = target;
          animating = false;
          return;
        }
        el.scrollLeft += diff * 0.3;
        requestAnimationFrame(step);
      }
      el.addEventListener(
        "wheel",
        (e) => {
          e.preventDefault();
          const delta = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
          target = Math.max(0, Math.min(target + delta, el.scrollWidth - el.clientWidth));
          if (!animating) {
            animating = true;
            requestAnimationFrame(step);
          }
        },
        { passive: false }
      );
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", {
          class: normalizeClass(_ctx.$style.spacer)
        }, null, 2),
        withDirectives((openBlock(), createElementBlock("div", {
          ref_key: "container",
          ref: container,
          class: normalizeClass(_ctx.$style.container)
        }, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(userData).tabs.order, (id) => {
            return withDirectives((openBlock(), createElementBlock("a", {
              key: id,
              href: `#screen=${id}`,
              class: normalizeClass(_ctx.$style.item)
            }, [
              createVNode(_sfc_main$1, {
                label: getScreen(id).name,
                active: unref(current) === getScreen(id)
              }, null, 8, ["label", "active"])
            ], 10, _hoisted_1)), [
              [vShow, !unref(userData).tabs.hidden.includes(id)]
            ]);
          }), 128))
        ], 2)), [
          [unref(so), [unref(userData).tabs.order, { animation: 150 }]]
        ]),
        createBaseVNode("div", {
          class: normalizeClass(_ctx.$style.spacer)
        }, null, 2)
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
