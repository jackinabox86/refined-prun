import _sfc_main$1 from "./SortCriteria.vue.js";
import { objectId } from "../../../utils/object-id.js";
import { defineComponent, openBlock, createElementBlock, Fragment, renderList, createBlock, createVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "InventorySortControls",
  props: {
    activeSort: {},
    onAddClick: { type: Function },
    onModeClick: { type: Function },
    reverse: { type: Boolean },
    sorting: {}
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.sorting, (mode) => {
          return openBlock(), createBlock(_sfc_main$1, {
            key: unref(objectId)(mode),
            label: mode.label,
            active: mode.label === _ctx.activeSort,
            reverse: _ctx.reverse,
            onClick: ($event) => _ctx.onModeClick(mode.label)
          }, null, 8, ["label", "active", "reverse", "onClick"]);
        }), 128)),
        createVNode(_sfc_main$1, {
          label: "+",
          onClick: _ctx.onAddClick
        }, null, 8, ["onClick"])
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
