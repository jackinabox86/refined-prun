import features from "../feature-registry.js";
import { setRepairButtonEnabled } from "../XIT/REP/repair-button.js";
function init() {
  setRepairButtonEnabled(true);
}
features.add(
  import.meta.url,
  init,
  "REP: Shows a REP button in the CMD column to open XIT REPAIRACT for the row's planet."
);
