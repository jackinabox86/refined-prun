import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import features from "../feature-registry.js";
import $style from "./other-context-notification-count.module.css.js";
import { companyStore } from "../../infrastructure/prun-api/data/company.js";
import { createReactiveSpan } from "../../utils/reactive-element.js";
import { reachableAlerts } from "../../core/alerts.js";
import { computed } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function init() {
  const countLabel = computed(() => {
    const alerts = reachableAlerts.value;
    if (!alerts) {
      return void 0;
    }
    let count = 0;
    for (const alert of alerts) {
      if (alert.seen) {
        continue;
      }
      if (alert.contextId !== companyStore.value?.id) {
        count++;
      }
    }
    return count > 0 ? ` (${count})` : void 0;
  });
  subscribe($$(document, C.AlertsHeadItem.count), (count) => {
    const otherCount = createReactiveSpan(count, countLabel);
    otherCount.classList.add($style.count);
    count.after(otherCount);
  });
}
features.add(import.meta.url, init, "Adds a counter for notifications from other contexts in the NOTS header label.");
