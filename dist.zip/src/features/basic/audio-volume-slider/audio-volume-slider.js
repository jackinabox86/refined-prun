import { subscribe } from "../../../utils/subscribe-async-generator.js";
import { $, $$ } from "../../../utils/select-dom.js";
import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import features from "../../feature-registry.js";
import { setAudioVolume } from "../../../infrastructure/prun-ui/audio-interceptor.js";
import { userData } from "../../../store/user-data.js";
import { createFragmentApp } from "../../../utils/vue-fragment-app.js";
import AudioVolume from "./AudioVolume.vue.js";
import { watchEffect, createVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function init() {
  watchEffect(() => {
    setAudioVolume(userData.settings.audioVolume);
  });
  subscribe($$(document, C.MenuHeadItem.menu), async (menu) => {
    const audioToggle = await $(menu, C.RadioItem.container);
    createFragmentApp(() => createVNode(AudioVolume, null, null)).after(audioToggle);
  });
}
features.add(import.meta.url, init, "Adds a volume slider to the game settings in the top-right corner of the screen.");
