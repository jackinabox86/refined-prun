import { subscribe } from "../../utils/subscribe-async-generator.js";
import { _$$, $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { materialsStore } from "../../infrastructure/prun-api/data/materials.js";
import { materialCategoriesStore, toSerializableCategoryName } from "../../infrastructure/prun-api/data/material-categories.js";
import { showBuffer } from "../../infrastructure/prun-ui/buffers.js";
function onTileReady(tile) {
  const parameter = tile.parameter;
  const material = materialsStore.getByTicker(parameter);
  const category = materialCategoriesStore.getById(material?.category);
  if (!category) {
    return;
  }
  subscribe($$(tile.anchor, C.MaterialInformation.container), async (container) => {
    const fields = _$$(container, C.StaticInput.static);
    const categoryField = fields[1];
    if (categoryField === void 0) {
      return;
    }
    categoryField.classList.add(C.Link.link);
    categoryField.addEventListener("click", (e) => {
      showBuffer("XIT MATS " + toSerializableCategoryName(category.name));
      e.preventDefault();
      e.stopPropagation();
    });
  });
}
function init() {
  tiles.observe("MAT", onTileReady);
}
features.add(
  import.meta.url,
  init,
  "MAT: Makes material category clickable and leading to XIT MATS with the material category."
);
