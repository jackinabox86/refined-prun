import { fixed0 } from "../../../utils/format.js";
import { getMaterialByName } from "../../../infrastructure/prun-ui/i18n.js";
import { defineComponent, computed, openBlock, createElementBlock, Fragment, createTextVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "PpuLabel",
  props: {
    amountInput: {},
    materialName: {},
    totalPriceInput: {}
  },
  setup(__props) {
    const material = computed(() => getMaterialByName(__props.materialName));
    const unit = computed(() => {
      if (!material.value) {
        return void 0;
      }
      const weight = material.value.weight;
      const volume = material.value.volume;
      return weight >= volume ? { symbol: "t", size: weight } : { symbol: "m³", size: volume };
    });
    const amount = computed(() => {
      const amount2 = parseInt(__props.amountInput, 10);
      return isFinite(amount2) ? amount2 : void 0;
    });
    const totalSize = computed(() => {
      if (unit.value && amount.value !== void 0) {
        return fixed0(amount.value * unit.value.size);
      }
      return `-- `;
    });
    const totalPrice = computed(() => {
      const totalPrice2 = parseInt(__props.totalPriceInput, 10);
      return isFinite(totalPrice2) ? totalPrice2 : void 0;
    });
    const perUnit = computed(() => {
      if (unit.value && amount.value !== void 0 && totalPrice.value !== void 0) {
        return fixed0(totalPrice.value / (amount.value * unit.value.size));
      }
      return "--";
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("span", null, [
        unref(material) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
          createTextVNode(toDisplayString(unref(totalSize)) + " " + toDisplayString(unref(unit)?.symbol) + " | " + toDisplayString(unref(perUnit)) + "/" + toDisplayString(unref(unit)?.symbol), 1)
        ], 64)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
          createTextVNode("--")
        ], 64))
      ]);
    };
  }
});
export {
  _sfc_main as default
};
