import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$ } from "../../utils/select-dom.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import link from "../../infrastructure/prun-ui/css/link.module.css.js";
import { showBuffer } from "../../infrastructure/prun-ui/buffers.js";
import { isPresent } from "../../../npm/ts-extras@0.15.0-ts-extras-is-present.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, "tbody"), (tbody) => {
    subscribe($$(tbody, "tr"), (tr) => {
      const commandColumn = tr.children[0];
      const command = commandColumn?.textContent;
      const mandatoryParameters = tr.children[2];
      if (!isPresent(command) || mandatoryParameters === void 0) {
        return;
      }
      commandColumn.classList.add(link.link);
      commandColumn.addEventListener("click", (e) => {
        void showBuffer(command, { autoSubmit: (mandatoryParameters.textContent ?? "") === "" });
        e.stopPropagation();
        e.preventDefault();
      });
    });
  });
}
function init() {
  tiles.observe("CMDS", onTileReady);
}
features.add(import.meta.url, init, "CMDS: Makes commands clickable.");
