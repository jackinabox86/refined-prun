import { $ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { createFragmentApp } from "../../utils/vue-fragment-app.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { showBuffer } from "../../infrastructure/prun-ui/buffers.js";
import TileControlsButton from "../../components/TileControlsButton.vue.js";
async function onTileReady(tile) {
  const tileControls = await $(tile.frame, C.TileFrame.controls);
  createFragmentApp(TileControlsButton, {
    icon: "",
    onClick: () => showBuffer("XIT CALC"),
    marginTop: 4
  }).prependTo(tileControls);
  return;
}
function init() {
  tiles.observe(["LM", "CX", "XIT"], onTileReady);
}
features.add(
  import.meta.url,
  init,
  "Adds a calculator button to the buffer header of LM, CX and XIT commands."
);
