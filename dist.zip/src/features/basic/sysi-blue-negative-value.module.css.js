const lowValue = "rp-sysi-blue-negative-value__lowValue___309ae95";
const $style = {
  lowValue
};
export {
  $style as default,
  lowValue
};
