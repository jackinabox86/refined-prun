import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$, $, _$$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { createFragmentApp } from "../../utils/vue-fragment-app.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { getMaterialName } from "../../infrastructure/prun-ui/i18n.js";
import $style from "./cx-search-bar.module.css.js";
import { materialsStore } from "../../infrastructure/prun-api/data/materials.js";
import css from "../../utils/css-utils.module.css.js";
import { watchEffectWhileNodeAlive } from "../../utils/watch.js";
import _sfc_main from "../../components/forms/TextInput.vue.js";
import _sfc_main$1 from "../../components/PrunButton.vue.js";
import fa from "../../utils/font-awesome.module.css.js";
import { refValue } from "../../utils/reactive-dom.js";
import { ref, triggerRef } from "../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { watch, createVNode, createTextVNode } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, C.ComExPanel.input), onComExPanelReady);
}
async function onComExPanelReady(comExPanel) {
  const actionBar = await $(comExPanel, C.ActionBar.container);
  const select = await $(actionBar, "select");
  const selectValue = refValue(select);
  const searchText = ref("");
  const categoryOptions = /* @__PURE__ */ new Map();
  for (const option of Array.from(select.options)) {
    categoryOptions.set(option.value, option);
  }
  const materialRows = /* @__PURE__ */ new Map();
  async function loadMaterialRows() {
    const tbody = await $(comExPanel, "tbody");
    for (const row of _$$(tbody, "tr")) {
      const labelText = await $(row, C.ColoredIcon.label);
      materialRows.set(labelText.innerText, row);
    }
    triggerRef(searchText);
  }
  subscribe($$(comExPanel, "tbody"), loadMaterialRows);
  watch(selectValue, loadMaterialRows);
  const resetMatches = (value) => {
    if (value.isConnected) {
      value.classList.toggle(css.hidden, searchText.value.length !== 0);
    }
  };
  watchEffectWhileNodeAlive(comExPanel, () => {
    const searchTerm = searchText.value.toUpperCase();
    for (const option of categoryOptions.values()) {
      resetMatches(option);
    }
    for (const row of materialRows.values()) {
      resetMatches(row);
    }
    const materials = materialsStore.all.value;
    if (searchTerm.length === 0 || !materials) {
      return;
    }
    for (const material of materials) {
      if (material.ticker.includes(searchTerm) || getMaterialName(material)?.toUpperCase().includes(searchTerm)) {
        const optionElement = categoryOptions.get(material.category);
        if (optionElement) {
          optionElement.classList.remove(css.hidden);
        }
        const rowElement = materialRows.get(material.ticker);
        if (rowElement?.isConnected) {
          rowElement.classList.remove(css.hidden);
        }
      }
    }
  });
  createFragmentApp(() => createVNode("div", {
    "class": [C.ActionBar.element, $style.container]
  }, [createTextVNode("Search: "), createVNode(_sfc_main, {
    "modelValue": searchText.value,
    "onUpdate:modelValue": ($event) => searchText.value = $event
  }, null), createVNode(_sfc_main$1, {
    "dark": true,
    "class": [$style.button, fa.solid],
    "onClick": () => searchText.value = ""
  }, {
    default: () => [""]
  })])).prependTo(actionBar);
}
function init() {
  tiles.observe("CX", onTileReady);
}
features.add(import.meta.url, init, "CX: Adds a search bar for materials.");
