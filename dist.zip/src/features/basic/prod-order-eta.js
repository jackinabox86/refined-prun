import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$, _$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { refPrunId } from "../../infrastructure/prun-ui/attributes.js";
import { sitesStore } from "../../infrastructure/prun-api/data/sites.js";
import { productionStore } from "../../infrastructure/prun-api/data/production.js";
import { formatEta } from "../../utils/format.js";
import { timestampEachMinute } from "../../utils/dayjs.js";
import { createReactiveDiv } from "../../utils/reactive-element.js";
import { keepLast } from "../../utils/keep-last.js";
import { calcCompletionDate } from "../../core/production-line.js";
import { computed } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function onTileReady(tile) {
  if (!tile.parameter) {
    return;
  }
  subscribe($$(tile.anchor, C.OrderSlot.container), (x) => onOrderSlotReady(x, tile.parameter));
}
function onOrderSlotReady(slot, siteId) {
  const orderId = refPrunId(slot);
  const completion = computed(() => {
    const site = sitesStore.getById(siteId);
    const lines = productionStore.getBySiteId(site?.siteId) ?? [];
    for (const line of lines) {
      for (const order of line.orders) {
        if (order.id === orderId.value) {
          return calcCompletionDate(line, order);
        }
      }
    }
    return void 0;
  });
  const eta = computed(() => {
    return completion.value !== void 0 ? `(${formatEta(timestampEachMinute.value, completion.value)})` : void 0;
  });
  const div = createReactiveDiv(slot, eta);
  keepLast(slot, () => _$(slot, C.OrderSlot.info), div);
}
function init() {
  tiles.observe("PROD", onTileReady);
}
features.add(import.meta.url, init, "PROD: Adds a finish ETA label to orders.");
