import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$, $ } from "../../utils/select-dom.js";
import { applyCssRule } from "../../infrastructure/prun-ui/refined-prun-css.js";
import { C, prunCssStylesheets } from "../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import $style from "./prun-bugs.module.css.js";
import { clickElement } from "../../util.js";
function removeMobileCssRules() {
  for (const style of prunCssStylesheets) {
    const styleSheet = style.sheet;
    const rules = styleSheet.cssRules;
    try {
      for (let j = rules.length - 1; j >= 0; j--) {
        const rule = rules[j];
        if (rule instanceof CSSMediaRule && rule.media.mediaText.includes("screen")) {
          styleSheet.deleteRule(j);
        }
      }
    } catch (e) {
      console.log(`Could not modify stylesheet: ${styleSheet.href}, Error: ${e}`);
    }
  }
}
function disableInvalidPopidSliders(tile) {
  subscribe($$(tile.anchor, "tr"), (row) => {
    subscribe($$(row, "rc-slider"), async (slider) => {
      const sliderMarks = Array.from((await $(slider, "rc-slider-mark")).children);
      const sliderMaxMark = sliderMarks[sliderMarks.length - 1];
      const sliderMax = parseFloat(sliderMaxMark.textContent);
      const sliderValueMark = sliderMarks.findLast(
        (x) => x.classList.contains("rc-slider-mark-text-active")
      );
      if (!sliderValueMark) {
        return;
      }
      const sliderValue = parseFloat(sliderValueMark.textContent);
      const reserveCell = row.children[3];
      if (reserveCell === void 0) {
        return;
      }
      const reserveBar = await $(reserveCell, "progress");
      if (reserveBar.value - sliderValue + sliderMax > reserveBar.max) {
        await clickElement(sliderMarks[0]);
        slider.classList.add("rc-slider-disabled");
        slider.style.pointerEvents = "none";
      }
    });
  });
}
function fixZOrder() {
  applyCssRule(
    [
      `.${C.ComExOrdersPanel.filter}`,
      `.${C.LocalMarket.filter}`,
      `.${C.ContractsListTable.filter}`
    ],
    $style.filter
  );
  applyCssRule(`.${C.ScrollView.track}`, $style.scrollTrack);
}
function fixSliders() {
  applyCssRule(".rc-slider-dot", $style.rcSliderDotFixes);
  applyCssRule(".rc-slider-handle", $style.rcSliderHandleFixes);
  applyCssRule(".rc-slider-step", $style.rcSliderStepFixes);
}
function init() {
  removeMobileCssRules();
  fixZOrder();
  fixSliders();
  applyCssRule(`.${C.Head.container}`, $style.head);
  applyCssRule(`.${C.ColoredIcon.subLabel}`, $style.subLabel);
  applyCssRule(`.${C.GridItemView.container}`, $style.gridItem);
  applyCssRule(`.${C.GridItemView.selected}`, $style.gridItemSelected);
  applyCssRule(`.${C.GridItemView.name}`, $style.gridItemName);
  applyCssRule(["PROD", "PRODQ"], `.${C.OrderTile.overlay}`, $style.disablePointerEvents);
  applyCssRule("PROD", `.${C.SiteProductionLines.container}`, $style.containerScrollbarGutter);
  applyCssRule("GIFT", `.${C.UserSelector.suggestionsContainer}`, $style.giftSearchResults);
  applyCssRule(
    "SYSI",
    `.${C.EnvironmentTable.gridContainer} .${C.ColoredValue.positive}`,
    $style.centerText
  );
  applyCssRule(
    "SYSI",
    `.${C.EnvironmentTable.gridContainer} .${C.ColoredValue.negative}`,
    $style.centerText
  );
  applyCssRule('[data-tooltip-position="bottom"]', $style.tooltipBottom);
  applyCssRule('[data-tooltip-position="right"]', $style.tooltipRight);
  tiles.observe("POPID", disableInvalidPopidSliders);
}
features.add(import.meta.url, init, "Fixes PrUn bugs.");
