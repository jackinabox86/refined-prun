import { subscribe } from "../../utils/subscribe-async-generator.js";
import { _$$, $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { createFragmentApp } from "../../utils/vue-fragment-app.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { sitesStore } from "../../infrastructure/prun-api/data/sites.js";
import { refPrunId } from "../../infrastructure/prun-ui/attributes.js";
import { isRepairableBuilding } from "../../core/buildings.js";
import ProgressBar from "../../components/ProgressBar.vue.js";
import { computed } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { reactive } from "../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
function onTileReady(tile) {
  const siteId = tile.parameter;
  const site = computed(() => sitesStore.getById(siteId));
  subscribe($$(tile.anchor, C.SectionList.section), (section) => {
    const id = refPrunId(section);
    const building = computed(() => site.value?.platforms.find((p) => p.id == id.value));
    if (!building.value || !isRepairableBuilding(building.value)) {
      return;
    }
    const rows = _$$(section, "tr");
    const condition = computed(() => building.value?.condition ?? 0);
    const good = computed(() => condition.value > 0.9);
    const warning = computed(() => !good.value && condition.value > 0.8);
    const danger = computed(() => condition.value <= 0.8);
    createFragmentApp(
      ProgressBar,
      reactive({
        value: condition,
        max: 1,
        good,
        warning,
        danger
      })
    ).prependTo(rows[5].children[1]);
  });
}
function init() {
  tiles.observe("BBL", onTileReady);
}
features.add(import.meta.url, init, "BBL: Adds a progress bar to the building condition row.");
