import { $ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { createFragmentApp } from "../../utils/vue-fragment-app.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import _sfc_main from "../../components/ContextControlsItem.vue.js";
import { sitesStore } from "../../infrastructure/prun-api/data/sites.js";
import { getEntityNaturalIdFromAddress } from "../../infrastructure/prun-api/data/addresses.js";
async function onTileReady(tile) {
  if (!tile.parameter) {
    return;
  }
  const site = sitesStore.getById(tile.parameter);
  if (!site) {
    return;
  }
  const contextBar = await $(tile.frame, C.ContextControls.container);
  createFragmentApp(_sfc_main, {
    cmd: `XIT BURN ${getEntityNaturalIdFromAddress(site.address)}`
  }).prependTo(contextBar);
}
function init() {
  tiles.observe("PROD", onTileReady);
}
features.add(import.meta.url, init, "PROD: Adds a XIT BURN link to the context bar.");
