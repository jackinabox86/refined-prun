import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$, _$$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { createFragmentApp } from "../../utils/vue-fragment-app.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { refAnimationFrame } from "../../utils/reactive-dom.js";
import { isEmpty } from "../../../npm/ts-extras@0.15.0-ts-extras-is-empty.js";
import { createVNode } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function onTileReady(tile) {
  if (!tile.parameter) {
    return;
  }
  subscribe($$(tile.anchor, C.Site.workforces), (workforces) => {
    subscribe($$(workforces, "tr"), (row) => {
      const cells = _$$(row, "td");
      if (isEmpty(cells)) {
        return;
      }
      const bar = cells[4].getElementsByTagName("div")[0];
      bar.style.display = "flex";
      bar.style.flexDirection = "row";
      bar.style.justifyContent = "left";
      const progress = bar.getElementsByTagName("progress")[0];
      const progressTitle = refAnimationFrame(progress, (x) => x.title);
      createFragmentApp(() => createVNode("span", null, [progressTitle.value])).appendTo(bar);
    });
  });
}
function init() {
  tiles.observe("BS", onTileReady);
}
features.add(import.meta.url, init, "BS: Adds a workforce satisfaction percentage label to the satisfaction progress bar.");
