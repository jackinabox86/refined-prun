import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import { shipsStore } from "../../../infrastructure/prun-api/data/ships.js";
import { percent0 } from "../../../utils/format.js";
import coloredValue from "../../../infrastructure/prun-ui/css/colored-value.module.css.js";
import { defineComponent, computed, openBlock, createElementBlock, createCommentVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ShipCondition",
  props: {
    id: {}
  },
  setup(__props) {
    const ship = computed(() => shipsStore.getById(__props.id));
    const condition = computed(() => Math.floor((ship.value?.condition ?? 1) * 100) / 100);
    const labelClass = computed(() => {
      if (condition.value <= 0.79) {
        return C.ColoredValue.negative;
      }
      if (condition.value <= 0.81) {
        return coloredValue.warning;
      }
      return C.ColoredValue.positive;
    });
    return (_ctx, _cache) => {
      return unref(ship) ? (openBlock(), createElementBlock("span", {
        key: 0,
        class: normalizeClass(unref(labelClass))
      }, " " + toDisplayString(unref(percent0)(unref(condition))), 3)) : createCommentVNode("", true);
    };
  }
});
export {
  _sfc_main as default
};
