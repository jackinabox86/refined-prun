import { subscribe } from "../../../utils/subscribe-async-generator.js";
import { $$ } from "../../../utils/select-dom.js";
import { createFragmentApp } from "../../../utils/vue-fragment-app.js";
import tiles from "../../../infrastructure/prun-ui/tiles.js";
import features from "../../feature-registry.js";
import { refPrunId } from "../../../infrastructure/prun-ui/attributes.js";
import _sfc_main from "./ShipCondition.vue.js";
import { reactive } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, "tr"), (row) => {
    createFragmentApp(
      _sfc_main,
      reactive({
        id: refPrunId(row)
      })
    ).appendTo(row.children[1]);
  });
}
function init() {
  tiles.observe(["FLT", "FLTS", "FLTP"], onTileReady);
}
features.add(import.meta.url, init, 'FLT: Adds a ship condition label to the "Name" column.');
