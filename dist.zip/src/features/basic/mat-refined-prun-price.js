import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $, $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { createFragmentApp } from "../../utils/vue-fragment-app.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { materialsStore } from "../../infrastructure/prun-api/data/materials.js";
import { PrunI18N } from "../../infrastructure/prun-ui/i18n.js";
import _sfc_main from "../../components/forms/Passive.vue.js";
import { getPrice } from "../../infrastructure/fio/cx.js";
import { fixed02, fixed0, fixed01, formatCurrency } from "../../utils/format.js";
import { computed, createVNode } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function onTileReady(tile) {
  const parameter = tile.parameter;
  const material = materialsStore.getByTicker(parameter);
  const volumeLabelText = PrunI18N["MaterialInformation.label.volume"]?.[0]?.value;
  subscribe($$(tile.anchor, C.FormComponent.containerPassive), async (container) => {
    const label = await $(container, "label");
    if (label.textContent !== volumeLabelText) {
      return;
    }
    const price = computed(() => {
      const price2 = getPrice(material?.ticker);
      if (price2 === void 0) {
        return "--";
      }
      let format = fixed02;
      if (price2 >= 100) {
        format = fixed0;
      } else if (price2 >= 10) {
        format = fixed01;
      }
      return formatCurrency(price2, format);
    });
    createFragmentApp(() => createVNode(_sfc_main, {
      "label": "Refined PrUn Price"
    }, {
      default: () => [createVNode("span", null, [price.value])]
    })).after(container);
  });
}
function init() {
  tiles.observe("MAT", onTileReady);
}
features.add(import.meta.url, init, 'MAT: Adds a "Refined PrUn Price" row.');
