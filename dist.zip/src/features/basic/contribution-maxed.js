import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$, $ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { clickElement } from "../../util.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, C.Contribution.contribute), async (contribute) => {
    const table = contribute.previousElementSibling;
    if (!table) {
      return;
    }
    subscribe($$(table, "rc-slider"), async (slider) => {
      if (slider.classList.contains("rc-slider-disabled")) {
        return;
      }
      const mark = await $(slider, "rc-slider-mark");
      await clickElement(mark.lastElementChild);
    });
  });
}
function init() {
  tiles.observe(["COGCU", "POPID"], onTileReady);
}
features.add(
  import.meta.url,
  init,
  "Automatically maxes the contribution sliders in CoGC and population upkeep tiles."
);
