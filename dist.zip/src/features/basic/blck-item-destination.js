import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $, $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { createFragmentApp } from "../../utils/vue-fragment-app.js";
import features from "../feature-registry.js";
import { contractsStore } from "../../infrastructure/prun-api/data/contracts.js";
import { getDestinationFullName } from "../../infrastructure/prun-api/data/addresses.js";
import { refPrunId } from "../../infrastructure/prun-ui/attributes.js";
import { watchUntil } from "../../utils/watch.js";
import { createVNode } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function init() {
  subscribe($$(document, C.ColoredIcon.container), async (container) => {
    const label = await $(container, C.ColoredIcon.label);
    if (label.textContent !== "BLCK") {
      return;
    }
    const id = refPrunId(container);
    await watchUntil(() => !!id.value);
    const destination = contractsStore.getDestinationByShipmentId(id.value);
    const name = getDestinationFullName(destination);
    if (name) {
      createFragmentApp(() => createVNode("span", {
        "class": [C.ColoredIcon.subLabel, C.type.typeVerySmall]
      }, [name])).after(label);
    }
  });
}
features.add(import.meta.url, init, "Adds a destination address to BLCK items.");
