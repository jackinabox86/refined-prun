import { $ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { createFragmentApp } from "../../utils/vue-fragment-app.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import TileControlsButton from "../../components/TileControlsButton.vue.js";
import { computedTileState, getTileState as getTileState$1 } from "../../store/user-data-tiles.js";
import { watchEffectWhileNodeAlive } from "../../utils/watch.js";
import css from "../../utils/css-utils.module.css.js";
import fa from "../../utils/font-awesome.module.css.js";
import { createVNode, Fragment, computed } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function getTileState(tile) {
  return computed(() => getTileState$1(tile));
}
async function onTileReady(tile) {
  const tileContextControls = await $(tile.frame, C.ContextControls.container);
  const isMinimized = computedTileState(getTileState(tile), "minimizeContextControls", false);
  watchEffectWhileNodeAlive(tile.anchor, () => {
    tileContextControls.classList.toggle(css.hidden, isMinimized.value);
  });
  const tileControls = await $(tile.frame, C.TileFrame.controls);
  createFragmentApp(() => isMinimized.value ? createVNode(TileControlsButton, {
    "icon": "",
    "marginTop": 4,
    "onClick": () => isMinimized.value = false
  }, null) : null).prependTo(tileControls);
  createFragmentApp(() => createVNode(Fragment, null, [createVNode("div", {
    "class": [C.ContextControls.item, C.fonts.fontRegular, C.type.typeSmall],
    "onClick": () => {
      isMinimized.value = true;
    }
  }, [createVNode("i", {
    "class": [fa.solid]
  }, [""])]), createVNode("div", {
    "style": {
      flexGrow: "1"
    }
  }, null)])).prependTo(tileContextControls);
}
function init() {
  tiles.observeAll(onTileReady);
}
features.add(import.meta.url, init, "Adds buttons to hide and show context controls for tiles containing them.");
