import { createFragmentApp } from "../../../utils/vue-fragment-app.js";
import { applyCssRule } from "../../../infrastructure/prun-ui/refined-prun-css.js";
import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import { subscribe } from "../../../utils/subscribe-async-generator.js";
import { $$ } from "../../../utils/select-dom.js";
import features from "../../feature-registry.js";
import css from "../../../utils/css-utils.module.css.js";
import link from "../../../infrastructure/prun-ui/css/link.module.css.js";
import $style from "./sidebar-contracts-details.module.css.js";
import ContractPartnerName from "./ContractPartnerName.vue.js";
import { refTextContent } from "../../../utils/reactive-dom.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import { reactive } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
function onContractIdReady(id) {
  id.addEventListener("click", (e) => {
    void showBuffer(`CONT ${id.textContent}`);
    e.preventDefault();
    e.stopPropagation();
  });
  createFragmentApp(
    ContractPartnerName,
    reactive({
      contractLocalId: refTextContent(id)
    })
  ).after(id);
}
function init() {
  applyCssRule(`.${C.Sidebar.contract} .${C.Link.link}:last-child`, css.hidden);
  applyCssRule(`.${C.Sidebar.contractId}`, link.link);
  applyCssRule(`.${C.Sidebar.contractId}`, $style.contractId);
  subscribe($$(document, C.Sidebar.contractId), onContractIdReady);
}
features.add(
  import.meta.url,
  init,
  "Adds a partner name to contracts in the sidebar on the right."
);
