import { subscribe } from "../../utils/subscribe-async-generator.js";
import { _$$, $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { fixed02 } from "../../utils/format.js";
import { getInvStore } from "../../core/store-id.js";
import { createReactiveSpan } from "../../utils/reactive-element.js";
import { computed } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function onTileReady(tile) {
  const store = computed(() => getInvStore(tile.parameter));
  const [weightIndex, volumeIndex] = tile.command === "SHPI" ? [0, 1] : [1, 2];
  subscribe($$(tile.anchor, C.StoreView.column), (column) => {
    const capacities = _$$(column, C.StoreView.capacity);
    if (capacities.length < 2) {
      return;
    }
    const weightText = computed(
      () => store.value ? ` (${fixed02(store.value.weightCapacity - store.value.weightLoad)}t)` : void 0
    );
    const weightSpan = createReactiveSpan(capacities[weightIndex], weightText);
    weightSpan.style.whiteSpace = "pre";
    capacities[weightIndex].appendChild(weightSpan);
    const volumeText = computed(
      () => store.value ? ` (${fixed02(store.value.volumeCapacity - store.value.volumeLoad)}m³)` : void 0
    );
    const volumeSpan = createReactiveSpan(capacities[volumeIndex], volumeText);
    volumeSpan.style.whiteSpace = "pre";
    capacities[volumeIndex].appendChild(volumeSpan);
  });
}
function init() {
  tiles.observe(["INV", "SHPI"], onTileReady);
}
features.add(
  import.meta.url,
  init,
  "INV/SHPI: Shows the remaining weight and volume capacity of the selected store in INV and SHPI"
);
