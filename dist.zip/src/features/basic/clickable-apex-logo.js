import { applyCssRule } from "../../infrastructure/prun-ui/refined-prun-css.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$ } from "../../utils/select-dom.js";
import features from "../feature-registry.js";
import $style from "./clickable-apex-logo.module.css.js";
import { companyStore } from "../../infrastructure/prun-api/data/company.js";
import { showBuffer } from "../../infrastructure/prun-ui/buffers.js";
function init() {
  applyCssRule(`.${C.Frame.logo}`, $style.logo);
  subscribe($$(document, C.Frame.logo), (logo) => {
    logo.addEventListener("click", (e) => {
      void showBuffer(`CO ${companyStore.value?.code}`);
      e.preventDefault();
      e.stopPropagation();
    });
  });
}
features.add(
  import.meta.url,
  init,
  "Makes the APEX logo clickable and leading to the user company info screen."
);
