import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { refTextContent } from "../../utils/reactive-dom.js";
import { shipsStore } from "../../infrastructure/prun-api/data/ships.js";
import { flightsStore } from "../../infrastructure/prun-api/data/flights.js";
import { formatEta } from "../../utils/format.js";
import { timestampEachMinute } from "../../utils/dayjs.js";
import { createReactiveSpan } from "../../utils/reactive-element.js";
import { keepLast } from "../../utils/keep-last.js";
import { refPrunId } from "../../infrastructure/prun-ui/attributes.js";
import { flightPlansStore } from "../../infrastructure/prun-api/data/flight-plans.js";
import { computed } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function onTileReady(tile) {
  const ship = computed(() => shipsStore.getByRegistration(tile.parameter));
  subscribe($$(tile.anchor, C.MissionPlan.table), (x) => onTableReady(x, ship));
}
function onTableReady(table, ship) {
  const planId = refPrunId(table);
  subscribe($$(table, "tr"), (x) => onRowReady(x, ship, planId));
}
function onRowReady(row, ship, planId) {
  const firstColumn = refTextContent(row.children[0]);
  const arrival = computed(
    () => getFlightSegmentArrival(ship.value, firstColumn.value, planId.value)
  );
  const eta = computed(
    () => arrival.value !== void 0 ? ` (${formatEta(timestampEachMinute.value, arrival.value)})` : void 0
  );
  const span = createReactiveSpan(row, eta);
  keepLast(row, () => row.children[3], span);
}
function getFlightSegmentArrival(ship, index, planId) {
  if (!ship || index === null) {
    return void 0;
  }
  let segments;
  if (ship.flightId) {
    const flight = flightsStore.getById(ship.flightId);
    if (!flight) {
      return void 0;
    }
    segments = flight.segments;
  } else {
    const plan = flightPlansStore.getById(planId);
    if (!plan) {
      return void 0;
    }
    segments = plan.segments;
  }
  const segmentId = index !== "" ? parseInt(index, 10) : segments.length - 1;
  if (isFinite(segmentId) && segmentId < segments.length) {
    return segments[segmentId].arrival.timestamp;
  }
  return void 0;
}
function init() {
  tiles.observe("SFC", onTileReady);
}
features.add(import.meta.url, init, 'SFC: Adds an arrival date to the "Duration" column.');
