import { subscribe } from "../../../utils/subscribe-async-generator.js";
import { $$ } from "../../../utils/select-dom.js";
import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import { createFragmentApp } from "../../../utils/vue-fragment-app.js";
import tiles from "../../../infrastructure/prun-ui/tiles.js";
import { applyCssRule } from "../../../infrastructure/prun-ui/refined-prun-css.js";
import features from "../../feature-registry.js";
import $style from "./cxpc-chart-types.module.css.js";
import { watchEffectWhileNodeAlive } from "../../../utils/watch.js";
import { cxobStore } from "../../../infrastructure/prun-api/data/cxob.js";
import { cxpcStore } from "../../../infrastructure/prun-api/data/cxpc.js";
import { COMEX_BROKER_PRICES } from "../../../infrastructure/prun-api/client-messages.js";
import { dispatchClientPrunMessage } from "../../../infrastructure/prun-api/prun-api-listener.js";
import { userData } from "../../../store/user-data.js";
import _sfc_main from "./SettingsGroup.vue.js";
import { computedTileState } from "../../../store/user-data-tiles.js";
import { getTileState } from "./tile-state.js";
import { computed } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { reactive } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
function onTileReady(tile) {
  const ticker = tile.parameter;
  const broker = computed(() => cxobStore.getByTicker(ticker));
  const cxpc = computed(() => cxpcStore.getById(broker.value?.id));
  const chartType = computedTileState(getTileState(tile), "chartType", void 0);
  chartType.value ??= userData.settings.defaultChartType;
  subscribe($$(tile.anchor, C.ChartContainer.container), (container) => {
    watchEffectWhileNodeAlive(container, () => {
      if (!cxpc.value) {
        return;
      }
      switch (chartType.value) {
        case "SMOOTH": {
          smooth(cxpc.value);
          break;
        }
        case "ALIGNED": {
          aligned(cxpc.value);
          break;
        }
        case "RAW": {
          raw(cxpc.value);
          break;
        }
      }
    });
  });
  subscribe($$(tile.anchor, C.ChartContainer.settings), (settings) => {
    createFragmentApp(
      _sfc_main,
      reactive({
        chartType,
        onChange: (type) => {
          chartType.value = type;
        }
      })
    ).appendTo(settings);
  });
}
function smooth(data) {
  const payload = { ...data, prices: [] };
  for (const interval of data.prices) {
    const intervalCopy = { ...interval };
    payload.prices.push(intervalCopy);
    if (interval.prices.length < 2) {
      continue;
    }
    const ha = [];
    for (let i = 0; i < interval.prices.length; i++) {
      const c = interval.prices[i];
      const haClose = (c.open + c.high + c.low + c.close) / 4;
      const haOpen = i === 0 ? (c.open + c.close) / 2 : (ha[i - 1].open + ha[i - 1].close) / 2;
      const haHigh = Math.max(c.high, haOpen, haClose);
      const haLow = Math.min(c.low, haOpen, haClose);
      ha.push({ ...c, open: haOpen, high: haHigh, low: haLow, close: haClose });
    }
    intervalCopy.prices = ha;
  }
  const messsage = COMEX_BROKER_PRICES(payload);
  dispatchClientPrunMessage(messsage);
}
function aligned(data) {
  const payload = { ...data, prices: [] };
  data = structuredClone(data);
  for (const interval of data.prices) {
    const intervalCopy = { ...interval };
    payload.prices.push(intervalCopy);
    if (interval.prices.length < 2) {
      continue;
    }
    const vwap = [];
    vwap.push({ ...interval.prices[0] });
    let previous = vwap[0];
    for (let i = 1; i < interval.prices.length; i++) {
      const current = { ...interval.prices[i] };
      vwap.push(current);
      const average = (current.open * current.volume + previous.close * previous.volume) / (current.volume + previous.volume);
      previous.close = average;
      current.open = average;
      previous = current;
    }
    intervalCopy.prices = vwap;
  }
  const messsage = COMEX_BROKER_PRICES(payload);
  dispatchClientPrunMessage(messsage);
}
function raw(data) {
  const messsage = COMEX_BROKER_PRICES(data);
  dispatchClientPrunMessage(messsage);
}
function init() {
  tiles.observe("CXPC", onTileReady);
  applyCssRule("CXPC", `.${C.ChartContainer.settings}`, $style.settings);
}
features.add(import.meta.url, init, 'CXPC: Adds "Smooth" and "Aligned" chart types.');
