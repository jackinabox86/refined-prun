import features from "../feature-registry.js";
import { setInboundShipInventoryEnabled } from "../../core/burn.js";
function init() {
  setInboundShipInventoryEnabled(true);
}
features.add(
  import.meta.url,
  init,
  "BURN: Counts in-flight ship inventory in the days-left calculation."
);
