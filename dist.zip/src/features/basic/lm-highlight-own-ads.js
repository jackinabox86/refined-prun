import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $, $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import $style from "./lm-highlight-own-ads.module.css.js";
import { companyStore } from "../../infrastructure/prun-api/data/company.js";
import { getPrunId } from "../../infrastructure/prun-ui/attributes.js";
import { localAdsStore } from "../../infrastructure/prun-api/data/local-ads.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, C.LocalMarket.item), async (item) => {
    const container = await $(item, C.CommodityAd.container);
    const id = getPrunId(container);
    const ad = localAdsStore.getById(id);
    if (ad?.creator.id === companyStore.value?.id) {
      item.classList.add($style.ownAd);
    }
  });
}
function init() {
  tiles.observe("LM", onTileReady);
}
features.add(import.meta.url, init, "LM: Highlights own ads.");
