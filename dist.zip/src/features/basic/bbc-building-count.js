import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { createFragmentApp } from "../../utils/vue-fragment-app.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import css from "../../utils/css-utils.module.css.js";
import { sitesStore } from "../../infrastructure/prun-api/data/sites.js";
import { computed, createVNode } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function onTileReady(tile) {
  const naturalId = tile.parameter;
  const totals = computed(() => {
    const totals2 = /* @__PURE__ */ new Map();
    const buildings = sitesStore.getByPlanetNaturalId(naturalId)?.platforms ?? [];
    for (const building of buildings) {
      const ticker = building.module.reactorTicker;
      totals2.set(ticker, (totals2.get(ticker) ?? 0) + 1);
    }
    return totals2;
  });
  subscribe($$(tile.anchor, C.BuildingIcon.tickerContainer), (tickerContainer) => {
    const ticker = tickerContainer.textContent;
    if (!ticker) {
      return;
    }
    const count = computed(() => totals.value.get(ticker) ?? 0);
    const isVisible = computed(() => count.value > 0);
    const hiddenClass = computed(() => isVisible.value ? void 0 : css.hidden);
    createFragmentApp(() => createVNode("div", {
      "class": [C.MaterialIcon.indicatorContainer, hiddenClass.value]
    }, [createVNode("div", {
      "class": [C.MaterialIcon.indicator, C.MaterialIcon.neutral, C.MaterialIcon.typeVerySmall]
    }, [totals.value.get(ticker)])])).appendTo(tickerContainer);
  });
}
function init() {
  tiles.observe("BBC", onTileReady);
}
features.add(import.meta.url, init, "BBC: Adds a building count label to the building icons.");
