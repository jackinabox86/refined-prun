import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$, _$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { applyCssRule } from "../../infrastructure/prun-ui/refined-prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { refPrunId } from "../../infrastructure/prun-ui/attributes.js";
import { productionStore } from "../../infrastructure/prun-api/data/production.js";
import { formatEta } from "../../utils/format.js";
import { timestampEachMinute } from "../../utils/dayjs.js";
import { createReactiveDiv } from "../../utils/reactive-element.js";
import { keepLast } from "../../utils/keep-last.js";
import $style from "./prodq-order-eta.module.css.js";
import { calcCompletionDate } from "../../core/production-line.js";
import { computed } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, C.ProductionQueue.table), (table) => {
    subscribe($$(table, "tr"), (order) => {
      if (_$(order, "th")) {
        return;
      }
      onOrderSlotReady(order.children[5], order, tile.parameter);
    });
  });
}
function onOrderSlotReady(slot, order, siteId) {
  const orderId = refPrunId(order);
  const completion = computed(() => {
    const line = productionStore.getById(siteId);
    for (const order2 of line?.orders ?? []) {
      if (order2.id === orderId.value) {
        return calcCompletionDate(line, order2);
      }
    }
    return void 0;
  });
  const eta = computed(() => {
    return completion.value !== void 0 ? `(${formatEta(timestampEachMinute.value, completion.value)})` : void 0;
  });
  const div = createReactiveDiv(slot, eta);
  keepLast(slot, () => slot, div);
}
function init() {
  applyCssRule("PRODQ", `.${C.ProductionQueue.table}`, $style.table);
  tiles.observe("PRODQ", onTileReady);
}
features.add(import.meta.url, init, "PRODQ: Adds a finish ETA label to orders.");
