import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$, _$$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { watchEffectWhileNodeAlive } from "../../utils/watch.js";
import { refPrunId } from "../../infrastructure/prun-ui/attributes.js";
import { sitesStore } from "../../infrastructure/prun-api/data/sites.js";
import { workforcesStore } from "../../infrastructure/prun-api/data/workforces.js";
import { PrunI18N } from "../../infrastructure/prun-ui/i18n.js";
import { isEmpty } from "../../../npm/ts-extras@0.15.0-ts-extras-is-empty.js";
import { computed } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function onTileReady(tile) {
  if (!tile.parameter) {
    return;
  }
  subscribe($$(tile.anchor, C.Site.container), () => {
    subscribe($$(tile.anchor, "tr"), (row) => {
      if (isEmpty(_$$(row, "td"))) {
        return;
      }
      const levelId = refPrunId(row);
      const shouldHideRow = computed(() => {
        const site = sitesStore.getByPlanetNaturalId(tile.parameter);
        const workforce = workforcesStore.getById(site?.siteId)?.workforces.find((x) => x.level === levelId.value);
        return workforce && workforce.capacity < 1 && workforce.required < 1 && workforce.population < 1;
      });
      watchEffectWhileNodeAlive(row, () => row.style.display = shouldHideRow.value ? "none" : "");
    });
  });
}
function init() {
  const localized = PrunI18N["SiteWorkforces.table.currentWorkforce"]?.[0];
  if (localized) {
    localized.value = localized.value.replace("Current Workforce", "Current");
  }
  tiles.observe("BS", onTileReady);
}
features.add(import.meta.url, init, "BS: Hides workforce rows with zero current workforce.");
