import { subscribe } from "../../utils/subscribe-async-generator.js";
import { _$$, $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { createFragmentApp } from "../../utils/vue-fragment-app.js";
import { applyCssRule } from "../../infrastructure/prun-ui/refined-prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import css from "../../utils/css-utils.module.css.js";
import $style from "./bbl-collapsible-categories.module.css.js";
import { ref } from "../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { computed, createVNode } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, C.SectionList.container), (container) => {
    for (const divider of _$$(container, C.SectionList.divider)) {
      const enabled = ref(container.firstChild !== divider);
      divider.addEventListener("click", (e) => {
        enabled.value = !enabled.value;
        e.stopPropagation();
        e.preventDefault();
      });
      const indicatorClass = computed(() => ({
        [C.RadioItem.indicator]: true,
        [C.RadioItem.active]: enabled.value,
        [C.effects.shadowPrimary]: enabled.value
      }));
      createFragmentApp(() => createVNode("div", {
        "class": indicatorClass.value
      }, null)).prependTo(divider);
    }
  });
}
function init() {
  applyCssRule("BBL", `.${C.SectionList.divider}:not(:has(.${C.RadioItem.active})) + div`, css.hidden);
  applyCssRule("BBL", `.${C.SectionList.divider}`, $style.divider);
  tiles.observe("BBL", onTileReady);
}
features.add(import.meta.url, init, 'BBL: Makes categories collapsible and collapses the "Infrastructure" category by default.');
