import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import { createFragmentApp } from "../../../utils/vue-fragment-app.js";
import features from "../../feature-registry.js";
import { showBuffer } from "../../../infrastructure/prun-ui/buffers.js";
import { userData } from "../../../store/user-data.js";
import MarketMenu from "./MarketMenu.vue.js";
import { reactive } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { nextTick } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
let clickOutsideListener = null;
let isOpen = false;
let menuElement = null;
let materialSelector;
function setLocation(event) {
  if (menuElement === null) {
    return;
  }
  const parentRect = menuElement.parentElement.getBoundingClientRect();
  const menuRect = menuElement.getBoundingClientRect();
  if (event.clientX + menuRect.width > parentRect.right) {
    store.menuStyle.left = (parentRect.right - menuRect.width).toString() + "px";
  } else {
    store.menuStyle.left = event.clientX.toString() + "px";
  }
  if (event.clientY + menuRect.height > parentRect.bottom) {
    store.menuStyle.top = (event.clientY - menuRect.height).toString() + "px";
  } else {
    store.menuStyle.top = event.clientY.toString() + "px";
  }
}
const store = reactive({
  materialID: "",
  menuStyle: {
    display: "none",
    left: "0px",
    top: "0px"
  },
  async showMenu(event, ticker) {
    if (clickOutsideListener !== null) {
      document.removeEventListener("click", clickOutsideListener);
      clickOutsideListener = null;
    }
    isOpen = true;
    this.materialID = ticker;
    this.menuStyle.display = "block";
    await nextTick();
    setLocation(event);
    clickOutsideListener = (e) => {
      if (menuElement !== null && !menuElement.contains(e.target)) {
        store.hideMenu();
      }
    };
    document.addEventListener("click", clickOutsideListener);
  },
  hideMenu() {
    if (!isOpen) {
      return;
    }
    isOpen = false;
    this.menuStyle.display = "none";
    if (clickOutsideListener !== null) {
      document.removeEventListener("click", clickOutsideListener);
      clickOutsideListener = null;
    }
  },
  showBuffer(cmd) {
    this.hideMenu();
    if (cmd === "CXM") {
      return showBuffer(`CXM ${this.materialID}`);
    } else if (["CXP", "CXPC", "CXPO", "CXOB"].includes(cmd)) {
      return showBuffer(`${cmd} ${this.materialID}.${userData.settings.contextMenuExchange}`);
    }
    return;
  }
});
async function init() {
  materialSelector = `.${C.ColoredIcon.container}`;
  const container = document.getElementById("container");
  if (container?.parentElement) {
    const componentInstance = createFragmentApp(MarketMenu).appendTo(container);
    menuElement = componentInstance.$el;
  }
  document.addEventListener("contextmenu", (event) => {
    const target = event.target.closest(materialSelector);
    if (target !== null) {
      event.preventDefault();
      store.showMenu(event, target.textContent ?? "");
      return;
    }
    if (isOpen) {
      store.hideMenu();
    }
  });
}
features.add(
  import.meta.url,
  init,
  "Right click any material to quickly see material market buttons."
);
export {
  store
};
