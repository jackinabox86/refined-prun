import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import _sfc_main$1 from "../../../components/PrunButton.vue.js";
import { userData } from "../../../store/user-data.js";
import { store } from "./market-contextmenu.js";
import { defineComponent, openBlock, createElementBlock, createElementVNode as createBaseVNode, Fragment, renderList, createVNode, withCtx, createTextVNode, createCommentVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass, normalizeStyle } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "MarketMenu",
  setup(__props) {
    const exchanges = ["AI1", "CI1", "CI2", "IC1", "NC1", "NC2"];
    const buttons = [
      ["Info", "CXP"],
      ["Chart", "CXPC"],
      ["Orders", "CXOB"],
      ["Trade", "CXPO"],
      ["CXM", "CXM"]
    ];
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        id: "market_contextmenu",
        class: normalizeClass(_ctx.$style.contextMenu),
        style: normalizeStyle(unref(store).menuStyle)
      }, [
        unref(store).materialID ? (openBlock(), createElementBlock("div", _hoisted_1, [
          createBaseVNode("div", null, [
            (openBlock(), createElementBlock(Fragment, null, renderList(buttons, (cmd) => {
              return createVNode(_sfc_main$1, {
                key: cmd[1],
                dark: true,
                class: normalizeClass(_ctx.$style.prunButton),
                onClick: ($event) => unref(store).showBuffer(cmd[1])
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(cmd[0]), 1)
                ]),
                _: 2
              }, 1032, ["class", "onClick"]);
            }), 64))
          ]),
          createBaseVNode("div", null, [
            createBaseVNode("div", {
              class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).Frame.toggle, _ctx.$style.exchangeHover])
            }, [
              createBaseVNode("span", {
                class: normalizeClass([
                  ("C" in _ctx ? _ctx.C : unref(C)).Frame.toggleLabel,
                  ("C" in _ctx ? _ctx.C : unref(C)).type.typeRegular,
                  ("C" in _ctx ? _ctx.C : unref(C)).fonts.fontRegular,
                  _ctx.$style.exchangeSelect
                ])
              }, toDisplayString(unref(userData).settings.contextMenuExchange), 3),
              createBaseVNode("span", {
                class: normalizeClass([
                  ("C" in _ctx ? _ctx.C : unref(C)).Frame.toggleLabel,
                  ("C" in _ctx ? _ctx.C : unref(C)).type.typeRegular,
                  ("C" in _ctx ? _ctx.C : unref(C)).fonts.fontRegular,
                  _ctx.$style.exchangeIcon
                ])
              }, "🞂", 2),
              createBaseVNode("div", {
                class: normalizeClass([_ctx.$style.exchangeList, _ctx.$style.contextMenu])
              }, [
                (openBlock(), createElementBlock(Fragment, null, renderList(exchanges, (exchange) => {
                  return createVNode(_sfc_main$1, {
                    key: exchange,
                    dark: unref(userData).settings.contextMenuExchange !== exchange,
                    primary: unref(userData).settings.contextMenuExchange === exchange,
                    class: normalizeClass(_ctx.$style.prunButton),
                    onClick: ($event) => unref(userData).settings.contextMenuExchange = exchange
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(exchange), 1)
                    ]),
                    _: 2
                  }, 1032, ["dark", "primary", "class", "onClick"]);
                }), 64))
              ], 2)
            ], 2)
          ])
        ])) : createCommentVNode("", true)
      ], 6);
    };
  }
});
export {
  _sfc_main as default
};
