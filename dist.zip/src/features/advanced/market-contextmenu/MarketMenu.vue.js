import _sfc_main from "./MarketMenu.vue2.js";
import style0 from "./MarketMenu.vue3.js";
import _export_sfc from "../../../../virtual/plugin-vue_export-helper.js";
const cssModules = {
  "$style": style0
};
const MarketMenu = /* @__PURE__ */ _export_sfc(_sfc_main, [["__cssModules", cssModules]]);
export {
  MarketMenu as default
};
