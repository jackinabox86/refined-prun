import { $$, $ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { subscribe } from "../../utils/subscribe-async-generator.js";
import features from "../feature-registry.js";
import css from "../../utils/css-utils.module.css.js";
import { balancesStore } from "../../infrastructure/prun-api/data/balances.js";
import { watchEffectWhileNodeAlive } from "../../utils/watch.js";
async function onSidebarLineReady(sidebarLine) {
  const currencyCodeElement = await $(sidebarLine, C.Sidebar.currencyCode);
  const currencyCode = currencyCodeElement.textContent?.trim();
  if (!currencyCode) {
    return;
  }
  watchEffectWhileNodeAlive(sidebarLine, () => {
    const amount = balancesStore.all.value?.find((x) => x.currency === currencyCode)?.amount;
    sidebarLine.classList.toggle(css.hidden, amount === 0);
  });
}
function init() {
  subscribe($$(document, C.Sidebar.sidebarLine), onSidebarLineReady);
}
features.add(import.meta.url, init, "Hides currencies with zero balance in the right sidebar.");
