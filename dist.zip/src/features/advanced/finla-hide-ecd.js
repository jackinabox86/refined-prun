import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$, _$$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { refTextContent } from "../../utils/reactive-dom.js";
import { watchEffectWhileNodeAlive } from "../../utils/watch.js";
import { observeDescendantListChanged } from "../../utils/mutation-observer.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, C.LiquidAssetsPanel.row), (row) => {
    const currency = refTextContent(row.children[0]);
    watchEffectWhileNodeAlive(row, () => {
      row.style.display = currency.value === "ECD" ? "none" : "";
    });
  });
  subscribe($$(tile.anchor, "tbody"), (tbody) => {
    observeDescendantListChanged(tbody, () => {
      const rows = _$$(tbody, "tr");
      for (const row of rows) {
        const currency = row.children[0].textContent;
        if (currency !== "ECD") {
          continue;
        }
        if (row !== tbody.lastChild) {
          tbody.appendChild(row);
        }
        return;
      }
    });
  });
}
function init() {
  tiles.observe("FINLA", onTileReady);
}
features.add(import.meta.url, init, "FINLA: Hides the ECD row.");
