const fuelFlex = "rp-flt-flex-fuel__fuelFlex___d5289b4";
const $style = {
  fuelFlex
};
export {
  $style as default,
  fuelFlex
};
