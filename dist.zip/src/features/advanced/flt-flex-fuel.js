import { applyCssRule } from "../../infrastructure/prun-ui/refined-prun-css.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import features from "../feature-registry.js";
import $style from "./flt-flex-fuel.module.css.js";
function init() {
  applyCssRule(["FLT", "FLTS", "FLTP"], `.${C.ShipFuel.container}`, $style.fuelFlex);
}
features.add(
  import.meta.url,
  init,
  "FLT: Allows the fuel column layout to better use available space."
);
