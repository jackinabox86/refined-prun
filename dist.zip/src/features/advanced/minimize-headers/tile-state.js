import { getTileState as getTileState$1 } from "../../../store/user-data-tiles.js";
import { computed } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function getTileState(tile) {
  return computed(() => getTileState$1(tile));
}
export {
  getTileState
};
