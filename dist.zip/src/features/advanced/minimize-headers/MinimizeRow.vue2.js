import { C } from "../../../infrastructure/prun-ui/prun-css.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode } from "../../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "MinimizeRow",
  props: {
    isMinimized: { type: Boolean },
    onClick: { type: Function }
  },
  setup(__props) {
    const symbol = computed(() => __props.isMinimized ? "+" : "-");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).FormComponent.containerPassive, ("C" in _ctx ? _ctx.C : unref(C)).forms.passive, ("C" in _ctx ? _ctx.C : unref(C)).forms.formComponent])
      }, [
        createBaseVNode("label", {
          class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).FormComponent.label, ("C" in _ctx ? _ctx.C : unref(C)).fonts.fontRegular, ("C" in _ctx ? _ctx.C : unref(C)).type.typeRegular])
        }, "Minimize", 2),
        createBaseVNode("div", {
          class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).FormComponent.input, ("C" in _ctx ? _ctx.C : unref(C)).forms.input])
        }, [
          createBaseVNode("div", null, [
            createBaseVNode("div", {
              class: normalizeClass(_ctx.$style.minimize),
              onClick: _cache[0] || (_cache[0] = //@ts-ignore
              (...args) => _ctx.onClick && _ctx.onClick(...args))
            }, toDisplayString(unref(symbol)), 3)
          ])
        ], 2)
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
