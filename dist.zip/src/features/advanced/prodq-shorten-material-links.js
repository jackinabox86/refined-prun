import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import { createFragmentApp } from "../../utils/vue-fragment-app.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { productionStore } from "../../infrastructure/prun-api/data/production.js";
import PrunLink from "../../components/PrunLink.vue.js";
import { watchEffectWhileNodeAlive } from "../../utils/watch.js";
import { refPrunId } from "../../infrastructure/prun-ui/attributes.js";
import { createVNode, isVNode } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function _isSlot(s) {
  return typeof s === "function" || Object.prototype.toString.call(s) === "[object Object]" && !isVNode(s);
}
async function onTileReady(tile) {
  subscribe($$(tile.anchor, C.ProductionQueue.table), (table) => {
    subscribe($$(table, "tr"), (order) => {
      const prunId = refPrunId(order);
      watchEffectWhileNodeAlive(order, () => {
        const line = productionStore.getById(tile.parameter);
        const productionOrder = line?.orders.find((order2) => order2.id === prunId.value);
        if (productionOrder) {
          linkifyMaterialNames(order.children[3].children, productionOrder.inputs);
          linkifyMaterialNames(order.children[4].children, productionOrder.outputs);
        }
      });
    });
  });
}
function linkifyMaterialNames(elements, resources) {
  for (let i = 0; i < elements.length; i++) {
    const children = Array.from(elements[i].children);
    const materialName = children.length === 2 ? children[1] : children[0];
    materialName.textContent = "";
    const material = resources[i].material.ticker;
    createFragmentApp(() => createVNode(PrunLink, {
      "inline": true,
      "command": `MAT ${material}`
    }, _isSlot(material) ? material : {
      default: () => [material]
    })).appendTo(materialName);
  }
}
function init() {
  tiles.observe("PRODQ", onTileReady);
}
features.add(import.meta.url, init, "PRODQ: Shortens material full names into their ticker with a link.");
