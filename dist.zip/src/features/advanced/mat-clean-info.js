import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $, $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import css from "../../utils/css-utils.module.css.js";
import { PrunI18N } from "../../infrastructure/prun-ui/i18n.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, C.FormComponent.containerPassive), async (container) => {
    const label = await $(container, "label");
    hideField(container, label, "MaterialInformation.ticker");
    hideField(container, label, "MaterialInformation.resource");
  });
}
function hideField(container, label, localizedKey) {
  const localizedValue = PrunI18N[localizedKey]?.[0]?.value;
  if (label?.textContent === localizedValue) {
    container.classList.add(css.hidden);
  }
}
function init() {
  tiles.observe("MAT", onTileReady);
}
features.add(import.meta.url, init, 'MAT: Hides "Ticker" and "Natural resource" fields.');
