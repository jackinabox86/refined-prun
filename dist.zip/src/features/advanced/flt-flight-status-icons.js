import { applyCssRule } from "../../infrastructure/prun-ui/refined-prun-css.js";
import features from "../feature-registry.js";
import { PrunI18N } from "../../infrastructure/prun-ui/i18n.js";
import { shipStatusI18nIconReplacements } from "../../core/ship-status-icons.js";
import $style from "./flt-flight-status-icons.module.css.js";
function init() {
  for (const { key, icon } of shipStatusI18nIconReplacements) {
    PrunI18N[key] = [
      {
        type: 0,
        value: icon
      }
    ];
  }
  applyCssRule(["FLT", "FLTS", "FLTP"], `td:nth-child(4)`, $style.status);
}
features.add(import.meta.url, init, "FLT: Replaces the flight status text with arrow icons.");
