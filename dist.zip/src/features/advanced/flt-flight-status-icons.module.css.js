const status = "rp-flt-flight-status-icons__status___931730f";
const $style = {
  status
};
export {
  $style as default,
  status
};
