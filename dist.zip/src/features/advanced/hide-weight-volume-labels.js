import { applyCssRule } from "../../infrastructure/prun-ui/refined-prun-css.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import features from "../feature-registry.js";
import css from "../../utils/css-utils.module.css.js";
function init() {
  applyCssRule(`.${C.StoreView.name}`, css.hidden);
}
features.add(import.meta.url, init, 'Hides "Weight" and "Volume" labels in all inventories.');
