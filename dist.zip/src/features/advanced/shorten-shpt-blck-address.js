import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $, $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import features from "../feature-registry.js";
import { refPrunId } from "../../infrastructure/prun-ui/attributes.js";
import { contractsStore } from "../../infrastructure/prun-api/data/contracts.js";
import { getDestinationName } from "../../infrastructure/prun-api/data/addresses.js";
import { watchUntil } from "../../utils/watch.js";
function init() {
  subscribe($$(document, C.ColoredIcon.container), async (container) => {
    const label = await $(container, C.ColoredIcon.label);
    const subLabel = await $(container, C.ColoredIcon.subLabel);
    if (label.textContent !== "SHPT" && label.textContent !== "BLCK") {
      return;
    }
    const id = refPrunId(container);
    await watchUntil(() => !!id.value);
    const destination = contractsStore.getDestinationByShipmentId(id.value);
    const name = getDestinationName(destination);
    if (!name) {
      return;
    }
    subLabel.textContent = name;
  });
}
features.add(import.meta.url, init, "Shortens addresses in SHPT and BLCK items.");
