import { subscribe } from "../../utils/subscribe-async-generator.js";
import { _$$, $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { refPrunId } from "../../infrastructure/prun-ui/attributes.js";
import { storagesStore } from "../../infrastructure/prun-api/data/storage.js";
import { watchEffectWhileNodeAlive } from "../../utils/watch.js";
import { PrunI18N } from "../../infrastructure/prun-ui/i18n.js";
import { computed } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
const storeTypes = [
  "STORE",
  "SHIP_STORE",
  "STL_FUEL_STORE",
  "FTL_FUEL_STORE",
  "WAREHOUSE_STORE",
  "CONSTRUCTION_STORE",
  "UPKEEP_STORE",
  "VORTEX_FUEL_STORE"
];
function onTileReady(tile) {
  shortenFilterLabels(tile);
  shortenTableLabels(tile);
}
function shortenFilterLabels(tile) {
  const map = /* @__PURE__ */ new Map();
  for (const type of storeTypes) {
    map.set(getFullName(type), getShortName(type));
  }
  subscribe($$(tile.anchor, C.InventoriesListContainer.filter), async (filter) => {
    for (const label of _$$(filter, C.RadioItem.value)) {
      const type = label.textContent;
      if (type) {
        label.textContent = map.get(type) ?? type;
      }
    }
  });
}
function shortenTableLabels(tile) {
  const map = /* @__PURE__ */ new Map();
  for (const type of storeTypes) {
    map.set(type, getShortName(type));
  }
  subscribe($$(tile.anchor, "tr"), (row) => {
    const id = refPrunId(row);
    const name = computed(() => {
      const storage = storagesStore.getById(id.value);
      return storage ? map.get(storage?.type) : void 0;
    });
    watchEffectWhileNodeAlive(row, () => {
      const typeLabel = row.firstChild?.firstChild;
      if (typeLabel && name.value !== void 0) {
        typeLabel.textContent = name.value;
      }
    });
  });
}
function getFullName(type) {
  return PrunI18N[`StoreTypeLabel.${type}`]?.[0]?.value ?? type;
}
function getShortName(type) {
  return PrunI18N[`StoreTypeLabel.${type}_SHORT`]?.[0]?.value ?? type;
}
function init() {
  tiles.observe("INV", onTileReady);
}
features.add(import.meta.url, init, "INV: Shortens storage type names in the table and filters.");
