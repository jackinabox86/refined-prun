import { applyCssRule } from "../../infrastructure/prun-ui/refined-prun-css.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import features from "../feature-registry.js";
import css from "../../utils/css-utils.module.css.js";
function init() {
  applyCssRule(
    "BBL",
    `.${C.SectionList.section} .${C.SectionList.table} tr:nth-child(5)`,
    css.hidden
  );
}
features.add(import.meta.url, init, 'BBL: Hides the "Book value" row.');
