import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, C.Button.darkInline), (button) => {
    button.textContent = "vote";
  });
  subscribe($$(tile.anchor, C.Link.link), (link) => {
    if (link.textContent) {
      link.textContent = link.textContent.replace("Advertising Campaign: ", "").replace("Education Events: ", "");
    }
  });
}
function init() {
  tiles.observe("COGCPEX", onTileReady);
}
features.add(
  import.meta.url,
  init,
  'COGCPEX: Hides "Advertising Campaign:" and "Education Events:" parts of the campaign labels.'
);
