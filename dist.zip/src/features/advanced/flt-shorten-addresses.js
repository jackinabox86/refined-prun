import { subscribe } from "../../utils/subscribe-async-generator.js";
import { $$ } from "../../utils/select-dom.js";
import { C } from "../../infrastructure/prun-ui/prun-css.js";
import tiles from "../../infrastructure/prun-ui/tiles.js";
import features from "../feature-registry.js";
import { extractPlanetName } from "../../util.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, C.Link.link), (link) => {
    if (link.textContent) {
      link.textContent = extractPlanetName(link.textContent);
    }
  });
}
function init() {
  tiles.observe(["FLT", "FLTS", "FLTP"], onTileReady);
}
features.add(import.meta.url, init, 'FLT: Shortens addresses in "Location" and "Destination".');
