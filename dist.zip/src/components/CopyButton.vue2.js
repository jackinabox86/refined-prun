import _sfc_main from "./CopyButton.vue.js";
export {
  _sfc_main as default
};
