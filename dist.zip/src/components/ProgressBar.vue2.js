import { useCssModule } from "../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import { C } from "../infrastructure/prun-ui/prun-css.js";
import { defineComponent, computed, openBlock, createElementBlock } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass } from "../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = ["value", "max"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ProgressBar",
  props: {
    danger: { type: Boolean },
    good: { type: Boolean },
    max: {},
    value: {},
    warning: { type: Boolean }
  },
  setup(__props) {
    const $style = useCssModule();
    const primary = computed(() => !__props.good && !__props.warning && !__props.danger);
    const progressClass = computed(() => ({
      [C.ProgressBar.primary]: primary.value,
      [$style.good]: __props.good,
      [$style.warning]: __props.warning,
      [$style.danger]: __props.danger
    }));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("progress", {
        class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).ProgressBar.progress, unref(progressClass)]),
        value: _ctx.value,
        max: _ctx.max
      }, null, 10, _hoisted_1);
    };
  }
});
export {
  _sfc_main as default
};
