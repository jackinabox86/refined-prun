const container = "rp-BuildingIcon__container___aed8f37";
const large = "rp-BuildingIcon__large___28d41ad";
const medium = "rp-BuildingIcon__medium___1963246";
const small = "rp-BuildingIcon__small___f51840c";
const inline = "rp-BuildingIcon__inline___7c176ea";
const inlineTable = "rp-BuildingIcon__inlineTable___7f13280";
const style0 = {
  container,
  large,
  medium,
  small,
  inline,
  inlineTable
};
export {
  container,
  style0 as default,
  inline,
  inlineTable,
  large,
  medium,
  small
};
