import _sfc_main from "./NumericInput.vue.js";
export {
  _sfc_main as default
};
