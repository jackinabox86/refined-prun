import { C } from "../infrastructure/prun-ui/prun-css.js";
import _export_sfc from "../../virtual/plugin-vue_export-helper.js";
import { openBlock, createElementBlock, renderSlot } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass } from "../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = {};
function _sfc_render(_ctx, _cache) {
  return openBlock(), createElementBlock("span", {
    class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).InlineFlex.inlineFlex)
  }, [
    renderSlot(_ctx.$slots, "default")
  ], 2);
}
const InlineFlex = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  InlineFlex as default
};
