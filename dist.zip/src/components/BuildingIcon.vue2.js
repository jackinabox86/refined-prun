import { C } from "../infrastructure/prun-ui/prun-css.js";
import { useCssModule } from "../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import { showBuffer } from "../infrastructure/prun-ui/buffers.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, createCommentVNode } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = ["title"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "BuildingIcon",
  props: {
    amount: {},
    size: { default: "large" },
    ticker: {}
  },
  setup(__props) {
    const amountClasses = [
      C.MaterialIcon.indicator,
      C.MaterialIcon.neutral,
      C.MaterialIcon.typeVerySmall
    ];
    const $style = useCssModule();
    const containerClass = computed(() => ({
      [C.BuildingIcon.container]: true,
      [$style.container]: true,
      [$style.large]: !__props.size || __props.size === "large",
      [$style.medium]: __props.size === "medium",
      [$style.small]: __props.size === "small",
      [$style.inline]: __props.size === "inline",
      [$style.inlineTable]: __props.size === "inline-table"
    }));
    function onClick() {
      showBuffer(`BUI ${__props.ticker}`);
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(unref(containerClass)),
        title: _ctx.ticker,
        onClick
      }, [
        createBaseVNode("div", {
          class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).BuildingIcon.tickerContainer)
        }, [
          createBaseVNode("span", {
            class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).BuildingIcon.ticker)
          }, toDisplayString(_ctx.ticker), 3)
        ], 2),
        _ctx.amount ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).MaterialIcon.indicatorContainer])
        }, [
          createBaseVNode("div", {
            class: normalizeClass(amountClasses)
          }, toDisplayString(_ctx.amount), 1)
        ], 2)) : createCommentVNode("", true)
      ], 10, _hoisted_1);
    };
  }
});
export {
  _sfc_main as default
};
