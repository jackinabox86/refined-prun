import _sfc_main from "./ProgressBar.vue2.js";
import style0 from "./ProgressBar.vue3.js";
import _export_sfc from "../../virtual/plugin-vue_export-helper.js";
const cssModules = {
  "$style": style0
};
const ProgressBar = /* @__PURE__ */ _export_sfc(_sfc_main, [["__cssModules", cssModules]]);
export {
  ProgressBar as default
};
