import { useCssModule } from "../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import { C } from "../infrastructure/prun-ui/prun-css.js";
import ColoredIcon from "./ColoredIcon.vue.js";
import { materialsStore } from "../infrastructure/prun-api/data/materials.js";
import { showBuffer } from "../infrastructure/prun-ui/buffers.js";
import { getMaterialName } from "../infrastructure/prun-ui/i18n.js";
import { fixed0 } from "../utils/format.js";
import { defineComponent, computed, openBlock, createElementBlock, createVNode, createElementVNode as createBaseVNode, createCommentVNode } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "MaterialIcon",
  props: {
    amount: {},
    size: { default: "large" },
    ticker: {},
    warning: { type: Boolean }
  },
  setup(__props) {
    const $style = useCssModule();
    const material = computed(() => materialsStore.getByTicker(__props.ticker));
    const name = computed(() => getMaterialName(material.value) ?? "Unknown");
    const amountText = computed(() => {
      if (__props.amount === void 0) {
        return void 0;
      }
      if (__props.size === "medium" && __props.amount >= 1e5) {
        return fixed0(Math.round(__props.amount / 1e3)) + "k";
      }
      return fixed0(__props.amount);
    });
    const indicatorClass = computed(() => ({
      [C.ColoredValue.negative]: __props.warning,
      [$style.indicatorSmall]: __props.size === "medium"
    }));
    const onClick = () => showBuffer(`MAT ${__props.ticker.toUpperCase()}`);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).MaterialIcon.container, unref($style).container])
      }, [
        createVNode(ColoredIcon, {
          label: _ctx.ticker,
          title: unref(name),
          size: _ctx.size,
          onClick
        }, null, 8, ["label", "title", "size"]),
        unref(amountText) !== void 0 ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).MaterialIcon.indicatorContainer),
          onClick
        }, [
          createBaseVNode("div", {
            class: normalizeClass([
              ("C" in _ctx ? _ctx.C : unref(C)).MaterialIcon.indicator,
              ("C" in _ctx ? _ctx.C : unref(C)).MaterialIcon.neutral,
              ("C" in _ctx ? _ctx.C : unref(C)).MaterialIcon.typeVerySmall,
              unref(indicatorClass)
            ])
          }, toDisplayString(unref(amountText)), 3)
        ], 2)) : createCommentVNode("", true)
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
