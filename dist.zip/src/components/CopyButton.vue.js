import _sfc_main$1 from "./PrunButton.vue.js";
import { useClipboard } from "../hooks/use-clipboard.js";
import { defineComponent, openBlock, createBlock, withCtx, createTextVNode } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { unref } from "../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CopyButton",
  props: {
    copyFn: { type: Function }
  },
  setup(__props) {
    const { copied, copy } = useClipboard();
    async function onClick() {
      await copy(__props.copyFn());
    }
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$1, {
        primary: "",
        "data-tooltip-position": "top",
        "data-tooltip": unref(copied) ? "Copied!" : void 0,
        onClick
      }, {
        default: withCtx(() => [..._cache[0] || (_cache[0] = [
          createTextVNode(" COPY ", -1)
        ])]),
        _: 1
      }, 8, ["data-tooltip"]);
    };
  }
});
export {
  _sfc_main as default
};
