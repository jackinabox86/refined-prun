import { C } from "../infrastructure/prun-ui/prun-css.js";
import { defineComponent, openBlock, createElementBlock } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass } from "../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = ["data-tooltip", "data-tooltip-position"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Tooltip",
  props: {
    position: { default: "right" },
    tooltip: {}
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("span", {
        "data-tooltip": _ctx.tooltip,
        "data-tooltip-position": _ctx.position,
        class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).Tooltip.container)
      }, "ⓘ", 10, _hoisted_1);
    };
  }
});
export {
  _sfc_main as default
};
