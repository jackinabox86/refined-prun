import { C } from "../infrastructure/prun-ui/prun-css.js";
import { defineComponent, computed, openBlock, createElementBlock, renderSlot } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass } from "../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "RadioGroupContainer",
  props: {
    horizontal: { type: Boolean, default: false }
  },
  setup(__props) {
    const classes = computed(() => ({
      [C.RadioGroup.container]: true,
      [C.RadioGroup.horizontal]: __props.horizontal
    }));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(unref(classes))
      }, [
        renderSlot(_ctx.$slots, "default")
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
