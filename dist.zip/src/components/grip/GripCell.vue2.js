import { grip } from "./index.js";
import _sfc_main$1 from "./GripChar.vue.js";
import { defineComponent, openBlock, createElementBlock, createVNode } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass } from "../../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "GripCell",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("td", {
        class: normalizeClass([unref(grip).class, _ctx.$style.gripCell])
      }, [
        createVNode(_sfc_main$1, {
          class: normalizeClass(_ctx.$style.grip)
        }, null, 8, ["class"])
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
