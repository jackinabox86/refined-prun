import gripCss from "./grip.module.css.js";
import { ref } from "../../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { watch } from "../../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
const dragging = ref(false);
const draggable = {
  animation: 150,
  handle: `.${gripCss.grip}`,
  onStart: () => dragging.value = true,
  onEnd: () => dragging.value = false
};
watch(dragging, () => {
  document.documentElement.classList.toggle(gripCss.gripRoot, dragging.value);
});
const grip = {
  class: gripCss.grip,
  draggable
};
export {
  grip
};
