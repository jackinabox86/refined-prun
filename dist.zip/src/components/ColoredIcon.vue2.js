import { useCssModule } from "../../npm/@vue+runtime-dom@3.5.20-@vue-runtime-dom-runtime-dom.esm-bundler.js";
import { C } from "../infrastructure/prun-ui/prun-css.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, createCommentVNode } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeStyle, normalizeClass, toDisplayString } from "../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _hoisted_1 = ["title"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ColoredIcon",
  props: {
    background: {},
    color: {},
    subLabel: {},
    label: {},
    size: { default: "large" },
    title: {}
  },
  setup(__props) {
    const $style = useCssModule();
    const containerClass = computed(() => ({
      [$style.large]: __props.size === "large",
      [$style.medium]: __props.size === "medium",
      [$style.small]: __props.size === "small",
      [$style.inline]: __props.size === "inline",
      [$style.inlineTable]: __props.size === "inline-table"
    }));
    const isSubLabelVisible = computed(() => __props.subLabel && (__props.size === "large" || __props.size === "medium"));
    const subLabelClasses = [
      C.ColoredIcon.subLabel,
      C.type.typeVerySmall,
      {
        [$style.mediumSubLabel]: __props.size === "medium"
      }
    ];
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).ColoredIcon.container, unref(containerClass)]),
        style: normalizeStyle({ background: _ctx.background, color: _ctx.color }),
        title: _ctx.title
      }, [
        createBaseVNode("div", {
          class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).ColoredIcon.labelContainer)
        }, [
          createBaseVNode("span", {
            class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).ColoredIcon.label)
          }, toDisplayString(_ctx.label), 3),
          unref(isSubLabelVisible) ? (openBlock(), createElementBlock("span", {
            key: 0,
            class: normalizeClass(subLabelClasses)
          }, toDisplayString(_ctx.subLabel), 1)) : createCommentVNode("", true)
        ], 2)
      ], 14, _hoisted_1);
    };
  }
});
export {
  _sfc_main as default
};
