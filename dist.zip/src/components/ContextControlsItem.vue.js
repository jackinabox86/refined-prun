import { C } from "../infrastructure/prun-ui/prun-css.js";
import { showBuffer } from "../infrastructure/prun-ui/buffers.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, createTextVNode, createCommentVNode } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "../../npm/@vue+shared@3.5.20-@vue-shared-shared.esm-bundler.js";
import { unref } from "../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ContextControlsItem",
  props: {
    cmd: {},
    label: {}
  },
  setup(__props) {
    const props = __props;
    const commandParts = computed(() => {
      const words = props.cmd.split(" ");
      let command = words.shift();
      if (command === "XIT") {
        command += " " + words.shift();
      }
      return [command, words.join(" ")];
    });
    const itemClasses = [C.ContextControls.item, C.fonts.fontRegular, C.type.typeSmall];
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(itemClasses),
        onClick: _cache[0] || (_cache[0] = () => unref(showBuffer)(_ctx.cmd))
      }, [
        createBaseVNode("span", null, [
          createBaseVNode("span", {
            class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).ContextControls.cmd)
          }, toDisplayString(unref(commandParts)[0]), 3),
          createTextVNode(" " + toDisplayString(unref(commandParts)[1]), 1)
        ]),
        _ctx.label ? (openBlock(), createElementBlock("span", {
          key: 0,
          class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).ContextControls.label)
        }, ": " + toDisplayString(_ctx.label), 3)) : createCommentVNode("", true)
      ]);
    };
  }
});
export {
  _sfc_main as default
};
