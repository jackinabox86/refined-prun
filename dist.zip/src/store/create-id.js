import v4 from "../../npm/uuid@11.1.0-uuid-esm-browser-v4.js";
const createId = () => v4().replaceAll("-", "");
export {
  createId
};
