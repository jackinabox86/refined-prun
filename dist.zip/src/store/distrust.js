import { userData } from "./user-data.js";
import { usersStore } from "../infrastructure/prun-api/data/users.js";
import { computed } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
const distrustedSet = computed(
  () => new Set(userData.distrustedUsernames.map((x) => x.toUpperCase()))
);
function isDistrustedUsername(username) {
  if (!username) {
    return false;
  }
  return distrustedSet.value.has(username.toUpperCase());
}
function isDistrustedCompany(code, name) {
  if (!code && !name) {
    return false;
  }
  const set = distrustedSet.value;
  const upperCode = code?.toUpperCase();
  const upperName = name?.toUpperCase();
  if (upperCode !== void 0 && set.has(upperCode)) {
    return true;
  }
  if (upperName !== void 0 && set.has(upperName)) {
    return true;
  }
  const users = usersStore.all.value;
  if (!users) {
    return false;
  }
  for (const user of users) {
    const companyMatches = upperCode !== void 0 && user.company.code.toUpperCase() === upperCode || upperName !== void 0 && user.company.name.toUpperCase() === upperName;
    if (companyMatches && isDistrustedUsername(user.username)) {
      return true;
    }
  }
  return false;
}
function isDistrustedPartner(partner) {
  if (!partner) {
    return false;
  }
  return isDistrustedCompany(partner.code ?? null, partner.name ?? null);
}
function setDistrustedUsernamesFromText(text) {
  userData.distrustedUsernames = text.split(/[\r\n,\t]+/).map((x) => x.trim()).filter((x) => x.length > 0);
}
export {
  isDistrustedCompany,
  isDistrustedPartner,
  isDistrustedUsername,
  setDistrustedUsernamesFromText
};
