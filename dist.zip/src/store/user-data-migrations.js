import { migrateVersionedUserData } from "./user-data-versioned-migrations.js";
import removeArrayElement from "../utils/remove-array-element.js";
function isCheckpoint(entry) {
  return entry.length === 1;
}
const migrations = [
  [
    "21.04.2026 Disable oog-burn-inflight-inventory by default",
    (userData) => {
      if (!userData.settings.disabled.includes("oog-burn-inflight-inventory")) {
        userData.settings.disabled.push("oog-burn-inflight-inventory");
      }
    }
  ],
  ["10.03.2026 Checkpoint"],
  [
    "10.03.2026 Remove funny-rations",
    (userData) => {
      removeFeature(userData, "funny-rations");
    }
  ],
  [
    "11.03.2026 Add linkedBuffersPresets",
    (userData) => {
      userData.linkedBuffersPresets = [];
    }
  ],
  [
    "09.03.2026 Add contextMenuExchange setting",
    (userData) => {
      userData.settings.contextMenuExchange = "AI1";
    }
  ],
  [
    "24.01.2026 Remove cxpc-default-1y",
    (userData) => {
      removeFeature(userData, "cxpc-default-1y");
    }
  ],
  [
    "02.02.2026 Add full equity mode",
    (userData) => {
      userData.fullEquityMode = true;
    }
  ],
  [
    "25.12.2025 Rename features",
    (userData) => {
      renameFeature(userData, "custom-item-sorting", "inv-custom-item-sorting");
      renameFeature(userData, "item-markers", "inv-item-markers");
      renameFeature(userData, "show-space-remaining", "inv-show-space-remaining");
    }
  ],
  [
    "25.12.2025 Add audio volume",
    (userData) => {
      userData.settings.audioVolume = 0.4;
    }
  ]
];
function removeFeature(userData, feature) {
  removeArrayElement(userData.settings.disabled, feature);
}
function renameFeature(userData, oldName, newName) {
  const disabled = userData.settings.disabled;
  const index = disabled.indexOf(oldName);
  if (index !== -1) {
    disabled[index] = newName;
  }
}
function migrateUserData(userData) {
  const orderedMigrations = migrations.slice().reverse();
  if (userData.version !== void 0) {
    migrateVersionedUserData(userData);
    delete userData.version;
    userData.migrations = [];
  }
  if (userData.migrations === void 0) {
    userData.migrations = compactIds(
      orderedMigrations,
      orderedMigrations.map((x) => x[0])
    );
    return userData;
  }
  const performed = new Set(userData.migrations);
  for (let i = orderedMigrations.length - 1; i >= 0; i--) {
    const entry = orderedMigrations[i];
    if (isCheckpoint(entry) && performed.has(entry[0])) {
      for (let j = 0; j < i; j++) {
        performed.add(orderedMigrations[j][0]);
      }
      break;
    }
  }
  for (const entry of orderedMigrations) {
    const id = entry[0];
    if (performed.has(id)) {
      continue;
    }
    if (!isCheckpoint(entry)) {
      entry[1](userData);
    }
    performed.add(id);
    userData.migrations.push(id);
  }
  userData.migrations = compactIds(orderedMigrations, userData.migrations);
  return userData;
}
function compactIds(orderedEntries, appliedIds) {
  const applied = new Set(appliedIds);
  let latestCheckpointIndex = -1;
  for (let i = orderedEntries.length - 1; i >= 0; i--) {
    const entry = orderedEntries[i];
    if (!isCheckpoint(entry) || !applied.has(entry[0])) {
      continue;
    }
    let complete = true;
    for (let j = i - 1; j >= 0; j--) {
      if (isCheckpoint(orderedEntries[j]) && applied.has(orderedEntries[j][0])) {
        break;
      }
      if (!applied.has(orderedEntries[j][0])) {
        complete = false;
        break;
      }
    }
    if (complete) {
      latestCheckpointIndex = i;
      break;
    }
  }
  if (latestCheckpointIndex === -1) {
    return appliedIds;
  }
  const removable = /* @__PURE__ */ new Set();
  for (let i = 0; i < latestCheckpointIndex; i++) {
    removable.add(orderedEntries[i][0]);
  }
  const checkpointId = orderedEntries[latestCheckpointIndex][0];
  const result = [checkpointId];
  for (const id of appliedIds) {
    if (!removable.has(id) && id !== checkpointId) {
      result.push(id);
    }
  }
  return result;
}
export {
  migrateUserData
};
