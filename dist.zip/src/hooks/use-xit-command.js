import { inject } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function useXitCommand() {
  return inject(xitCommandKey) ?? "";
}
const xitCommandKey = Symbol();
export {
  useXitCommand,
  xitCommandKey
};
