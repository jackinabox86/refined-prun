import { inject } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function useXitParameters() {
  return inject(xitParametersKey) ?? [];
}
const xitParametersKey = Symbol();
export {
  useXitParameters,
  xitParametersKey
};
