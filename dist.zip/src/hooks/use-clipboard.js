import { ref, onScopeDispose } from "../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
function useClipboard() {
  const copied = ref(false);
  let timeout;
  onScopeDispose(() => clearTimeout(timeout));
  async function copy(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch (e) {
      console.error("Failed to copy to clipboard", e);
      return;
    }
    copied.value = true;
    clearTimeout(timeout);
    timeout = setTimeout(() => {
      copied.value = false;
    }, 1e3);
  }
  return { copied, copy };
}
export {
  useClipboard
};
