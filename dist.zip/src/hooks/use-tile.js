import { inject } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
function useTile() {
  return inject(tileKey);
}
const tileKey = Symbol();
export {
  tileKey,
  useTile
};
