function startMeasure(name) {
}
function stopMeasure() {
}
export {
  startMeasure,
  stopMeasure
};
