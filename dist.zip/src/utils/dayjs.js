import duration from "../../npm/dayjs@1.11.18-dayjs-plugin-duration.js";
import relativeTime from "../../npm/dayjs@1.11.18-dayjs-plugin-relativeTime.js";
import isoWeek from "../../npm/dayjs@1.11.18-dayjs-plugin-isoWeek.js";
import dayjs from "../../npm/dayjs@1.11.18-dayjs-dayjs.min.js";
import { ref } from "../../npm/@vue+reactivity@3.5.20-@vue-reactivity-reactivity.esm-bundler.js";
import { computed } from "../../npm/@vue+runtime-core@3.5.20-@vue-runtime-core-runtime-core.esm-bundler.js";
dayjs.extend(duration);
dayjs.extend(relativeTime);
dayjs.extend(isoWeek);
const eachSecond = ref(0);
setInterval(() => eachSecond.value++, 1e3);
const eachMinute = ref(0);
setInterval(() => eachMinute.value++, 6e4);
const dayjsEachSecond = computed(() => live(dayjs(), eachSecond));
const timestampEachSecond = computed(() => live(Date.now(), eachSecond));
const timestampEachMinute = computed(() => live(Date.now(), eachMinute));
function live(value, tick) {
  void tick.value;
  return value;
}
export {
  dayjsEachSecond,
  timestampEachMinute,
  timestampEachSecond
};
