import { getDefaultExportFromCjs } from "../virtual/commonjsHelpers.js";
import { __require as requireEs } from "./math-expression-evaluator@2.0.7-math-expression-evaluator-es2.js";
var esExports = requireEs();
const Mexp = /* @__PURE__ */ getDefaultExportFromCjs(esExports);
export {
  Mexp as default
};
