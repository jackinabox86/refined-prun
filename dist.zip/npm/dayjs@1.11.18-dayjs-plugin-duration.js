import { getDefaultExportFromCjs } from "../virtual/commonjsHelpers.js";
import { __require as requireDuration } from "./dayjs@1.11.18-dayjs-plugin-duration2.js";
var durationExports = requireDuration();
const duration = /* @__PURE__ */ getDefaultExportFromCjs(durationExports);
export {
  duration as default
};
