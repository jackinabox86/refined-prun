import { getDefaultExportFromCjs } from "../virtual/commonjsHelpers.js";
import { __require as requireAdvancedFormat } from "./dayjs@1.11.18-dayjs-plugin-advancedFormat2.js";
var advancedFormatExports = requireAdvancedFormat();
const AdvancedFormat = /* @__PURE__ */ getDefaultExportFromCjs(advancedFormatExports);
export {
  AdvancedFormat as default
};
