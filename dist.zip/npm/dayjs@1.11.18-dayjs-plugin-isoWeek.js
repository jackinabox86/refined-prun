import { getDefaultExportFromCjs } from "../virtual/commonjsHelpers.js";
import { __require as requireIsoWeek } from "./dayjs@1.11.18-dayjs-plugin-isoWeek2.js";
var isoWeekExports = requireIsoWeek();
const isoWeek = /* @__PURE__ */ getDefaultExportFromCjs(isoWeekExports);
export {
  isoWeek as default
};
