import { getDefaultExportFromCjs } from "../virtual/commonjsHelpers.js";
import { __require as requireQuarterOfYear } from "./dayjs@1.11.18-dayjs-plugin-quarterOfYear2.js";
var quarterOfYearExports = requireQuarterOfYear();
const QuarterOfYear = /* @__PURE__ */ getDefaultExportFromCjs(quarterOfYearExports);
export {
  QuarterOfYear as default
};
