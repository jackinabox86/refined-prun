import { getDefaultExportFromCjs } from "../virtual/commonjsHelpers.js";
import { __require as requireHammer } from "./hammerjs@2.0.8-hammerjs-hammer2.js";
var hammerExports = requireHammer();
const Hammer = /* @__PURE__ */ getDefaultExportFromCjs(hammerExports);
export {
  Hammer as default
};
