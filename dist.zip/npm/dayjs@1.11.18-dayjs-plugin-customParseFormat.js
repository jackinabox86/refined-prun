import { getDefaultExportFromCjs } from "../virtual/commonjsHelpers.js";
import { __require as requireCustomParseFormat } from "./dayjs@1.11.18-dayjs-plugin-customParseFormat2.js";
var customParseFormatExports = requireCustomParseFormat();
const CustomParseFormat = /* @__PURE__ */ getDefaultExportFromCjs(customParseFormatExports);
export {
  CustomParseFormat as default
};
