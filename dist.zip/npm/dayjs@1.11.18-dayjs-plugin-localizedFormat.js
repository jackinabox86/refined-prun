import { getDefaultExportFromCjs } from "../virtual/commonjsHelpers.js";
import { __require as requireLocalizedFormat } from "./dayjs@1.11.18-dayjs-plugin-localizedFormat2.js";
var localizedFormatExports = requireLocalizedFormat();
const LocalizedFormat = /* @__PURE__ */ getDefaultExportFromCjs(localizedFormatExports);
export {
  LocalizedFormat as default
};
