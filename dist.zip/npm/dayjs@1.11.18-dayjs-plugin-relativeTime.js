import { getDefaultExportFromCjs } from "../virtual/commonjsHelpers.js";
import { __require as requireRelativeTime } from "./dayjs@1.11.18-dayjs-plugin-relativeTime2.js";
var relativeTimeExports = requireRelativeTime();
const relativeTime = /* @__PURE__ */ getDefaultExportFromCjs(relativeTimeExports);
export {
  relativeTime as default
};
